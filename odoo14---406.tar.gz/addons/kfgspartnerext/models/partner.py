# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import time
import logging

from psycopg2 import sql, DatabaseError

from odoo import api, fields, models, _
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
from odoo.exceptions import ValidationError
from odoo.addons.base.models.res_partner import WARNING_MESSAGE, WARNING_HELP

_logger = logging.getLogger(__name__)



class ResPartner(models.Model):
    _name = 'res.partner'
    _inherit = 'res.partner'

    # Computed fields to order the partners as suppliers/customers according to the

    kfgs_supplier_rank = fields.Boolean(default=False, string='供应商')
    kfgs_customer_rank = fields.Boolean(default=False, string='客户')
    kfgs_inside_rank = fields.Boolean(default=True, string='内部')
    kfgs_partner_co_code = fields.Char(string='统一社会信用代码')
    kfgs_account_account = fields.Char(string='科目')


    @api.model_create_multi
    def create(self, vals_list):
        # for vals in vals_list:
        #     if 'customer_rank' not in vals:
        #         vals['customer_rank'] = 1
        #     elif 'supplier_rank' not in vals:
        #         vals['supplier_rank'] = 1
        return super().create(vals_list)
