# -*- coding: utf-8 -*-
# from odoo import http


# class Kfgspartnerext(http.Controller):
#     @http.route('/kfgspartnerext/kfgspartnerext/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/kfgspartnerext/kfgspartnerext/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('kfgspartnerext.listing', {
#             'root': '/kfgspartnerext/kfgspartnerext',
#             'objects': http.request.env['kfgspartnerext.kfgspartnerext'].search([]),
#         })

#     @http.route('/kfgspartnerext/kfgspartnerext/objects/<model("kfgspartnerext.kfgspartnerext"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('kfgspartnerext.object', {
#             'object': obj
#         })
