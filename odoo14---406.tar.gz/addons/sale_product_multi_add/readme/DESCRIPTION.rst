This module extends the functionality of sale module
and allow you to import multiple products into your current sale order.
