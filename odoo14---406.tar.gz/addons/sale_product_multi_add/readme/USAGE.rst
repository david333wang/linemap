This module add a button on sale order to import several products on your current sale order.
A wizard opens and allows the user to search and select products.

.. image:: /sale_product_multi_add/static/src/description/sale_product_multi_add.png
    :alt: Sale Product Multi Add
