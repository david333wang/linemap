# -*- coding: utf-8 -*-
# from odoo import http


# class Kfgspartnereval(http.Controller):
#     @http.route('/kfgspartnereval/kfgspartnereval/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/kfgspartnereval/kfgspartnereval/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('kfgspartnereval.listing', {
#             'root': '/kfgspartnereval/kfgspartnereval',
#             'objects': http.request.env['kfgspartnereval.kfgspartnereval'].search([]),
#         })

#     @http.route('/kfgspartnereval/kfgspartnereval/objects/<model("kfgspartnereval.kfgspartnereval"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('kfgspartnereval.object', {
#             'object': obj
#         })
