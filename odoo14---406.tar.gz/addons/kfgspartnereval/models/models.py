# -*- coding: utf-8 -*-

from odoo import models, fields, api


class kfgspartnereval(models.Model):
    _name = 'kfgspartnereval.kfgspartnereval'
    _description = 'partner evalate'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'image.mixin']

    name = fields.Char()
    scores = fields.Float(string='score')
    partner_id = fields.Many2one('res.partner', string='Customer', auto_join=True, tracking=True,
                                 domain="[ ('kfgs_supplier_rank', '=', True)]", required=True)

    category_id = fields.Many2many('res.partner.category', column1='partner_id',
                                    column2='category_id', string='Tags', related="partner_id.category_id")

    company_id = fields.Many2one('res.company', string='Company', required=True, default=lambda self: self.env.company)

    state = fields.Selection([
        ('draft', 'Quotation'),

        ('done', 'Locked'),
        ('cancel', 'Cancelled'),
        ], string='Status', readonly=True, copy=False, index=True, tracking=1, default='draft')



    # attachment_ids = fields.One2many('ir.attachment', compute='_compute_attachment_ids', string="Main Attachments",
    #     help="Attachment that don't come from message.")

    attachment_file = fields.Binary(string="File", required=True)

    # def _compute_attachment_ids(self):
    #     for task in self:
    #         attachment_ids = self.env['ir.attachment'].search(
    #             [('res_id', '=', task.id), ('res_model', '=', 'kfgspartnereval.kfgspartnereval')]).ids
    #         message_attachment_ids = task.mapped('message_ids.attachment_ids').ids  # from mail_thread
    #         task.attachment_ids = [(6, 0, list(set(attachment_ids) - set(message_attachment_ids)))]

    def _track_subtype(self, init_values):
        self.ensure_one()

        return super(kfgspartnereval, self)._track_subtype(init_values)