# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo.addons.achworkflow.tests.common import TestWorkflowCommon
from odoo.tests import tagged


@tagged('-standard', 'nice')
class TestRunningworkflow(TestWorkflowCommon):

    def setUp(self):
        super(TestRunningworkflow, self).setUp()
    
    def test_open2workflow_job(self):
        xname = 'TestProjct'
        self.assertEqual(xname, 'TestProject')

        print('')


       