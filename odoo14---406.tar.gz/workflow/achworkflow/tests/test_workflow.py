# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo.addons.achworkflow.tests.common import TestWorkflowCommon
from odoo.tests import tagged


@tagged('-standard', 'nice')
class TestSaleFlow(TestSaleCommonBase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()

        user = cls.env['res.users'].create({
            'name': 'Because I am saleman!',
            'login': 'saleman',
            'groups_id': [(6, 0, cls.env.user.groups_id.ids),
                          (4, cls.env.ref('achworkflow.group_achworkflow_manager').id)],
        })

        cls.env = cls.env(user=user)
        cls.cr = cls.env.cr

        cls.company = cls.env['res.company'].create({
            'name': 'Test Company',
            'currency_id': cls.env.ref('base.USD').id,
        })
        cls.company_data = cls.setup_sale_configuration_for_company(cls.company)

        cls.partner_a = cls.env['res.partner'].create({
            'name': 'partner_a',
            'company_id': False,
        })
        user.company_ids |= cls.company
        user.company_id = cls.company



    def test_open2workflow_job(self):
        self.channel = self.env['mail.channel'].create({'name': 'Test'})
        print('')
       