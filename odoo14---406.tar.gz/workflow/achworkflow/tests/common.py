# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.


from odoo.addons.mail.tests.common import mail_new_test_user
from odoo.addons.product.tests import common

class TestWorkflowCommon(common.SavepointCase):
    @classmethod
    def setUpClass(cls):
        super(TestWorkflowCommon, cls).setUpClass()

        # User Data: stock user and stock manager
        cls.user_stock_user = mail_new_test_user(
            cls.env,
            name='Pauline Poivraisselle',
            login='pauline',
            email='p.p@example.com',
            notification_type='inbox',
            groups='achworkflow.group_achworkflow_manager',
        )


