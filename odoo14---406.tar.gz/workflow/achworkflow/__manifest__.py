# -*- coding: utf-8 -*-
{
    'name': "achworkflow",

    'summary': """
        ACH 工作流""",

    'description': """
        ACH 工作流
    """,

    'author': "ACH",
    'website': "",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/14.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'tools/achworkflow',
    'version': '0.1',

    # any module necessary for this one to work correctly
  'depends': ['base', 'mail', 'resource', "base_user_role", "ach_frontui_workflow", "achwatermark"],


    # always loaded
    'data': [
         'data/workflow_type_data.xml',
          'security/achworkflow_security.xml',
           'security/ir.model.access.csv',
           'views/templates.xml',

           'views/workflowtype_views.xml',
            'views/achworkflow_views.xml',
            'views/achrunningworkflow_views.xml',
             'views/achrunningworkflowmixin_views.xml',

             'views/achrunningworkflowline_views.xml',
            'views/workflow_node_views.xml',
            'views/workflow_nodeappover_views.xml',
            'views/workflow_line_views.xml',
            'views/workflow_line_expression_views.xml',

        	'views/achworkflowtypelinkmodel_views.xml',

        	'report/running_workflow_templates.xml',
            'report/workflow_reports.xml',


        'views/res_config_settings_views.xml',


        'views/menuv.xml',
        'views/templates.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
    ],
    'installable': True,
    'application': True,
    'post_init_hook': 'workflow_post_init',
    'qweb': [
    'static/src/js/components/workflow_container/workflow_container.xml',
    'static/src/js/components/chatter_topbar/chatter_topbar.xml',    
    'static/src/js/components/chatter_topbar1/chatter_topbar1.xml',
    'static/src/js/components/composer/composer.xml',
    'static/src/js/components/composer_text_input/composer_text_input.xml',
    'static/src/js/components/activity_box/activity_box.xml',
    'static/src/js/components/activity/activity.xml',
    'static/src/js/components/chatter/chatter.xml',


],
}
