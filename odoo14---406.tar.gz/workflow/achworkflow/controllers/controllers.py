# -*- coding: utf-8 -*-
import json

from odoo import _, http, fields
from odoo.exceptions import AccessError
from odoo.http import request
from odoo.osv import expression
from odoo.tools import float_round, float_repr


class AchworkflowController(http.Controller):
    @http.route('/achworkflow/workflowformquery', type='json', auth='user')
    def workflowform_query(self, run_workflowid, **kw):
        if type(run_workflowid) == int:
            intr_workflowid = int(run_workflowid)
        else:
            intr_workflowid = 0

        rwfobjs = request.env['achworkflow.achrunningworkflow'].sudo().search([('id', '=', intr_workflowid)], limit=1)

        workflowid = 0
        # workflow id

        for rwfobj in rwfobjs:
            workflowid = rwfobj.workflow_id.id

        workflowlinkmodelobjs = request.env['achworkflow.achworkflowtypelinkmodel'].sudo().search(
            [('workflow_id', '=', workflowid), ('status', '=', 'run'), ('active', '=', True)], limit=1)

        template_action_id = 1
        model_name = "achworkflow.achworkflow"
        for workflowobj in workflowlinkmodelobjs:
            template_action_id = workflowobj.template_action_id.id
            model_name = workflowobj.model_name


        linkobjs = request.env[model_name].sudo().search([('runningworkflow_id.id', '=', intr_workflowid)], limit=1)
        linkmodel_id = 0
        if linkobjs:
            for linkobj in linkobjs:
                linkmodel_id = linkobj.id

        res_id = linkmodel_id
        action_domain = ''
        action_context = ''
        action_model = 'wodebug.wodebug'
        workflowid = 0

        str_action = _('''<action   name="%s"  res_id="%s" context="{'lang': 'zh_CN', 'tz': False, 'uid': 2, 'allowed_company_ids': [1], 'default_is_company': True, 'group_by': [], 'orderedBy': [], 'dashboard_merge_domains_contexts': False}" domain="[]"  view_mode="form" modifiers="{}"/>
               ''') % (str(template_action_id), str(res_id))

        info = {"runworkflowid": run_workflowid, "res_id": res_id, "template_action_id": template_action_id, "str_action": str_action}
        return info
