# -*- coding: utf-8 -*-

from . import controllers
from . import models
from . import report

from odoo import api, SUPERUSER_ID


def init_settings(env):
    res_config_id = env['res.config.settings'].create({
            'workflowstartnodekey': -1,
            'workflowmessageflag': -1000,
             'workflowactivityhour': 2,
            'workflowactivityflag': True,
            'workflowmessageflag': True,
        })
    res_config_id.execute()

def workflow_post_init(cr, registry):
    env = api.Environment(cr, SUPERUSER_ID, {})
    init_settings(env)