odoo.define('achworkflow/composer.js', function (require) {
'use strict';

const components = {

    TextInput: require('achworkflow/composer_text_input.js'),
};
const useDragVisibleDropZone = require('mail/static/src/component_hooks/use_drag_visible_dropzone/use_drag_visible_dropzone.js');
const useShouldUpdateBasedOnProps = require('mail/static/src/component_hooks/use_should_update_based_on_props/use_should_update_based_on_props.js');
const useStore = require('mail/static/src/component_hooks/use_store/use_store.js');
const useUpdate = require('mail/static/src/component_hooks/use_update/use_update.js');
const {
    isEventHandled,
    markEventHandled,
} = require('mail/static/src/utils/utils.js');

const { Component } = owl;
const { useRef } = owl.hooks;

class Composer extends Component {

    /**
     * @override
     */
    constructor(...args) {
        super(...args);
        this.isDropZoneVisible = useDragVisibleDropZone();
        useShouldUpdateBasedOnProps({
            compareDepth: {

            },
        });
        useStore(props => {
            const composer = this.env.models['workflow.chatter'].get(props.composerLocalId);

            return {
                composer,
            };
        }, {
            compareDepth: {
            },
        });
        useUpdate({ func: () => this._update() });

        /**
         * Reference of the text input component.
         */
        this._textInputRef = useRef('textInput');
        /**
         * Reference of the subject input. Useful to set content.
         */

    }

    mounted() {
    }

    willUnmount() {
    }


    //--------------------------------------------------------------------------
    // Public
    //--------------------------------------------------------------------------
   _update() {

        if (!this.composer) {
            return;
        }
        if (this._textInputRef.el) {
            this._textInputRef.el.value = this.composer.textInputContent;
        }
    }
    /**
     * @returns {mail.composer}
     */
    get composer() {
        return this.env.models['workflow.chatter'].get(this.props.composerLocalId);
    }



    get hasfirstbutton() {
        return (

            this.props.hasFirstSignButton || this.composer.hasFirstSignButton
        );
    }
    get hasmidbutton() {
        return (

            this.props.hasnormalSignButton || this.composer.hasnormalSignButton
        );
    }
    get haslastbutton() {
        return (

            this.props.haslastSignButton || this.composer.haslastSignButton
        );
    }

    //--------------------------------------------------------------------------
    // Private
    //--------------------------------------------------------------------------

    /**
     * Post a message in the composer on related thread.
     *
     * Posting of the message could be aborted if it cannot be posted like if there are attachments
     * currently uploading or if there is no text content and no attachments.
     *
     * @private
     */
    async _postMessage() {
//        if (!this.composer.canPostMessage) {
//            if (this.composer.hasUploadingAttachment) {
//                this.env.services['notification'].notify({
//                    message: this.env._t("Please wait while the file is uploading."),
//                    type: 'warning',
//                });
//            }
//            return;
//        }
        await this.composer.postMessage();
//        // TODO: we might need to remove trigger and use the store to wait for the post rpc to be done
//        // task-2252858
        this.trigger('o_workflow_message_posted');
    }

    /**
     * @private
     */


    //--------------------------------------------------------------------------
    // Handlers
    //--------------------------------------------------------------------------
    //============================================================sign
    _onClickSign(ev) {
        if(this.props.hasFirstSignButton || this.composer.hasFirstSignButton)return false;
         if( this.props.haslastSignButton || this.composer.haslastSignButton)return false;
         this.composer.openSignWindow();

    }


 /**
     * Called when clicking on "discard" button.
     *
     * @private
     * @param {MouseEvent} ev
     */
    _onClickSeeworkflow(ev) {
       this.composer.openFullWorkflow();
    }

    /**
     * Called when clicking on "discard" button.
     *
     * @private
     * @param {MouseEvent} ev
     */
    _onClickAgree(ev) {
        this._postAgreeMessage();
    }
    async _postAgreeMessage() {

        await this.composer.postagreeMessage();
//        // TODO: we might need to remove trigger and use the store to wait for the post rpc to be done
//        // task-2252858
        this.trigger('o_workflow_message_posted');
    }

    _onClickDisagree(ev) {
         this._postDisagreeMessage();
    }

    async _postDisagreeMessage() {

        await this.composer.postdisagreeMessage();
//        // TODO: we might need to remove trigger and use the store to wait for the post rpc to be done
//        // task-2252858
      this.trigger('o_workflow_message_posted');
    }


      _onClickDocument(ev) {
         this._postDocumentMessage();
    }

    async _postDocumentMessage() {

        await this.composer.postDocumentMessage();
//        // TODO: we might need to remove trigger and use the store to wait for the post rpc to be done
//        // task-2252858
        //this.trigger('o-message-posted');
    }


    /**
     * Called when clicking on "send" button.
     *
     * @private
     */
    _onClickSendToManager() {
        this._postMessage();
//        this.focus();
    }

    /**
     * @private
     */
    _onComposerSuggestionClicked() {
//        this.focus();
    }

    /**
     * @private
     */
    _onComposerTextInputSendShortcut() {
//        this._postMessage();
    }

    /**
     * Called when some files have been dropped in the dropzone.
     *
     * @private
     * @param {CustomEvent} ev
     * @param {Object} ev.detail
     * @param {FileList} ev.detail.files
     */
    async _onDropZoneFilesDropped(ev) {
//        ev.stopPropagation();
//        await this._fileUploaderRef.comp.uploadFiles(ev.detail.files);
//        this.isDropZoneVisible.value = false;
    }



    /**
     * @private
     */
    _onInputSubject() {
//        this.composer.update({ subjectContent: this._subjectRef.el.value });
    }







}

Object.assign(Composer, {
    components,
    defaultProps: {

    },
    props: {

        composerLocalId: String,

    },
    template: 'achworkflow.Composer',
});

return Composer;

});
