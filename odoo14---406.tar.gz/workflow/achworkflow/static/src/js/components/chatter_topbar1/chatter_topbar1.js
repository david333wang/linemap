odoo.define('achworkflow/ChatterTopMenubar.js', function (require) {
'use strict';

const components = {
    
};
const useShouldUpdateBasedOnProps = require('mail/static/src/component_hooks/use_should_update_based_on_props/use_should_update_based_on_props.js');
const useStore = require('mail/static/src/component_hooks/use_store/use_store.js');

const { Component } = owl;

class ChatterTopMenubar extends Component {

    /**
     * @override
     */
    constructor(...args) {
        super(...args);
        useShouldUpdateBasedOnProps();
        useStore(props => {
            const chatter = this.env.models['workflow.chatter'].get(props.chatterLocalId);
            
            return {
                chatter: chatter ? chatter.__state : undefined,
              
            };
        });
    }

    //--------------------------------------------------------------------------
    // Public
    //--------------------------------------------------------------------------

    /**
     * @returns {mail.chatter}
     */
    get chatter() {
        return this.env.models['workflow.chatter'].get(this.props.chatterLocalId);
    }

    //--------------------------------------------------------------------------
    // Handlers
    //--------------------------------------------------------------------------

    


  

    /**
     * @private
     * @param {MouseEvent} ev
     */
    _onClickSeeworkflow(ev) {
        if (!this.chatter) {
            return;
        }
        this.chatter.openFullWorkflow();

    }
        /**
     * @private
     * @param {MouseEvent} ev
     */
    _onClickSign(ev) {
        if (!this.chatter) {
            return;
        }
        this.chatter.openSignWindow();

    }

}

Object.assign(ChatterTopMenubar, {
    components,
    props: {
        chatterLocalId: String,
    },
    template: 'achworkflow.ChatterTopMenubar',
});

return ChatterTopMenubar;

});
