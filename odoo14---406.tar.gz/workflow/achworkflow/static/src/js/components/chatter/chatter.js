odoo.define('achworkflow/chatter.js', function (require) {
'use strict';

const components = {
     ActivityBox: require('achworkflow/activity_box.js'),

     ChatterTopbar: require('achworkflow/chatter_topbar.js'),
  ChatterTopMenubar: require('achworkflow/ChatterTopMenubar.js'),
     Composer: require('achworkflow/composer.js'),
};
const useShouldUpdateBasedOnProps = require('mail/static/src/component_hooks/use_should_update_based_on_props/use_should_update_based_on_props.js');
const useStore = require('mail/static/src/component_hooks/use_store/use_store.js');
const useUpdate = require('mail/static/src/component_hooks/use_update/use_update.js');

const { Component } = owl;
const { useRef } = owl.hooks;

class Chatter extends Component {

    /**
     * @override
     */
    constructor(...args) {
        super(...args);
        useShouldUpdateBasedOnProps();
        useStore(props => {
            const chatter = this.env.models['workflow.chatter'].get(props.chatterLocalId);
            
            return {
                chatter: chatter ? chatter.__state : undefined,
                
            };
        }, {
            compareDepth: {
                attachments: 1,
            },
        });
        useUpdate({ func: () => this._update() });
        /**
         * Reference of the composer. Useful to focus it.
         */
        //this._composerRef = useRef('composer');
        /**
         * Reference of the message list. Useful to trigger the scroll event on it.
         */
        this._textInputRef = useRef('textInput');
    }

    //--------------------------------------------------------------------------
    // Public
    //--------------------------------------------------------------------------

    /**
     * @returns {mail.chatter}
     */
    get chatter() {
        return this.env.models['workflow.chatter'].get(this.props.chatterLocalId);
    }

    //--------------------------------------------------------------------------
    // Private
    //--------------------------------------------------------------------------

    /**
     * @private
     */
    _notifyRendered() {
        this.trigger('o_Workflow_rendered', {
            // attachments: this.chatter.thread.allAttachments,
            // thread: this.chatter.thread.localId,
        });
    }

    /**
     * @private
     */
    _update() {
        if (!this.chatter) {
            return;
        }
        // if (this.chatter.thread) {
        //     this._notifyRendered();
        // }
         if (this.chatter) {


         }
    }

    //--------------------------------------------------------------------------
    // Handlers
    //--------------------------------------------------------------------------

    /**
     * @private
     */
    _onComposerMessagePosted() {
        // this.chatter.update({ isComposerVisible: false });
    }

    /**
     * @private
     * @param {MouseEvent} ev
     */
    _onScrollPanelScroll(ev) {
        // if (!this._threadRef.comp) {
        //     return;
        // }
        // this._threadRef.comp.onScroll(ev);
    }

}

Object.assign(Chatter, {
    components,
    props: {
        chatterLocalId: String,
    },
    template: 'achworkflow.Chatter',
});

return Chatter;

});
