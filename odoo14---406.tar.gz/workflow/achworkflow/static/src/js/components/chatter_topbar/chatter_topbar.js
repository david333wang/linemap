odoo.define('achworkflow/chatter_topbar.js', function (require) {
'use strict';

const components = {
    
};
const useShouldUpdateBasedOnProps = require('mail/static/src/component_hooks/use_should_update_based_on_props/use_should_update_based_on_props.js');
const useStore = require('mail/static/src/component_hooks/use_store/use_store.js');

const { Component } = owl;

class ChatterTopbar extends Component {

    /**
     * @override
     */
    constructor(...args) {
        super(...args);
        useShouldUpdateBasedOnProps();
        useStore(props => {
            const chatter = this.env.models['workflow.chatter'].get(props.chatterLocalId);
            
            return {
                chatter: chatter ? chatter.__state : undefined,
              
            };
        });
    }

    //--------------------------------------------------------------------------
    // Public
    //--------------------------------------------------------------------------

    /**
     * @returns {mail.chatter}
     */
    get chatter() {
        return this.env.models['workflow.chatter'].get(this.props.chatterLocalId);
    }

    //--------------------------------------------------------------------------
    // Handlers
    //--------------------------------------------------------------------------

    


  

    /**
     * @private
     * @param {MouseEvent} ev
     */
    _onClickSendMessage(ev) {

      this.chatter.openSignWindow();
    }

}

Object.assign(ChatterTopbar, {
    components,
    props: {
        chatterLocalId: String,
    },
    template: 'achworkflow.ChatterTopbar',
});

return ChatterTopbar;

});
