odoo.define('achworkflow/activity.js', function (require) {
'use strict';

const components = {
   
};
const useShouldUpdateBasedOnProps = require('mail/static/src/component_hooks/use_should_update_based_on_props/use_should_update_based_on_props.js');
const useStore = require('mail/static/src/component_hooks/use_store/use_store.js');
const useUpdate = require('mail/static/src/component_hooks/use_update/use_update.js');

const {
    auto_str_to_date,
    getLangDateFormat,
    getLangDatetimeFormat,
} = require('web.time');

const { Component, useState } = owl;
const { useRef } = owl.hooks;

class Activity extends Component {

    /**
     * @override
     */
    constructor(...args) {
        super(...args);
        useShouldUpdateBasedOnProps();
        this.state = useState({

        });
        useStore(props => {
            const activity = this.env.models['achworkflow.activity'].get(props.activityLocalId);
            return {
                activity: activity ? activity.__state : undefined,

            };


        });
        useUpdate({ func: () => this._update() });

        this._prettyBodyRef = useRef('prettyMessageBody');

    }

    //--------------------------------------------------------------------------
    // Public
    //--------------------------------------------------------------------------

    /**
     * @returns {mail.activity}
     */
    get activity() {
        return this.env.models['achworkflow.activity'].get(this.props.activityLocalId);
    }



    /**
     * @private
     */
    _update() {
        if (!this.activity) {
            return;
        }
        if (this._prettyBodyRef.el&&this.activity.signed_txt) {
            this._prettyBodyRef.el.innerHTML = this.activity.signed_txt;
        }

    }

    //--------------------------------------------------------------------------
    // Handlers
    //--------------------------------------------------------------------------
    /**
     * @returns {string}
     */
    get formattedCreateDatetime() {
        const momentCreateDate = moment(auto_str_to_date(this.activity.create_date));
        const datetimeFormat = getLangDatetimeFormat();
        return momentCreateDate.format(datetimeFormat);
    }
     get formattedauditDatetime() {
        const momentAuditDate = moment(auto_str_to_date(this.activity.signed_on));
        const datetimeFormat = getLangDatetimeFormat();
        return momentAuditDate.format(datetimeFormat);
    }
}

Object.assign(Activity, {
    components,
    props: {
        activityLocalId: String,
    },
    template: 'achworkflow.Activity',
});

return Activity;

});
