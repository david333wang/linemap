odoo.define('achworkflow/form_renderer', function (require) {
"use strict";



var FormRenderer = require('web.FormRenderer');
const { ComponentWrapper } = require('web.OwlCompatibility');
const { parseArch } = require("web.viewUtils");

var Context = require('web.Context');
var config = require('web.config');
var core = require('web.core');
var dataManager = require('web.data_manager');
var Dialog = require('web.Dialog');
var Domain = require('web.Domain');
var FormController = require('web.FormController');
var FormView = require('web.FormView');
var pyUtils = require('web.py_utils');
var session  = require('web.session');
var viewRegistry = require('web.view_registry');
var concurrency = require('web.concurrency');
var QWeb = core.qweb;




class WorkflowformContainerWrapperComponent extends ComponentWrapper {}

FormController.include(
{
    custom_events: _.extend({}, FormController.prototype.custom_events, {

        switch_view: '_onSwitchView',
    }),
    /**
     * We need to intercept switch_view event coming from sub views, because we
     * don't actually want to switch view in dashboard, we want to do a
     * do_action (which will open the record in a different breadcrumb).
     *
     * @private
     * @param {OdooEvent} event
     */
    _onSwitchView: function (event) {
        event.stopPropagation();
        this.do_action({
            type: 'ir.actions.act_window',
            res_model: event.data.model,
            views: [[event.data.formViewID || false, 'form']],
            res_id: event.data.res_id,
        });
    },



});



/**
 * Include the FormRenderer to instantiate the chatter area containing (a
 * subset of) the mail widgets (mail_thread, mail_followers and mail_activity).
 */
 FormRenderer.include({

 custom_events: _.extend({}, FormRenderer.prototype.custom_events, {
        switch_view: '_onSwitchView',
    }),

/**
     * @override
     */
    init(parent, state, params) {

        this._super.apply(this, arguments);

        // Do not load chatter in form view dialogs
        this._isFromFormViewDialog = params.isFromFormViewDialog;


              this.runworkflowid = 0;


        this.readwritemode = params.mode;
        this.actionsDescr = {};
        this._boardSubcontrollers = []; // for board: controllers of subviews
        this._boardFormViewIDs = {}; // for board: mapping subview controller to form vie
        this.str_wfaction = '';
        console.log('>>>>>>>>>>>>>>>'+this.runworkflowid );
        console.log('>=================================================');

    },
    /**
     * @override
     */
    destroy() {
           console.log('die111111111111111111111111');
        this.modelname = '';
        this.runworkflowid = 0;
        this.str_wfaction = '';

                this._super(...arguments);
    },
    /**
     * Call `on_attach_callback` for each subview
     *
     * @override
     */
    on_attach_callback: function () {
        _.each(this._boardSubcontrollers, function (controller) {
            if ('on_attach_callback' in controller) {
                controller.on_attach_callback();
            }
        });
    },
    /**
     * Call `on_detach_callback` for each subview
     *
     * @override
     */
    on_detach_callback: function () {
        _.each(this._boardSubcontrollers, function (controller) {
            if ('on_detach_callback' in controller) {
                controller.on_detach_callback();
            }
        });
    },


    //--------------------------------------------------------------------------
    // Private
    //--------------------------------------------------------------------------
 /**
     * @private
     * @param {Object} params
     * @param {jQueryElement} params.$node
     * @param {integer} params.actionID
     * @param {Object} params.context
     * @param {any[]} params.domain
     * @param {string} params.viewType
     * @returns {Promise}
     */
    _wf_createController: function (params) {
        var self = this;
        return this._rpc({
                route: '/web/action/load',
                params: {action_id: params.actionID}
            })
            .then(function (action) {
                if (!action) {
                    // the action does not exist anymore
                    return Promise.resolve();
                }
                var evalContext = new Context(params.context).eval();
                if (evalContext.group_by && evalContext.group_by.length === 0) {
                    delete evalContext.group_by;
                }
                // tz and lang are saved in the custom view
                // override the language to take the current one
                var rawContext = new Context(action.context, evalContext, {lang: session.user_context.lang});
                var context = pyUtils.eval('context', rawContext, evalContext);
                var domain = params.domain || pyUtils.eval('domain', action.domain || '[]', action.context);

                action.context = context;
                action.domain = domain;

                action.res_id =  Number(params.res_id);

                // When creating a view, `action.views` is expected to be an array of dicts, while
                // '/web/action/load' returns an array of arrays.
                action._views = action.views;
                action.views = $.map(action.views, function (view) { return {viewID: view[0], type: view[1]}});

                var viewType = params.viewType || action._views[0][1];
                var view = _.find(action._views, function (descr) {
                    return descr[1] === viewType;
                }) || [false, viewType];
                return self.loadViews(action.res_model, context, [view])
                           .then(function (viewsInfo) {
                    var viewInfo = viewsInfo[viewType];
                    var View = viewRegistry.get(viewType);

                    const searchQuery = {
                        context: context,
                        domain: domain,
                        groupBy: typeof context.group_by === 'string' && context.group_by ?
                                    [context.group_by] :
                                    context.group_by || [],
                        ordeedBy: context.orderedBy || [],
                    };

                    if (View.prototype.searchMenuTypes.includes('comparison')) {
                        searchQuery.timeRanges = context.comparison || {};
                    }

                    var view = new View(viewInfo, {
                        action: action,
                        hasSelectors: false,
                        modelName: action.res_model,
                        searchQuery,
                        withControlPanel: false,
                        withSearchPanel: false,
                    });
                    return view.getController(self).then(function (controller) {
                        self._boardFormViewIDs[controller.handle] = _.first(
                            _.find(action._views, function (descr) {
                                return descr[1] === 'form';
                            })
                        );
                        self._boardSubcontrollers.push(controller);
                        return controller.appendTo(params.$node);
                    });
                });
            });
    },
    /**
     * @private
     * @param {Object} node
     * @returns {jQueryElement}
     */
    _renderWFBoard: function (node) {
        var self = this;

        var hasAction = _.detect(node.children, function (column) {
            return _.detect(column.children,function (element){
                return element.tag === "action"? element: false;
            });
        });
        if (!hasAction) {
            return $(QWeb.render('Workflow_DashBoard.NoContent'));
        }

        // We should start with three columns available
        node = $.extend(true, {}, node);

        // no idea why master works without this, but whatever
        if (!('layout' in node.attrs)) {
            node.attrs.layout = node.attrs.style;
        }
        for (var i = node.children.length; i < 3; i++) {
            node.children.push({
                tag: 'column',
                attrs: {},
                children: []
            });
        }

        // register actions, alongside a generated unique ID
        _.each(node.children, function (column, column_index) {
            _.each(column.children, function (action, action_index) {
                action.attrs.id = 'action_' + column_index + '_' + action_index;
                self.actionsDescr[action.attrs.id] = action.attrs;
            });
        });

        var $html = $('<div>').append($(QWeb.render('Workflow_DashBoard', {node: node, isMobile: false})));
        this._boardSubcontrollers = []; // dashboard controllers are reset on re-render

        // render each view
        _.each(this.actionsDescr, function (action) {
            self.defs.push(self._wf_createController({
                $node: $html.find('.oe_action[data-id=' + action.id + '] .oe_content'),
                actionID: _.str.toNumber(action.name),
                context: action.context,
                domain: Domain.prototype.stringToArray(action.domain, {}),
                viewType: action.view_mode,
                res_id: action.res_id
            }));
        });


        return $html;

    },

    /**
     * Create the DOM element that will contain the chatter. This is made in
     * a separate method so it can be overridden (like in mail_enterprise for
     * example).
     *
     * @private
     * @returns {jQuery.Element}
     */

     getworkflowaction: async function(){
        var self = this;

         this.runworkflowid =this.state.res_id;
        var workflowaction = await this._rpc({
                        route: '/achworkflow/workflowformquery',
                        params: {run_workflowid: this.runworkflowid}
                    }
                );
        this.str_wfaction = workflowaction.str_action;



     },

    _makeWorkflowform: function() {
        var containedform = '<action   name="140"  res_id="1" context="{\'lang\': \'zh_CN\', \'tz\': False, \'uid\': 2}" domain="[]"  view_mode="form" modifiers="{}"/>';

        var $el = $('<div class="o_FormRenderer_workflowContainer"></div>');


        this.getworkflowaction();


        if(this.str_wfaction != '')
        {
            containedform = this.str_wfaction;
        }
        var obj_container = '' +
                '<board style="2-1">' +
                    '<column>' +
                    containedform +
                           '</column>' +
                '</board>' +
            ''

        var obj1 = parseArch(obj_container);
        $el.append(this._renderWFBoard(obj1));

        return $el;
    },

 /**
     * Override to fetch and display the lunch data. Because of the presence of
     * the searchPanel, also wrap the lunch widget and the renderer into
     * a div, to get the desired layout.
     *
     * @override
     * @private
     */
//    start: function () {
//       this.getworkflowaction();
//       return this._super.apply(this, arguments);
//    },
    _render:function()
    {
         this.getworkflowaction();
         return    this._super(...arguments);
    },
    /**
     * @override
     */
    _renderNode(node) {

        if (node.tag === 'div' && node.attrs.class === 'oe_workflowform') {
            if (this._isFromFormViewDialog) {
                return $('<div/>');
            }

            if(this.runworkflowid != undefined)
            {
                return this._makeWorkflowform();
            }
        }
        return         this._super(...arguments);
    },

//  _updateView: async function($newContent)
//    {
//        var self = this;
//         var t= await this._rpc({
//                        route: '/achworkflow/workflowformquery',
//                        params: {run_workflowid: this.runworkflowid}
//                    }
//                );
//    },
    /**
     * Let FormController know which form view it should display based on the
     * window action of the sub controller that is switching view
     *
     * @private
     * @param {OdooEvent} event
     */
    _onSwitchView: function (event) {
        event.data.formViewID = this._boardFormViewIDs[event.target.handle];
    },
    /**
     * Stops the propagation of 'update_filters' events triggered by the
     * controllers instantiated by the dashboard to prevent them from
     * interfering with the ActionManager.
     *
     * @private
     * @param {OdooEvent} event
     */
    _onUpdateFilters: function (event) {
        event.stopPropagation();
    },

 });



});
