odoo.define('achworkflow/form_renderer.js', function (require) {
"use strict";

const components = {
    WorkflowContainer: require('achworkflow/workflow_container.js'),
};

const FormRenderer = require('web.FormRenderer');
const { ComponentWrapper } = require('web.OwlCompatibility');

class AchworkflowContainerWrapperComponent extends ComponentWrapper {}

/**
 * Include the FormRenderer to instantiate the Workflow area containing (a
 * subset of) the mail widgets (mail_thread, mail_followers and mail_activity).
 */
FormRenderer.include({
    /**
     * @override
     */
    init(parent, state, params) {
        this._super(...arguments);
        this.workflowFields = {hasRecordReloadOnMessagePosted:true,};
        this._workflowContainerComponent = undefined;
        /**
         * The target of Workflow, if Workflow has to be appended to the DOM.
         * This is set when arch contains `div.oe_Workflow`.
         */
        this._workflowContainerTarget = undefined;
        // Do not load Workflow in form view dialogs
        this._isFromFormViewDialog = params.isFromFormViewDialog;
    },
    /**
     * @override
     */
    destroy() {
        this._super(...arguments);
        this._workflowContainerComponent = undefined;
   
       // this.off('o_message_posted', this);
      
    },

    //--------------------------------------------------------------------------
    // Private
    //--------------------------------------------------------------------------

    /**
     * Returns whether the form renderer has a Workflow to display or not.
     * This is based on arch, which should have `div.oe_Workflow`.
     *
     * @private
     * @returns {boolean}
     */
    _hasWorkflow() {
        return !!this._workflowContainerTarget;
    },
    /**
     * @private
     */
    _makeworkflowContainerComponent() {
        const props = this._makeworkflowContainerProps();
        this._workflowContainerComponent = new AchworkflowContainerWrapperComponent(
            this,
            components.WorkflowContainer,
            props
        );
        // Not in custom_events because other modules may remove this listener
        // while attempting to extend them.
        this.on('o_Workflow_rendered', this, ev => this._onWorkflowRendered(ev));
        
        if (this.workflowFields.hasRecordReloadOnMessagePosted) {
            this.on('o_workflow_message_posted', this, ev => {
                this.trigger_up('reload', { keepChanges: true });
            });
        }
      
    },
    /**
     * @private
     * @returns {Object}
     */
    _makeworkflowContainerProps() {

        return {            
        	hasComposer: false,
        	hasFirstSignButton:false,
        	hasnormalSignButton:false,
        	haslastSignButton:false,
            threadId: this.state.res_id,
            threadModel: this.state.model,
        };
    },
    /**
     * Create the DOM element that will contain the Workflow. This is made in
     * a separate method so it can be overridden (like in mail_enterprise for
     * example).
     *
     * @private
     * @returns {jQuery.Element}
     */
    _makeworkflowContainerTarget() {
        const $el = $('<div class="o_FormRenderer_workflowContainer o_FormRenderer_chatterContainer"/>');
        this._workflowContainerTarget = $el[0];
        return $el;
    },
    /**
     * Mount the Workflow
     *
     * Force re-mounting Workflow component in DOM. This is necessary
     * because each time `_renderView` is called, it puts old content
     * in a fragment.
     *
     * @private
     */
    async _mountworkflowContainerComponent() {
        try {
            await this._workflowContainerComponent.mount(this._workflowContainerTarget);
        } catch (error) {
            if (error.message !== "Mounting operation cancelled") {
                throw error;
            }
        }
    },
    /**
     * @override
     */
    _renderNode(node) {
        if (node.tag === 'div' && node.attrs.class === 'oo_achworkflow') {
            if (this._isFromFormViewDialog) {
                return $('<div/>');
            }
            return this._makeworkflowContainerTarget();
        }
        return this._super(...arguments);
    },
    /**
     * Overrides the function to render the Workflow once the form view is
     * rendered.
     *
     * @override
     */
    async __renderView() {
        await this._super(...arguments);
        if (this._hasWorkflow()) {
            if (!this._workflowContainerComponent) {
                this._makeworkflowContainerComponent();
            } else {
                await this._updateworkflowContainerComponent();
            }
            await this._mountworkflowContainerComponent();
        }
    },
    /**
     * @private
     */
    async _updateworkflowContainerComponent() {
        const props = this._makeworkflowContainerProps();
        try {
            await this._workflowContainerComponent.update(props);
        } catch (error) {
            if (error.message !== "Mounting operation cancelled") {
                throw error;
            }
        }
    },

    //--------------------------------------------------------------------------
    // Handlers
    //--------------------------------------------------------------------------

    /**
     * @abstract
     * @private
     * @param {OdooEvent} ev
     * @param {Object} ev.data
     * @param {mail.attachment[]} ev.data.attachments
     * @param {mail.thread} ev.data.thread
     */
    _onWorkflowRendered(ev) {},
});

});
