odoo.define('achworkflow/models/activity.js', function (require) {
'use strict';

const { registerNewModel } = require('mail/static/src/model/model_core.js');
const { attr, many2many, many2one } = require('mail/static/src/model/model_field.js');
const { clear } = require('mail/static/src/model/model_field_command.js');

function factory(dependencies) {

    class Activity extends dependencies['mail.model'] {


        //----------------------------------------------------------------------
        // Public
        //----------------------------------------------------------------------



        //----------------------------------------------------------------------
        // Public
        //----------------------------------------------------------------------

        /**
         * @static
         * @param {Object} data
         * @return {Object}
         */
        static convertData(data) {
            const data2 = {};
             if ('id' in data) {
                data2.id = data.id;
            }

            if ('create_date' in data) {
                data2.create_date = data.create_date
            }
            if ('signed_txt' in data) {
                data2.signed_txt = data.signed_txt
            }
            if ('signed_on' in data) {
                data2.signed_on = data.signed_on
            }
             if ('node_text' in data) {
                data2.node_text = data.node_text
            }
             if ('state' in data) {
                data2.state = data.state
            }
            if ('authedstate' in data) {
                data2.authedstate = data.authedstate
            }

                // relation
            data2.chatter = [
                        ['insert', {
                            threadId: 4

                        }],
                    ];

            if ('create_uid' in data) {
                if (!data.create_uid) {
                    data2.creator = [['unlink-all']];
                } else {
                    data2.creator = [
                        ['insert', {
                            id: data.create_uid[0],
                            display_name: data.create_uid[1],
                        }],
                    ];
                }
            }

             if ('user_id' in data) {
                if (!data.user_id) {
                    data2.user_id = [['unlink-all']];
                } else {
                    data2.user_id = [
                        ['insert', {
                            id: data.user_id[0],
                            display_name: data.user_id[1],
                        }],
                    ];
                }
            }

            return data2;
        }



        async fetchAndUpdate() {

        }





        //----------------------------------------------------------------------
        // Private
        //----------------------------------------------------------------------

        /**
         * @override
         */
        static _createRecordLocalId(data) {
            return `${this.modelName}_${data.id}`;
        }



        /**
         * Wysiwyg editor put `<p><br></p>` even without a note on the activity.
         * This compute replaces this almost empty value by an actual empty
         * value, to reduce the size the empty note takes on the UI.
         *
         * @private
         * @returns {string|undefined}
         */

    }

    Activity.fields = {
        user_id: many2one('mail.user'),
        user_idPartner: many2one('mail.partner', {
            related: 'user_id.partner',
        }),



        creator: many2one('mail.user'),
        create_date: attr(),

        signed_txt: attr(),

        signed_on: attr(),
        node_text: attr(),

        state: attr(),
        authedstate: attr(),

        id: attr(),


        /**
         * Determines to which "thread" (using `mail.activity.mixin` on the
         * server) `this` belongs to.
         */
        chatter: many2one('workflow.chatter', {
            inverse: 'activities',
        }),

    };

    Activity.modelName = 'achworkflow.activity';

    return Activity;
}

registerNewModel('achworkflow.activity', factory);

});
