odoo.define('achworkflow/models/chatter.js', function (require) {
'use strict';

const { registerNewModel } = require('mail/static/src/model/model_core.js');
const { attr, many2one, one2one, one2many } = require('mail/static/src/model/model_field.js');
const mailUtils = require('mail.utils');


const {
    addLink,
    escapeAndCompactTextContent,
    parseAndTransform,
} = require('mail.utils');
function factory(dependencies) {

    const getThreadNextTemporaryId = (function () {
        let tmpId = 0;
        return () => {
            tmpId -= 1;
            return tmpId;
        };
    })();

    const getMessageNextTemporaryId = (function () {
        let tmpId = 0;
        return () => {
            tmpId -= 1;
            return tmpId;
        };
    })();

    class Chatter extends dependencies['mail.model'] {

        /**
         * @override
         */
        _willDelete() {
            return super._willDelete(...arguments);
        }

        //----------------------------------------------------------------------
        // Public
        //----------------------------------------------------------------------

        focus() {

        }
        //-------------------------------------------------------------

       //--------------------------------------------


          /**
         * Post a message in provided composer's thread based on current composer fields values.
         */
        async postMessage() {
          const workflow = this.threadId
          console.log('==============step one postmessage=====================');
          if(this.textInputContent=='')
          {
              this.env.services['notification'].notify({
                        message: this.env._t("You must input something."),
                        type: 'warning',
                    });
              return;
          }
          const escapedAndCompactContent = escapeAndCompactTextContent(this.textInputContent);
          let body = escapedAndCompactContent.replace(/&nbsp;/g, ' ').trim();
            // This message will be received from the mail composer as html content
            // subtype but the urls will not be linkified. If the mail composer
            // takes the responsibility to linkify the urls we end up with double
            // linkification a bit everywhere. Ideally we want to keep the content
            // as text internally and only make html enrichment at display time but
            // the current design makes this quite hard to do.
         // body = this._generateMentionsLinks(body);
          body = parseAndTransform(body, addLink);
          let postData = {
              signed_txt : body,
              threadId: this.threadId,
              threadModel: this.threadModel,

          };
            try {

                 await this.async(() =>
                             this.env.models['workflow.chatter'].performRpcMessagePost({
                                postData,
                                threadId: this.threadId,
                                threadModel: this.threadModel,
                            })
                        );
                 this.update({textInputContent: ''});
              }
              finally
              {
                    this.refreshWorkflowActivities();
              }


        }


                /**
         * Performs the `message_post` RPC on given threadModel.
         *
         * @static
         * @param {Object} param0
         * @param {Object} param0.postData
         * @param {integer} param0.threadId
         * @param {string} param0.threadModel
         * @return {integer} the posted message id
         */
        static async performRpcMessagePost({ postData, threadId, threadModel }) {
            return this.env.services.rpc({
                model: threadModel,
                method: 'trigger_message_post',
                args: [threadId],
                kwargs: postData,
            });
        }

    //============================================
    //public string function

        async refresh() {
                this.refreshWorkflowActivities();



        }
        async refreshWorkflowActivities() {

            // A bit "extreme", may be improved
            if(this.threadId==-1)
            {return;}

            const [{ runningworkflow_id: newActivityIds }] = await this.async(() => this.env.services.rpc({
                model: this.threadModel,
                method: 'read',
                args: [this.threadId, ['runningworkflow_id']]
            }, { shadow: true }));

            const [{ runningworkflowline_ids: newworkflowlineIds }] = await this.async(() => this.env.services.rpc({
                model: 'achworkflow.achrunningworkflow',
                method: 'read',
                args: [newActivityIds[0],['runningworkflowline_ids']]
            }, { shadow: true }));


            const workflowlinesData = await this.async(() => this.env.services.rpc({
                model: 'achworkflow.achrunningworkflowline',
                method: 'workflowline_format',
                args: [newworkflowlineIds]
            }, { shadow: true }));

             const workflowlinesjudgeData = await this.async(() => this.env.services.rpc({
                model: 'achworkflow.achrunningworkflowline',
                method: 'workflowline_judge',
                args: [newworkflowlineIds]
            }, { shadow: true }));
             console.log('=====================================');
             console.log(workflowlinesjudgeData);

            if(workflowlinesjudgeData==1)
            {//draft=>firstnode to second
                 this.update({hasComposer: true, hasFirstSignButton: true, hasnormalSignButton: false, haslastSignButton: false, textInputContent: ''});
             }
             if(workflowlinesjudgeData==2)
            {//done
                 this.update({hasComposer: false, hasFirstSignButton: false, hasnormalSignButton: false, haslastSignButton: false, textInputContent: ''});
             }
            if(workflowlinesjudgeData==3)
            {// this uid is to do
                 this.update({hasComposer: true, hasFirstSignButton: false, hasnormalSignButton: true, haslastSignButton: false, textInputContent: ''});
             }
            if(workflowlinesjudgeData==4)
            {// this last uid is to do
                 this.update({hasComposer: true, hasFirstSignButton: false, hasnormalSignButton: false, haslastSignButton: true, textInputContent: 'document'});
             }

//            Object.assign({threadId:this.threadId,threadModel:this.threadModel},workflowlinesData)

            const activities = this.env.models['achworkflow.activity'].insert(workflowlinesData.map(
              workflowData => this.env.models['achworkflow.activity'].convertData(workflowData)
           ));
           activities.reverse();
            this.update({ activities: [['replace', activities]] });
        }


    //====================================================
    //----------------------------------------------------------------
    //code 9-20
    //-------------------------------------------

          /**
         * Post a message in provided composer's thread based on current composer fields values.
         */
        async postagreeMessage() {
          const workflow = this.threadId
          console.log('==============post agree action message=====================');
           if(this.textInputContent=='')
            {
              this.env.services['notification'].notify({
                        message: this.env._t("You must input something."),
                        type: 'warning',
                    });
              return;
          }
          const escapedAndCompactContent = escapeAndCompactTextContent(this.textInputContent);
          let body = escapedAndCompactContent.replace(/&nbsp;/g, ' ').trim();
            // This message will be received from the mail composer as html content
            // subtype but the urls will not be linkified. If the mail composer
            // takes the responsibility to linkify the urls we end up with double
            // linkification a bit everywhere. Ideally we want to keep the content
            // as text internally and only make html enrichment at display time but
            // the current design makes this quite hard to do.
         // body = this._generateMentionsLinks(body);
          body = parseAndTransform(body, addLink);
          let postData = {
              signed_txt : body,
              threadId: this.threadId,
              threadModel: this.threadModel,
              waction:'0',//agree

          };
            try {

                 await this.async(() =>
                             this.env.models['workflow.chatter'].performRpcActionMessagePost({
                                postData,
                                threadId: this.threadId,
                                threadModel: this.threadModel,


                            })
                        );
                 this.update({ textInputContent: ''});
              }
              finally
              {
                    this.refreshWorkflowActivities();
              }


        }



        async postDocumentMessage() {
          const workflow = this.threadId
          console.log('==============post last document action message=====================');
           if(this.textInputContent=='')
            {
              this.env.services['notification'].notify({
                        message: this.env._t("You must input something."),
                        type: 'warning',
                    });
              return;
          }

          const escapedAndCompactContent = escapeAndCompactTextContent(this.textInputContent);
          let body = escapedAndCompactContent.replace(/&nbsp;/g, ' ').trim();
            // This message will be received from the mail composer as html content
            // subtype but the urls will not be linkified. If the mail composer
            // takes the responsibility to linkify the urls we end up with double
            // linkification a bit everywhere. Ideally we want to keep the content
            // as text internally and only make html enrichment at display time but
            // the current design makes this quite hard to do.
         // body = this._generateMentionsLinks(body);
          body = parseAndTransform(body, addLink);
          let postData = {
              signed_txt : body,
              threadId: this.threadId,
              threadModel: this.threadModel,
              waction:'3',//documented

          };
            try {

                 await this.async(() =>
                             this.env.models['workflow.chatter'].performRpcActionMessagePost({
                                postData,
                                threadId: this.threadId,
                                threadModel: this.threadModel,


                            })
                        );
                 this.update({ textInputContent: '', overflag: true});
              }
              finally
              {
                    this.refreshWorkflowActivities();
              }


        }

            /**
         * Performs the `message_post` RPC on given threadModel.
         *
         * @static
         * @param {Object} param0
         * @param {Object} param0.postData
         * @param {integer} param0.threadId
         * @param {string} param0.threadModel
         * @return {integer} the posted message id
         */
        static async performRpcActionMessagePost({ postData, threadId, threadModel }) {
            return this.env.services.rpc({
                model: threadModel,
                method: 'triggerWorkflowAction',
                args: [threadId],
                kwargs: postData,
            });
        }



        async postdisagreeMessage() {
              const workflow = this.threadId
              console.log('==============post disagree action message=====================');
               if(this.textInputContent=='')
                {
              this.env.services['notification'].notify({
                        message: this.env._t("You must input something."),
                        type: 'warning',
                    });
              return;
                }
              const escapedAndCompactContent = escapeAndCompactTextContent(this.textInputContent);
              let body = escapedAndCompactContent.replace(/&nbsp;/g, ' ').trim();
                // This message will be received from the mail composer as html content
                // subtype but the urls will not be linkified. If the mail composer
                // takes the responsibility to linkify the urls we end up with double
                // linkification a bit everywhere. Ideally we want to keep the content
                // as text internally and only make html enrichment at display time but
                // the current design makes this quite hard to do.
             // body = this._generateMentionsLinks(body);
              body = parseAndTransform(body, addLink);
              let postData = {
                  signed_txt : body,
                  threadId: this.threadId,
                  threadModel: this.threadModel,
                  waction:'1',
              };
                try {

                     await this.async(() =>
                                 this.env.models['workflow.chatter'].performRpcActionMessagePost({
                                    postData,
                                    threadId: this.threadId,
                                    threadModel: this.threadModel,
                                })
                            );
                     this.update({textInputContent: ''});
                  }
                  finally
                  {
                        this.refreshWorkflowActivities();
                  }


            }




           /**
         * Performs the `message_post` RPC on given threadModel.
         *
         * @static
         * @param {Object} param0
         * @param {Object} param0.postData
         * @param {integer} param0.threadId
         * @param {string} param0.threadModel
         * @return {integer} the posted message id
         */
        static async performRpcDisagreeMessagePost({ postData, threadId, threadModel }) {
            return this.env.services.rpc({
                model: threadModel,
                method: 'triggerWorkflowAction',
                args: [threadId],
                kwargs: postData,
            });
        }
        // to do sign widnow
        async openSignWindow() {
             event.preventDefault();
              if(this.threadId==-1)
               {
              this.env.services['notification'].notify({
                        message: this.env._t("Workflow is not running."),
                        type: 'warning',
                    });
              return;
              }


             const domain = [
            ['state', '=', 'todo'],
            ['runningworkflow_id', '=', this.threadId],

            ['user_id', '=', this.env.session.uid],



            ];
            const fields=['id'];
             const newActivityIds = await this.async(() => this.env.services.rpc({
                model: 'achworkflow.achrunningworkflowline',
                method: 'search_read',

                kwargs: {domain,fields,},
            }, { shadow: true }));
            if(newActivityIds.length == 0)
              {return;}

            const domain1 = [
            ['model', '=', 'achworkflow.achrunningworkflowline'],
            ['xml_id', '=', 'achworkflow.view_achrunningworkflowline_tosign_form'],

            ];
            const fields1=['id', 'xml_id'];
             const result = await this.async(() => this.env.services.rpc({
                model: 'ir.ui.view',
                method: 'search_read',

                kwargs: {domain: domain1,fields:fields1 ,},
            }, { shadow: true }));
            var viewid = 0
            result.forEach(function(item, index){
                if(item['xml_id'] == 'achworkflow.view_achrunningworkflowline_tosign_form')
                {
                    viewid = item['id'];
                }

            })
              const action = {
                            name: this.env._t('auth'),
                            type: 'ir.actions.act_window',
                            res_model: 'achworkflow.achrunningworkflowline',
                            res_id: newActivityIds[0].id,
                            context: {
                            'active_id': newActivityIds[0].id,
                            'create':0,
                            'edit':0,
            'flags': {
                'sidebar': false, //是否显示sidebar区域(主要为action按钮)
                'pager': false,  //是否显示分页组件
                'initial_mode': 'edit', // 进入时的默认视图模式
                'form': { //表单视图的设置
                    'action_buttons': false,
                    'initial_mode': 'edit',
                    'options': {'mode': 'view'},
                }
            },


                            },

                            views: [[viewid, 'form']],
                            target: 'new'
                            };
            const options = { on_close: () => {
                     this.refreshWorkflowActivities();
                },

            };
                await this.env.bus.trigger('do-action', { action, options });







        }
         /**
         * Open the full composer modal.
         */
        async openFullWorkflow() {
            event.preventDefault();

            if(this.threadId==-1)
             {
              this.env.services['notification'].notify({
                        message: this.env._t("Workflow is not starting."),
                        type: 'warning',
                    });
              return;
          }
            const [{ runningworkflow_id: newActivityIds }] = await this.async(() => this.env.services.rpc({
                model: this.threadModel,
                method: 'read',
                args: [this.threadId, ['runningworkflow_id']]
            }, { shadow: true }));

            const domain = [
            ['name', '=', 'achworkflow.achrunningworkflow.form'],
            ['xml_id', '=', 'achworkflow.view_workflow_chart_form'],

            ];
            const fields=['id', 'xml_id'];
             const result = await this.async(() => this.env.services.rpc({
                model: 'ir.ui.view',
                method: 'search_read',

                kwargs: {domain,fields,},
            }, { shadow: true }));
            var viewid = 0
            result.forEach(function(item, index){
                if(item['xml_id'] == 'achworkflow.view_workflow_chart_form')
                {
                    viewid = item['id'];
                }

            })

            const action = {
                            name: 'workflow graph',
                            type: 'ir.actions.act_window',
                            res_model: 'achworkflow.achrunningworkflow',
                            res_id: newActivityIds[0],
                            context: {
                            'active_id': newActivityIds[0],
                            },

                'flags': {
                'sidebar': false, //是否显示sidebar区域(主要为action按钮)
                'pager': false,  //是否显示分页组件
                'initial_mode': 'edit', // 进入时的默认视图模式
                'form': { //表单视图的设置
                    'action_buttons': false,
                    'initial_mode': 'edit',
                    'options': {'mode': 'view'},
                }
            },
                            views: [[viewid, 'form']],
                            target: 'fullscreen'
                            };
            const options = {};
                await this.env.bus.trigger('do-action', { action, options });





//            await this.env.bus.trigger('do-action',    {
//            action: {'achworkflow.workflowchart_window_action', res_id: newActivityIds[0],},
//            options: {
//                additional_context:  {
//                                    active_id: newActivityIds[0],
//                                    res_id: newActivityIds[0],
//                                    default_id:  newActivityIds[0],
//                                    default_res_id:  newActivityIds[0],
//                                    default_active_id: newActivityIds[0],
//                                    },
//                }
//            });
        }


//-------------------------------------------------------

///

    }

    Chatter.fields = {
       
        context: attr({
            default: {},
        }),
        hasComposer: attr({
             default: false,
        }),
         hasFirstSignButton: attr({
             default: false,
        }),
        hasnormalSignButton: attr({
             default: false,
        }),
        haslastSignButton: attr({
             default: false,
        }),
        textInputContent: attr({
             default: "",
        }),
        overflag: attr({
             default: false,
        }),
        
      /**
         * Determines the `mail.activity` that belong to `this`, assuming `this`
         * has activities (@see hasActivities).
         */
        activities: one2many('achworkflow.activity', {
            inverse: 'chatter',
        }),
      
        /**
         * Determines the id of the thread that will be displayed by `this`.
         */
        threadId: attr(),
        /**
         * Serves as compute dependency.
         */
        threadModel: attr(),
        
    };

    Chatter.modelName = 'workflow.chatter';

    return Chatter;
}

registerNewModel('workflow.chatter', factory);

});
