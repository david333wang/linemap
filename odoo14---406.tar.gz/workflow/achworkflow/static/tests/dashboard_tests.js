odoo.define('achworkflow.dashboard_tests', function (require) {
"use strict";

var BoardView = require('achworkflow.BoardView');

var ListController = require('web.ListController');
var testUtils = require('web.test_utils');
var ListRenderer = require('web.ListRenderer');
var pyUtils = require('web.py_utils');

const cpHelpers = testUtils.controlPanel;
var createActionManager = testUtils.createActionManager;
var createView = testUtils.createView;

const patchDate = testUtils.mock.patchDate;

QUnit.module('achDashboard', {
    beforeEach: function () {
        this.data = {
            board: {
                fields: {
                },
                records: [
                ]
            },
            partner: {
                fields: {
                    display_name: {string: "Displayed name", type: "char", searchable: true},
                    foo: {string: "Foo", type: "char", default: "My little Foo Value", searchable: true},
                    bar: {string: "Bar", type: "boolean"},
                    int_field: {string: "Integer field", type: "integer", group_operator: 'sum'},
                },
                records: [{
                    id: 1,
                    display_name: "first record",
                    foo: "yop",
                    int_field: 3,
                }, {
                    id: 2,
                    display_name: "second record",
                    foo: "lalala",
                    int_field: 5,
                }, {
                    id: 4,
                    display_name: "aaa",
                    foo: "abc",
                    int_field: 2,
                }],
            },
        };
    },
});
//===================================================================

QUnit.test('twice the same action in a dashboard', async function (assert) {
    assert.expect(2);

    var form = await createView({
        View: BoardView,
        model: 'board',
        data: this.data,
        arch: '<form string="My Dashboard">' +
                '<board style="2-1">' +
                    '<column>' +
                        '<action context="{}" view_mode="list" string="ABC" name="51" domain="[]"></action>' +
                        '<action context="{}" view_mode="kanban" string="DEF" name="51" domain="[]"></action>' +
                    '</column>' +
                '</board>' +
            '</form>',
        mockRPC: function (route) {
            if (route === '/web/action/load') {
                return Promise.resolve({
                    res_model: 'partner',
                    views: [[4, 'list'],[5, 'kanban']],
                });
            }
            if (route === '/web/view/edit_custom') {
                assert.step('edit custom');
                return Promise.resolve(true);
            }
            return this._super.apply(this, arguments);
        },
        archs: {
            'partner,4,list':
                '<tree string="Partner"><field name="foo"/></tree>',
            'partner,5,kanban':
                '<kanban><templates><t t-name="kanban-box">' +
                    '<div><field name="foo"/></div>' +
                '</t></templates></kanban>',
        },
    });

    var $firstAction = form.$('.oe_action:contains(ABC)');
    assert.strictEqual($firstAction.find('.o_list_view').length, 1,
        "list view should be displayed in 'ABC' block");
    var $secondAction = form.$('.oe_action:contains(DEF)');
    assert.strictEqual($secondAction.find('.o_kanban_view').length, 1,
        "kanban view should be displayed in 'DEF' block");

    form.destroy();
});

//======================================================================

});

