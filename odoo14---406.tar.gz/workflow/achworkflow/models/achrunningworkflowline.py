# -*- coding: utf-8 -*-


import base64
import json
import datetime

from odoo import api, fields, models, _
from odoo.osv.query import Query
from odoo.exceptions import ValidationError, AccessError
from odoo.modules.module import get_module_resource


class achrunningworkflowline(models.Model):
    _name = 'achworkflow.achrunningworkflowline'
    _description = 'to do data of node'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'image.mixin']
    _order = 'create_date  asc'


    def _default_get_now(self):
        return datetime.now()

    name = fields.Char()
    active = fields.Boolean(default=True)

    description = fields.Text('Description', translate=True)
    state = fields.Selection([
        ('todo', 'Todo'),
        ('done', 'Done'),
        ], string='Status', index=True, tracking=1, default='todo')
    create_date = fields.Datetime(string='Creation Date', default=fields.Datetime.now(),  index=True, help="Date on which workflow request is created.")
    fininsh_date = fields.Datetime(string='Finish Date', default=fields.Datetime.now(),  index=True, help="Date on which workflow request is created.")

    authedstate = fields.Selection([
        ('todo', 'Todo'),
        ('passed', 'Passed'),
        ('reject', 'Reject'),
        ('back', 'Back'),
        ], string='auth Status',  index=True,  default='todo')

    user_id = fields.Many2one('res.users', string='node mananger', index=True,  default=lambda self: self.env.user)
    signed_txt = fields.Html('Signed txt',  required=True, default='')
    signed_image = fields.Image("sign")

    user_id_authedstate = fields.Char('user_id_authedstate', compute='_compute_user_state', store=True)

    @api.depends("user_id", "authedstate")
    def _compute_user_state(self):
        for workflowline in self:
            workflowline.user_id_authedstate = str(workflowline.user_id.id) + workflowline.authedstate

    signature = fields.Image('Signature', help='Signature received through the portal.', copy=False, attachment=True, max_width=1024, max_height=1024)
    signed_by = fields.Char('Signed By', help='Name of the person that signed the SO.', copy=False)
    signed_on = fields.Datetime('Signed On', help='Date of the signature.', copy=False)


    node_run_mode = fields.Selection([
        ('xand', 'xand'),
        ('xor', 'xor'),
        ], string='node execute mode', default='xand')

    node_key = fields.Integer(default=-1, string="node id")
    node_text = fields.Char(default="", string="node text")

    runningworkflow_id = fields.Many2one('achworkflow.achrunningworkflow', string="running workflow")
    workflow_id = fields.Integer(related='runningworkflow_id.workflow_id.id', string="workflow_id", store=True)

    workflow_name = fields.Char(related='runningworkflow_id.workflow_type_nm', string="workflow_name", store=True)

    workflow_sequence = fields.Char(related='runningworkflow_id.workflow_sequence', string="workflow_sequence",
                                    store=True)
    def button_approve(self):
        # if not self.signature:
        #     return {
        #         'warning': {
        #             'title': _('Requested create.'),
        #             'message': _("The delivery date is sooner than the expected date."
        #                          "You may be unable to honor the delivery date.")
        #         }
        #     }

        workflowobj = self.env['achworkflow.achrunningworkflow']
        v1 = {
            'authedstate': 'passed',


        }
        workflowid = self.workflow_id
        workflow_sn = self.workflow_sequence
        achrunningworkflowid = self.runningworkflow_id.id
        runingworkflowlineid = self.id

        workflowobj.triggerWorkflow(workflowid, workflow_sn, achrunningworkflowid, False, runingworkflowlineid, v1)
        return {
            'warning': {
                'title': _('Requested create.'),
                'message': _("The delivery date is sooner than the expected date."
                             "You may be unable to honor the delivery date.")
            }
        }

    def button_reject(self):
        workflowobj = self.env['achworkflow.achrunningworkflow']
        v1 = {
            'authedstate': 'reject',

        }
        workflowid = self.workflow_id
        workflow_sn = self.workflow_sequence
        achrunningworkflowid = self.runningworkflow_id.id
        runingworkflowlineid = self.id

        workflowobj.triggerWorkflow(workflowid, workflow_sn, achrunningworkflowid, False, runingworkflowlineid, v1)
        return {
            'warning': {
                'title': _('Requested create.'),
                'message': _("The delivery date is sooner than the expected date."
                             "You may be unable to honor the delivery date.")
            }
        }





    # ==================================================================
    #

    def button_approve_ui(self):
        # if not self.signature:
        #     return {
        #         'warning': {
        #             'title': _('Requested create.'),
        #             'message': _("The delivery date is sooner than the expected date."
        #                          "You may be unable to honor the delivery date.")
        #         }
        #     }

        workflowobj = self.env['achworkflow.achrunningworkflow']
        v1 = {
            'authedstate': 'passed',


        }
        workflowid = self.workflow_id
        workflow_sn = self.workflow_sequence
        achrunningworkflowid = self.runningworkflow_id.id
        runingworkflowlineid = self.id

        workflowobj.triggerWorkflow(workflowid, workflow_sn, achrunningworkflowid, False, runingworkflowlineid, v1)

        return {'type': 'ir.actions.act_window_close'}

    def button_reject_ui(self):
        workflowobj = self.env['achworkflow.achrunningworkflow']
        v1 = {
            'authedstate': 'reject',

        }
        workflowid = self.workflow_id
        workflow_sn = self.workflow_sequence
        achrunningworkflowid = self.runningworkflow_id.id
        runingworkflowlineid = self.id

        workflowobj.triggerWorkflow(workflowid, workflow_sn, achrunningworkflowid, False, runingworkflowlineid, v1)

        return {'type': 'ir.actions.act_window_close'}



    @api.model
    def create(self, values):
        # ===================
        # 这是管理员给流程增加待办＝＝＝＝＝＝＝＝
        if 'runworkflowid' in self.env.context:
            runningworkflowid = self.env.context['runworkflowid']
            if not runningworkflowid:
                runningworkflowid = 0
            workflowlineobj = self.env['achworkflow.achrunningworkflowline'].sudo().search([('runningworkflow_id', '=', runningworkflowid), ('state', '=', 'todo')])
            if workflowlineobj:
                for wline in workflowlineobj:
                    if values['user_id'] == wline.user_id.id:
                        raise ValidationError(_("Insert same man in node. (%s)", values['user_id']))
                        return False
                    node_run_mode = wline.node_run_mode
                    node_key = wline.node_key
                    node_text = wline.node_text

                newvalue = {
                    'name': runningworkflowid,
                    'state': 'todo',
                    'runningworkflow_id': runningworkflowid,
                    'authedstate': 'todo',
                    'node_run_mode': node_run_mode,
                    'node_key': node_key,
                    'user_id': values['user_id'],
                    'node_text': node_text}
                self.workflow_message(runningworkflowid, values['user_id'])
                self.workflow_activity(runningworkflowid, values['user_id'])

                values = newvalue
        # =============================================================
        # 这增加消息和规划 4.2 2022
        if 'runningworkflow_id' in values:
            if 'user_id' in values:
                runningworkflowid = values.get('runningworkflow_id')
                self.workflow_message(runningworkflowid, values['user_id'])
                self.workflow_activity(runningworkflowid, values['user_id'])

        res = super(achrunningworkflowline, self).create(values)
        return res

#    ==============================================================
#     add message support and activity activity_schedule
#     fixed time 4-2 -2022
#     =========================================================
    def workflow_message(self, runworkflowid, userid):
        if self.env.uid == userid:
            return
        if not self.env['ir.config_parameter'].sudo().get_param('achworkflow.workflowmessageflag', False):
            return

        if runworkflowid:
            obj_rww = self.env['achworkflow.achrunningworkflow']
            obj_ww_link = self.env['achworkflow.achworkflowtypelinkmodel']
            obj_users = self.env['res.users']

            workflowlineobj = obj_rww.sudo().search([('id', '=', runworkflowid)], limit=1)
            if workflowlineobj:
                workflow_id = workflowlineobj.workflow_id.id
                workflowlineobj = obj_ww_link.sudo().search([('workflow_id', '=', workflow_id), ('status', '=', 'run')], limit=1)
                if workflowlineobj:
                    model_name = workflowlineobj.model_name
                    obj_run = self.env[model_name].sudo().search([('runningworkflow_id', '=', runworkflowid)])
                    if obj_run:
                        odoobot = self.env.ref('base.partner_root')
                        if userid:
                            userids = obj_users.sudo().search([('id', '=', userid)])
                        # ======================== send message
                        if userids:
                            obj_run.message_subscribe(partner_ids=userids.partner_id.ids)
                        refs = [
                            "<a href=# data-oe-model=%s data-oe-id=%s>%s</a>" % (model_name, obj_run.id, obj_run.name)]
                        message = _("This  bill is from: %s") % ','.join(refs)

                        obj_run.message_post(body=message,
                                          message_type='comment',
                                          subtype_xmlid='mail.mt_note',
                                          author_id=odoobot.id)

    def workflow_activity(self, runworkflowid, userid):
        if self.env.uid == userid:
            return

        if not self.env['ir.config_parameter'].sudo().get_param('achworkflow.workflowactivityflag', False):
            return
        hour_add = self.env['ir.config_parameter'].sudo().get_param('achworkflow.workflowactivityhour', 2)
        if hour_add:
            expiration_date = fields.datetime.now() + datetime.timedelta(hours=int(hour_add))
        else:
            expiration_date = fields.datetime.now()

        if runworkflowid:
            obj_rww = self.env['achworkflow.achrunningworkflow']
            obj_ww_link = self.env['achworkflow.achworkflowtypelinkmodel']
            obj_users = self.env['res.users']

            workflowlineobj = obj_rww.sudo().search([('id', '=', runworkflowid)], limit=1)
            if workflowlineobj:
                workflow_id = workflowlineobj.workflow_id.id
                workflowlineobj = obj_ww_link.sudo().search([('workflow_id', '=', workflow_id), ('status', '=', 'run')],
                                                            limit=1)
                if workflowlineobj:
                    model_name = workflowlineobj.model_name
                    obj_run = self.env[model_name].sudo().search([('runningworkflow_id', '=', runworkflowid)])
                    if obj_run:
                        if userid:
                            userids = obj_users.sudo().search([('id', '=', userid)], limit=1)
                        # ======================== send message
                        if userids:
                            refs = [
                                "<a href=# data-oe-model=%s data-oe-id=%s>%s</a>" % (model_name, obj_run.id, obj_run.name)]
                            message = _("This  bill is from: %s") % ','.join(refs)

                            create_vals = {
                                'activity_type_id': self.env.ref('mail.mail_activity_data_todo').id,
                                'summary': message,
                                'automated': True,
                                'note': '',
                                'date_deadline': expiration_date,
                                'res_model_id': workflowlineobj.model_id.id,
                                'res_id': obj_run.id,
                                'user_id': userids.id
                            }
                            self.env['mail.activity'].sudo().create(create_vals)


    # ======================================================================================
# code 9-18
# =======================================================================
    def workflowline_format(self):
        workflowlines = self.read()
        return workflowlines
# ========================================================================================
# code 9-19
# ==================================================================================
    def workflowline_judge(self):
        lastnodekey = self.env['ir.config_parameter'].sudo().get_param('achworkflow.workflowlastnodekey')
        workflowlines = self.read()
        if workflowlines:
            for workflowline in workflowlines:
                if workflowline['user_id'][0] == self.env.uid and workflowline['state'] == 'todo':
                    if str(workflowline['node_key']) == lastnodekey:
                        return 4
                    else:
                        return 3
        else:
            # 上面是起始节点
            return 1
        #
        return 2