# -*- coding: utf-8 -*-

from odoo import models, fields, api


class achworkflowudf(models.Model):
    _name = 'achworkflow.achworkflowudf'
    _description = 'achworkflowudf'

    name = fields.Char()

    active = fields.Boolean(default=True)

    status = fields.Selection([
        ('run', 'run'),
        ('pause', 'pause')
    ], default='run', tracking=True)

    englishlbl = fields.Char(string="par name")

    workflow_id = fields.Many2one('achworkflow.achworkflow', string="workflow udf")
