# -*- coding: utf-8 -*-


import base64
import json


from odoo import api, fields, models, _
from odoo.osv.query import Query
from odoo.exceptions import ValidationError, AccessError
from odoo.modules.module import get_module_resource

class achworkflow(models.Model):
    _name = 'achworkflow.achworkflow'
    _description = 'achworkflow.achworkflow'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'resource.mixin',  'image.mixin']

    @api.model
    def _default_image(self):
        image_path = get_module_resource('achworkflow', 'static/src/img', 'default_image.png')
        return base64.b64encode(open(image_path, 'rb').read())

    name = fields.Char()
    chart = fields.Char(string="Chart", required=True)

    chart_modified = fields.Char(string="Chartcheck")

    active = fields.Boolean(default=True)


    sequence = fields.Integer('Sequence', default=1, help='Gives the no')
    description = fields.Text('Description', translate=True)

    categ_id = fields.Many2one(
        'achworkflow.achworkflowtype', 'Workflow Category',
        change_default=True,
        required=True, help="Select category for the current Workflow")

    categ_name = fields.Char(related="categ_id.name", store=True)

    categ_simplename = fields.Char(related="categ_id.simplename", store=True)

    image_1920 = fields.Image(default=_default_image)

    udf_ids = fields.One2many('achworkflow.achworkflowudf', 'workflow_id', string='workflow running parameter tree')

    node_ids = fields.One2many('achworkflow.achworkflownode', 'workflow_id', string='workflow running  tree')
    node_lineids = fields.One2many('achworkflow.achworkflowline', 'workflow_id', string='workflow running  tree')

    workflow_sn = fields.Char("workflow no")

    workflow_evaluate_field = fields.Char("workflow evalulate field")
    workflow_evaluate_flag = fields.Boolean("workflow evaluate", default=False)

    workflow_option_flag = fields.Boolean("workflow option", default=False)
    workflow_option1_flag = fields.Boolean("workflow option 1", default=False)
    workflow_option2_flag = fields.Boolean("workflow option 2", default=False)
    workflow_option3_flag = fields.Boolean("workflow option 3", default=False)
    workflow_option4_flag = fields.Boolean("workflow option 4", default=False)
    workflow_option5_flag = fields.Boolean("workflow option 5", default=False)
    workflow_option6_flag = fields.Boolean("workflow option 6", default=False)


    request_to_workflow_count = fields.Integer(string="Tasks in workflow", compute='_compute_runworkflow_count')


    runningworkflow_id = fields.One2many('achworkflow.achrunningworkflow', 'workflow_id', string="workflow")

    @api.depends('runningworkflow_id')
    def _compute_runworkflow_count(self):
        self.request_to_workflow_count = 0
        for wokflow in self:
            wokflow.request_to_workflow_count = self.env['achworkflow.achrunningworkflow'].search_count([('workflow_id', '=', wokflow.id),
                                                                                                         ('state', '=', 'run')
                                                                                                         ])

    request_to_myworkflowline_count = fields.Integer(string="Tasks in workflow", compute='_compute_myrunworkflowline_count')

    @api.depends('runningworkflow_id')
    def _compute_myrunworkflowline_count(self):
        # self.request_to_myworkflowline_count = 0
        for workflow in self:
            todonum = self.env['achworkflow.achrunningworkflowline'].sudo().search_count(
                [('workflow_id', '=', workflow.id),
                 ('state', '=', 'todo'),
                 ('authedstate', '=', 'todo'),
                 ('user_id', '=', self.env.uid)

                 ])
            workflow.update({'request_to_myworkflowline_count': todonum})

    request_to_myworkflowlinedid_count = fields.Integer(string="Tasks in workflow",
                                                     compute='_compute_myrunworkflowlinedid_count')

    @api.depends('runningworkflow_id')
    def _compute_myrunworkflowlinedid_count(self):
        # self.request_to_myworkflowlinedid_count = 0
        for workflow in self:
            domain1 = [('workflow_id', '=', workflow.id),
                 ('state', '=', 'done'),
                 ('user_id', '=', self.env.uid)
                 ]

            runningworklines = self.env['achworkflow.achrunningworkflowline'].sudo().search(domain1)
            if runningworklines:
                workflow.update({'request_to_myworkflowlinedid_count': len(runningworklines.mapped('runningworkflow_id'))})
            else:
                workflow.update({'request_to_myworkflowlinedid_count': 0})



    # ------------------------------------------------------------------
    # test
    # ---------------------------------------------------------------------
    def action_run_test_workflow(self):
        workflowobj = self.env['achworkflow.achrunningworkflow']
        running_workflow_table = {'line': 1}
        workflowid = self.id
        workflow_sn = self.workflow_sn
        workflownm = self.name
        workflowobj.triggerWorkflow(workflowid, workflow_sn, 0, True, 0, {'workflow_running_table': running_workflow_table, 'name': workflownm})
        # v1 = {
        #     'authedstate': 'passed'
        # }
        # workflowobj.triggerWorkflow(1, '00001', 1, False, -2, v1)
        return {
            'warning': {
                'title': _('Requested create.'),
                'message': _("The delivery date is sooner than the expected date."
                             "You may be unable to honor the delivery date.")
            }
        }

    def action_remove_test_workflow(self):
        workflowobjs = self.env['achworkflow.achrunningworkflow'].search([('workflow_id', '=', self.id),
                                                                          ('debugflag', '=', True)
                                                                          ])
        for workflowobj in workflowobjs:
            workflowobj.mapped("runningworkflowline_ids").unlink()
            workflowobj.unlink()

    def format_workflowstr(self, json_str):
        objworkflow = json.loads(json_str)
        lastnodekey = -100
        if objworkflow:
            if ('class' in objworkflow):
                if objworkflow['class'] == 'GraphLinksModel':
                    if ('nodeDataArray' in objworkflow):
                        nodeDataArray = objworkflow['nodeDataArray']
                        for node in nodeDataArray:
                            if node['text'] == 'End' or node['text'] == '结束':
                                lastnodekey = node['key']
                                break
        json_str = json_str.replace('"key":'+str(lastnodekey), '"key":-1000')
        json_str = json_str.replace('"to":' + str(lastnodekey), '"to":-1000')
        return json_str
    # ------------------------------------------------------------------
    #  CRUN
    # ---------------------------------------------------------------------
    @api.model
    def create(self, values):
        values['workflow_sn'] = self.env[
            'ir.sequence'].next_by_code('workflow.wfsequence')
        workflowchart = values['chart']
        workflowchart = self.format_workflowstr(workflowchart)
        values['chart_modified'] = workflowchart
        res = super(achworkflow, self).create(values)
        if workflowchart:
        #     deal with chart
            workflowid = res.id
            self._workwithchartforecreate(workflowchart, workflowid)
        return res
    def write(self, values):
        modifiedflag = False
        if 'chart' in values:
            workflowchart = values['chart']
            workflowchart = self.format_workflowstr(workflowchart)
            workflowchartmodified = self.chart_modified
            if workflowchart != workflowchartmodified:
                modifiedflag = True
                values['chart_modified'] = workflowchart
        res = super(achworkflow, self).write(values)

        if modifiedflag:
            #     deal with chart
            if workflowchart:
                workflowid = self.id
                self._workwithchartforedit(workflowchart, workflowid)
        return res

    def _workwithchartforedit(self, json_str, workflowid=0):
        nodess = self.env['achworkflow.achworkflownode'].search([('active', '=', 'True'), ('workflow_id', '=', workflowid)])
        for node1 in nodess:
            node1.write({'active': False})
            node1.mapped("appover_ids").write({'active': False})

        liness = self.env['achworkflow.achworkflowline'].search(
            [('active', '=', 'True'), ('workflow_id', '=', workflowid)])
        for line1 in liness:
            line1.write({'active': False})
            line1.mapped("linejudge_ids").write({'active': False})

        objworkflow = json.loads(json_str)
        if objworkflow:
            if ('class' in objworkflow):
                if objworkflow['class'] == 'GraphLinksModel':
                    if ('nodeDataArray' in objworkflow):
                        nodeDataArray = objworkflow['nodeDataArray']
                        for node in nodeDataArray:
                            # if node['text'] == '节点':
                            #     str_node_category = 'node'
                            # else:
                            #     str_node_category = node['category']
                            str_node_category = node['category']
                            str_node_category = str_node_category.lower()
                            str_node_key = node['key']
                            str_node_text = node['text']

                            # print(str_node_category)
                            # print(str_node_key)
                            # print(str_node_text)
                            self.env['achworkflow.achworkflownode'].create({
                                'workflow_id': workflowid,
                                'name': str_node_text,
                                'node_text': str_node_text,
                                'node_key': str_node_key,
                                'node_category': str_node_category

                            })

                    if ('linkDataArray' in objworkflow):
                        linkDataArray = objworkflow['linkDataArray']
                        if len(linkDataArray) ==0:
                            raise ValidationError(_("no Link "))
                            return
                        for link in linkDataArray:
                            fromnode = link['from']
                            tonode = link['to']
                            linktext = ''
                            if ('text' in link):
                                linktext = link['text']
                            nodeDataArray = objworkflow['nodeDataArray']
                            # search node name by node key
                            for node in nodeDataArray:
                                if node['key'] == fromnode:
                                    node_from_nm = node['text']
                                    break
                            for node in nodeDataArray:
                                if node['key'] == tonode:
                                    node_to_nm = node['text']
                                    break

                            # print(fromnode, tonode, linktext)
                            self.env['achworkflow.achworkflowline'].create({
                                'workflow_id': workflowid,
                                'name': workflowid,
                                'node_line_from': fromnode,
                                'node_line_to': tonode,
                                'node_line_text': linktext,
                                'node_from_nm': node_from_nm,
                                'node_to_nm': node_to_nm

                            })

    def _workwithchartforecreate(self, json_str, workfowid):
        objworkflow = json.loads(json_str)

        if objworkflow:
            if ('class' in objworkflow):
                if objworkflow['class'] == 'GraphLinksModel':
                    if ('nodeDataArray' in objworkflow):
                        nodeDataArray = objworkflow['nodeDataArray']
                        for node in nodeDataArray:
                            # if node['text'] == '节点':
                            #     str_node_category = 'node'
                            # else:
                            #     str_node_category = node['category']
                            str_node_category = node['category']
                            str_node_category = str_node_category.lower()
                            str_node_key = node['key']
                            str_node_text = node['text']

                            # print(str_node_category)
                            # print(str_node_key)
                            # print(str_node_text)
                            self.env['achworkflow.achworkflownode'].create({
                                'workflow_id': workfowid,
                                'name': str_node_text,
                                'node_text': str_node_text,
                                'node_key': str_node_key,
                                'node_category': str_node_category

                            })
                    if ('linkDataArray' in objworkflow):
                        linkDataArray = objworkflow['linkDataArray']
                        if len(linkDataArray) == 0:
                            raise ValidationError(_("no Link "))
                            return
                        for link in linkDataArray:
                            fromnode = link['from']
                            tonode = link['to']
                            linktext = ''
                            if ('text' in link):
                                linktext = link['text']
                            nodeDataArray = objworkflow['nodeDataArray']
                            node_from_nm = ''
                            node_to_nm = ''

                            # search node name by node key
                            for node in nodeDataArray:
                                if node['key'] == fromnode:
                                    node_from_nm = node['text']
                                    break
                            for node in nodeDataArray:
                                if node['key'] == tonode:
                                    node_to_nm = node['text']
                                    break


                            # print(fromnode, tonode, linktext)
                            self.env['achworkflow.achworkflowline'].create({
                                'workflow_id': workfowid,
                                'name': workfowid,
                                'node_line_from': fromnode,
                                'node_line_to': tonode,
                                'node_line_text': linktext,
                                'node_from_nm': node_from_nm,
                                'node_to_nm': node_to_nm

                            })


