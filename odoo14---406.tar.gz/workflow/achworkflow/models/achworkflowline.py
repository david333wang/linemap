# -*- coding: utf-8 -*-


import base64
from random import choice
from string import digits
from werkzeug.urls import url_encode


from odoo import api, fields, models, _
from odoo.osv.query import Query
from odoo.exceptions import ValidationError, AccessError
from odoo.modules.module import get_module_resource


class achworkflowline(models.Model):
    _name = 'achworkflow.achworkflowline'
    _description = 'achworkflow.achworkflowline'
    _order = "id"

    workflow_id = fields.Many2one('achworkflow.achworkflow', string="workflow")

    name = fields.Char()
    active = fields.Boolean(default=True)

    node_line_from = fields.Integer(default=-1, string="from node")
    node_line_to = fields.Integer(default=-1, string="to node")
    node_line_text = fields.Char(string="text")
    node_from_nm = fields.Char()
    node_to_nm = fields.Char()

    linejudge_ids = fields.One2many('achworkflow.achworkflowlinejudge', 'workflow_line_id', string='node line expression')




