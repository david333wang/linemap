# -*- coding: utf-8 -*-




from odoo import api, fields, models, _
from odoo.exceptions import UserError



class achrworkflowmixin(models.AbstractModel):
    _name = 'achworkflow.achrworkflowmixin'
    _description = 'runningworkflowmixin'
    _order = 'id desc'
    _inherit = ['resource.mixin', 'image.mixin']

    # ========================================================================

    workflowmixin_company_id = fields.Many2one('res.company', string='Company', required=True, readonly=True, default=lambda self: self.env.company)
    workflow_watermark_image = fields.Image(related="workflowmixin_company_id.workflow_watermark_image", readonly=False)

    # ===============================
    runningworkflow_id = fields.Many2one('achworkflow.achrunningworkflow', string="running workflow")
    workflow_id = fields.Integer(related='runningworkflow_id.workflow_id.id', string="workflow_id", store=True)
    finished_chart = fields.Char(related='runningworkflow_id.finished_chart', string="finished_chart", store=True)
    workflow_sn = fields.Char(related='runningworkflow_id.workflow_sn', string="workflow_sn", store=True)
    workflow_evaluate_field = fields.Char(related='runningworkflow_id.workflow_evaluate_field', string="workflow_evaluate_field", store=True)
    workflow_current_node_key = fields.Integer(related='runningworkflow_id.workflow_current_node_key', string="workflow_current_node_key", store=True)

    workflowline_ids = fields.One2many('achworkflow.achrunningworkflowline',  compute='_compute_line_ids', string="workflowlines")
    #
    @api.depends("runningworkflow_id")
    def _compute_line_ids(self):
        for workflow in self:
            if workflow.runningworkflow_id:
                workflow.workflowline_ids = workflow.runningworkflow_id.runningworkflowline_ids


    # ========================================================
    #
    # ========================================================



    # ========================================================
    #
    # ========================================================

    def action_trigger_achworkflow_workflow(self):
        self.mapped("runningworkflow_id").triggerActiveWorkflow()
        return self

    # -----------------------------------------------------------
    # workflow status :defualt true ,has no workflow attached
    # -----------------------------------------------------------------
    def _get_running_workflow_status(self):
        if len(self.runningworkflow_id) > 0:
            workflow_over_exec_resultflag = self.runningworkflow_id.workflow_id.workflowover_evaluate_flag
            if workflow_over_exec_resultflag:
                if self.runningworkflow_id.state in ('evalated', 'pendding'):
                    return True
                else:
                    return False
            else:
                if self.runningworkflow_id.state in ('run', 'done', 'cancel'):
                    return False

        return True
    # -----------------------------------------------------------
    # CRUD
    # -----------------------------------------------------------------
    @api.model
    def create(self, vals):
        workflowlinkmodelobjs = self.env['achworkflow.achworkflowtypelinkmodel'].search(
            [('model_id.model', '=', self._name), ('status', '=', 'run'), ('active', '=', True)], limit=1)
        # form save and trigger workflow flag ,default =true
        # savetriggerworkflowflag = True
        # if workflowlinkmodelobjs:
        #     for workflowlinkformobj in workflowlinkmodelobjs:
        #         savetriggerworkflowflag = workflowlinkformobj.savetriggerworkflowflag
        #
        # if not savetriggerworkflowflag:
        #    return super(achrworkflowmixin, self).create(vals)
        # ==================================

        workflowobj = self.env['achworkflow.achrunningworkflow']

        # -------------------------------------------------------------
        workflowlinkmodelobjs = self.env['achworkflow.achworkflowtypelinkmodel'].search([('model_id.model', '=', self._name), ('status', '=', 'run'), ('active', '=', True)], limit=1)
        if workflowlinkmodelobjs:
            for workflowlinkformobj  in workflowlinkmodelobjs:
                workflowid = workflowlinkformobj.workflow_id.id
        else:
            raise UserError(_('%s,form not link workflow', 0))
            return False


            # 给运行的workflow增加运行值
        running_workflow_table = {}
        rs_workflow = self.env['achworkflow.achworkflow'].sudo().browse(workflowid)
        if rs_workflow:
            for workflow_udf in rs_workflow.udf_ids:
                str_udf = workflow_udf.name
                if vals.__contains__(str_udf):
                    running_workflow_table[str_udf] = vals.get(str_udf, '')
        # ------------------------------------------------------------------------
        workflow_sn = ''
        workflownm = '%s ' % (vals['name'])
        runworkflowid = workflowobj.sudo().triggerBlankWorkflow(workflowid, workflow_sn, 0, False, 0, {'workflow_running_table': running_workflow_table, 'name': workflownm})
        if runworkflowid == None:
            raise UserError(_('%s,mixin workflow can not create', 0))
        vals['runningworkflow_id'] = runworkflowid
        res = super(achrworkflowmixin, self).create(vals)
        return res


    def write(self, vals):
        if self.runningworkflow_id:
            # if self.runningworkflow_id.state in ('done'):
            #     if 'state' in vals:
            #         newsate = vals['state']
            #         vals.clear()
            #         vals['state'] = newsate
            # ('draft', 'draft'),
            # ('run', 'runing'),
            # ('pendding', 'dendding'),
            # ('done', 'done'),
            # ('cancel', 'cancelled'),
            # ('evalated', 'evalated'),
            # DRAFT PEDDING 是一样的，RUNNING运行中，done是结束，如果是评价流程的话，可以修改评价字段
            if self.runningworkflow_id.state == 'draft':
                pass
            elif self.runningworkflow_id.state == 'pedding':
                pass
            elif self.runningworkflow_id.state == 'done':
                if not self.runningworkflow_id.workflow_evaluate_flag:
                    raise UserError(_('%s workflow does not support evaluate', self.runningworkflow_id.id))
            elif self.runningworkflow_id.state == 'run':
                raise UserError(_('%s workflow is running now. ', self.runningworkflow_id.id))
            elif self.runningworkflow_id.state == 'cancel':
                raise UserError(_('%s workflow cancelled now. ', self.runningworkflow_id.id))



            # form name submit to workflow name

            if 'name' in vals:
                self.runningworkflow_id.write({'name': vals['name']})
            # ---------------------------------------------------------------------
            #  code 2021 -10 -3 add evalate function
            if (self.runningworkflow_id.state in ('done')) and self.runningworkflow_id.workflow_evaluate_flag:
                protected_fields = self._get_write_fields()
                for p in self.fields_get():
                    if p in vals:
                        if p not in protected_fields:
                            vals.pop(p)
            else:
                # code 2021-10-3 add evalate function
                # -------------------------------------------------------------
                # fixed by-923
                # 给运行的workflow增加运行值
                running_workflow_table = {}
                rs_workflow = self.runningworkflow_id.workflow_id

                if rs_workflow:
                    for workflow_udf in rs_workflow.udf_ids:
                        str_udf = workflow_udf.name
                        if vals.__contains__(str_udf):
                            running_workflow_table[str_udf] = vals.get(str_udf)

                self.runningworkflow_id.write({'workflow_running_table': running_workflow_table})

        res = super(achrworkflowmixin, self).write(vals)
        return res


    def unlink(self):
        if len(self.runningworkflow_id) > 0:
            if self.runningworkflow_id.state in ('run', 'done', 'cancel'):
                raise UserError(_('%s workflow is running now.  ', self.runningworkflow_id.id))
        res = super(achrworkflowmixin, self).unlink()
        return res

    def _get_write_fields(self):
        if self.workflow_evaluate_field == '':
            return {}
        return eval(self.workflow_evaluate_field)
    # =====================================support attachment=====================================

    # ==========================================down ========================================

    workflow_attachment_ids = fields.One2many('ir.attachment', compute='_compute_mixin_attachment_ids', string="Main Attachments",
                                     help="Attachment that don't come from message.")

    workflow_doc_count = fields.Integer(compute='_compute_mixin_attached_docs_count', string="Number of documents attached")

    def _compute_mixin_attachment_ids(self):
        for wk in self:
            attachment_ids = self.env['ir.attachment'].search([('res_id', '=', wk.id),
                                                               ('res_model', '=', self._name)]).ids
            # message_attachment_ids = wk.mapped('message_ids.attachment_ids').ids  # from mail_thread
            # wk.attachment_ids = [(6, 0, list(set(attachment_ids) - set(message_attachment_ids)))]
            wk.workflow_attachment_ids = attachment_ids

    def _compute_mixin_attached_docs_count(self):
        Attachment = self.env['ir.attachment']
        for wk in self:
            wk.workflow_doc_count = Attachment.search_count([

                ('res_model', '=', self._name), ('res_id', '=', wk.id),

            ])

    @api.model
    def workflow_attachment_tree_view(self, args=None):
        action = self.env['ir.actions.act_window']._for_xml_id('base.action_attachment')
        res_id = self.env.context['default_res_id']


        action['domain'] = str([

            '&',
            ('res_model', '=', self._name),
            ('res_id', '=', res_id)
        ])
        action['res_id'] = res_id
        if self._get_running_workflow_status():
            action['context'] = "{'default_res_model': '%s','default_res_id': %d}" % (self._name, res_id)
        else:
            action['context'] = "{'create':False,'edit':False, 'delete':False,  'default_res_model': '%s','default_res_id': %d}" % (self._name, res_id)

        return action
    # ==========================================up ========================================

    # =====================================support first workflow action=====================================
    # 激活工作流－审批start

    @api.returns('achworkflow.achrunningworkflow', lambda value: value.id)
    def trigger_message_post(self, *args, **kwargs):
        self.ensure_one()  # should always be posted on a record, use message_notify if no record
        # split message additional values from notify additional values
        msg_kwargs = dict((key, val) for key, val in kwargs.items())
        # Explicit access rights check, because display_name is computed as sudo.
        self.check_access_rights('read')
        self.check_access_rule('read')

        values = dict(msg_kwargs)

        res_id = values.get('threadId')
        res_model_name = values.get('threadModel')
        signed_txt = values.get('signed_txt')
        if signed_txt == '':
            signed_txt = 'check'
        return self._trigger_achworkflow_workflow(signed_txt, res_model_name, res_id)

    def _trigger_achworkflow_workflow(self, signed_txt, res_model_name='', res_id=0):
        existing_obj = self.env[res_model_name].sudo().browse(res_id)
        if existing_obj:
            workfflow = existing_obj.mapped("runningworkflow_id")
            existing_obj.mapped("runningworkflow_id").triggerActiveWorkflow(signed_txt)

        return workfflow


    @api.returns('achworkflow.achrunningworkflow', lambda value: value.id)
    def triggerWorkflowAction(self, *args, **kwargs):
        self.ensure_one()  # should always be posted on a record, use message_notify if no record
        # split message additional values from notify additional values
        msg_kwargs = dict((key, val) for key, val in kwargs.items())
        # Explicit access rights check, because display_name is computed as sudo.
        self.check_access_rights('read')
        self.check_access_rule('read')

        values = dict(msg_kwargs)
        action =values.get('waction')
        res_id = values.get('threadId')
        res_model_name = values.get('threadModel')
        signed_txt = values.get('signed_txt')
        return self._trigger_achworkflow_workflow_action(signed_txt, res_model_name, res_id, action)

    def _trigger_achworkflow_workflow_action(self, signed_txt, res_model_name='', res_id=0, action=''):
        existing_obj = self.env[res_model_name].sudo().browse(res_id)
        if existing_obj:
            workfflow = existing_obj.mapped("runningworkflow_id")
            existing_obj.mapped("runningworkflow_id").triggerWorkflowAction(signed_txt, action, res_id)

        return workfflow



# ======================================================================================
# code 2021-3-18
# ======================================================================================
    def workflow_format(self):
        pass
# ------------------------------------------------------------------------
# code-9-23
#
# ------------------------------------------------------------------------
    def _feed_running_workflow_pate(self):
        pass