# -*- coding: utf-8 -*-


import base64
from random import choice
from string import digits
from werkzeug.urls import url_encode


from odoo import api, fields, models, _
from odoo.osv.query import Query
from odoo.exceptions import ValidationError, AccessError
from odoo.modules.module import get_module_resource


class achworkflownode(models.Model):
    _name = 'achworkflow.achworkflownode'
    _description = 'achworkflow.achworkflownode'

    workflow_id = fields.Many2one('achworkflow.achworkflow', string="workflow")

    name = fields.Char()
    active = fields.Boolean(default=True)

    node_category = fields.Selection([
        ('start', 'start'),
        ('node', 'node'),
        ('conditional', 'Conditional'),
        ('end', 'end'),
        ('coment', 'coment'),
    ], 'node type', default='start')

    node_run_mode = fields.Selection([
        ('xand', 'xand'),
        ('xor', 'xor'),

    ], 'node run mode', default='xand')

    nodedate = fields.Datetime('node date', default=fields.Datetime.now)

    node_key = fields.Integer(default=-1, string="node id")
    node_text = fields.Char(string="node label")

    appover_ids = fields.One2many('achworkflow.achworkflownodeappover', 'workflow_node_id', string='node executor')
    sameDepartment = fields.Boolean(default=False, string='same department')
    sameCompany = fields.Boolean(default=False, string='same company')
    tostarter = fields.Boolean(default=False, string='to starter')




