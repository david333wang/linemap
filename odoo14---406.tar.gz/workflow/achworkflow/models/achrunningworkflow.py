# -*- coding: utf-8 -*-


import base64
import json
import ast
from datetime import date, datetime, time


from odoo import api, fields, models, _
from odoo.osv.query import Query
from odoo.exceptions import ValidationError, AccessError
from odoo.modules.module import get_module_resource
from odoo.exceptions import UserError


class achrunningworkflow(models.Model):
    _name = 'achworkflow.achrunningworkflow'
    _description = '此类提供运行WORKFLOW的主体'
    _order = 'id desc'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'image.mixin']


    name = fields.Char()

    active = fields.Boolean(default=True)

    description = fields.Text('Description', translate=True)

    debugflag = fields.Boolean(default=False)

    state = fields.Selection([
        ('draft', 'draft'),
        ('run', 'runing'),
        ('pendding', 'dendding'),
        ('done', 'done'),
        ('cancel', 'cancelled'),
        ('evalated', 'evalated'),

    ], string='Status', readonly=True, copy=False, index=True, tracking=1, default='run')


    user_id = fields.Many2one('res.users', string='workflow starter', index=True, default=lambda self: self.env.user)
    runningworkflowline_ids = fields.One2many('achworkflow.achrunningworkflowline', 'runningworkflow_id', string="workflowlines")
    workflow_running_table = fields.Char(default='')
    workflow_id = fields.Many2one('achworkflow.achworkflow', string="workflow")
    workflow_type_nm = fields.Char(related='workflow_id.categ_name', string="workflow type name", store=True)
    workflow_type_smn = fields.Char(related='workflow_id.categ_simplename', string="workflow type simple name", store=True)
    workflow_sn = fields.Char(related='workflow_id.workflow_sn', string="workflow sn", store=True)
    chart = fields.Char(related='workflow_id.chart', string="workflow chart", store=True)

    finished_chart = fields.Char(string="workflow finishing chart")

    workflow_evaluate_flag = fields.Boolean(related='workflow_id.workflow_evaluate_flag', string="workflow eval", store=True)
    workflow_evaluate_field = fields.Char(related='workflow_id.workflow_evaluate_field', string="workflow eval string", store=True)
    workflow_option1_flag = fields.Boolean(related='workflow_id.workflow_option1_flag', string="workflow_option1_flag", store=True)
    workflow_option2_flag = fields.Boolean(related='workflow_id.workflow_option2_flag', string="workflow_option2_flag", store=True)
    workflow_option3_flag = fields.Boolean(related='workflow_id.workflow_option3_flag', string="workflow_option2_flag", store=True)
    workflow_option4_flag = fields.Boolean(related='workflow_id.workflow_option4_flag', string="workflow_option2_flag", store=True)
    workflow_option5_flag = fields.Boolean(related='workflow_id.workflow_option5_flag', string="workflow_option2_flag", store=True)
    workflow_option6_flag = fields.Boolean(related='workflow_id.workflow_option6_flag', string="workflow_option2_flag", store=True)
    workflow_sequence = fields.Char("running workflow sequence")
    workflow_current_node = fields.Char(default="start", string="workflow current node")
    workflow_current_node_key = fields.Integer(default=-1, string="workflow current node key")
    create_date = fields.Datetime(string='Creation Date',  default=fields.Datetime.now, readonly=True, index=True, help="Date on which workflow request is created.")
    finish_date = fields.Datetime(string='Finish Date', default=fields.Datetime.now, readonly=True, index=True, help="Date on which workflow request is created.")


    # =====================================================above=============================
    # change form style
    # 2021-6-14 add




    # ====== 6-14 code added

    # ===================================================== bottom ==================================

    def triggerBlankWorkflow(self, workflowid, workflow_sn, runningworkflowid, debugflag, runingworkflowlineid=0, values={}):
        if runningworkflowid is None:
            raise UserError(_('Workflow %s is not set.', 'null'))
        if 'name' not in values:
            values['name'] = workflowid
        if 'workflow_running_table' not in values:
            values['workflow_running_table'] = ''
        workflow_running_par_json_str = values['workflow_running_table']
        workflow_evaluate_flag = False

        if runningworkflowid == 0:
            # 此IF区域，表示完成开始节点，传送到一下节点，生成下节点的待办
            startkey = int(self.env['ir.config_parameter'].sudo().get_param('achworkflow.workflowstartnodekey'))
            if startkey == 0:
                startkey = -1
            rsworkflow = self.env['achworkflow.achworkflow'].search(
                ['|', ('id', '=', workflowid), ('workflow_sn', '=', workflow_sn)], limit=1)
            if rsworkflow:
                workflowid = rsworkflow.id
                vals = {
                    'workflow_id': workflowid,

                    'workflow_type_nm': rsworkflow.categ_name,
                    'workflow_current_node_key': startkey,
                    'workflow_type_smn': rsworkflow.categ_simplename,
                    'user_id': self.env.uid,
                    'state': 'draft',
                    'debugflag': debugflag,
                    'name': values['name'],
                    'workflow_running_table': workflow_running_par_json_str
                }
                runningworkflow = self.create(vals)
                runningworkflowid = runningworkflow.id

            else:
                raise UserError(_('Workflow %s .not found', workflow_sn))




        return runningworkflowid

        # -----------------------------------------------------------------
        # 本区域是指已经有运行的WORKFLOW主体，根据待办来执行。＃E01

    def triggerActiveWorkflow(self, signed_txt=''):
        self.write({'state': 'run'})
        # state  => run
        workflowid = self.workflow_id.id
        startkey = self.workflow_current_node_key
        rsworkflownode = self.env['achworkflow.achworkflownode'].search(
            [
                ('workflow_id', '=', workflowid),
                ('active', '=', True),
            ]
        )
        #
        # ################################################################
        # 根据STARTKEY查询开始节点，并根据节点，查询节点线段信息查询下一节点信息
        #
        #
        current_node_id = 0
        node_text = ''
        current_node_key = 0
        node_run_mode = 'xand'
        if rsworkflownode:
            for wfnode in rsworkflownode:
                node_category = wfnode.node_category
                node_key = wfnode.node_key
                if startkey == node_key:
                    current_node_id = wfnode.id
                    node_text = wfnode.node_text
                    current_node_key = wfnode.node_key
                    node_run_mode = wfnode.node_run_mode
                    break

        self.write({'workflow_current_node': node_text,
                    'workflow_current_node_key': current_node_id
                    })

        # ################################################################
        # next node =>if node is node search appover[manager]如果下一节点，也是节点，查询节点角色，并根据节点生成待办
        # else if node is conditional ,do judge 如果下一节点，也是条件节点，判断条件，根据条件来查询下一节点，根据节点生成待办
        #
        rsworkflowline = self.env['achworkflow.achworkflowline'].search(
            [
                ('workflow_id', '=', workflowid),
                ('active', '=', True),
            ]
        )
        if True:
            # first node first appover[manager]，开始节点提交后，生产开始节点流程完成的信息
            self.env['achworkflow.achrunningworkflowline'].sudo().create(
                {
                    'name': workflowid,
                    'state': 'done',
                    'runningworkflow_id': self.id,
                    'workflow_sequence': self.workflow_sn,
                    'authedstate': 'passed',
                    'user_id': self.env.uid,
                    'node_run_mode': node_run_mode,
                    'node_key': startkey,
                    'node_text': node_text,
                    'signed_txt': signed_txt,
                    'signed_on': fields.Datetime.now(),


                }
            )
            # 查询下一节点的，节点KEY
            workflow_running_par_json_str = self.workflow_running_table
            runningworkflowid = self.id
            workflow_evaluate_flag = self.workflow_evaluate_flag
            runningworkflow = self

            self.setup_nextnode(rsworkflowline, rsworkflownode, current_node_key, workflow_running_par_json_str,
                                runningworkflowid, self.env.user, runningworkflow, workflow_evaluate_flag)
            self._compute_workflow_chart()

    # -----------------------------------------------------------------
        # 本区域是指已经有运行的WORKFLOW主体，根据待办来执行。＃E01

    def triggerWorkflow(self, workflowid, workflow_sn,  runningworkflowid, debugflag, runingworkflowlineid=0, values={}):
        if runningworkflowid is None:
            raise UserError(_('Workflow %s is not set.', 'null'))
        if 'name' not in values:
            values['name'] = workflowid
        if 'workflow_running_table' not in values:
            values['workflow_running_table'] = ''
        workflow_running_par_json_str = values['workflow_running_table']
        workflow_evaluate_flag = False

        if runningworkflowid == 0:
            #此IF区域，表示完成开始节点，传送到一下节点，生成下节点的待办
            startkey = int(self.env['ir.config_parameter'].sudo().get_param('achworkflow.workflowstartnodekey'))
            if startkey == 0:
                startkey = -1
            rsworkflow = self.env['achworkflow.achworkflow'].search(['|', ('id', '=', workflowid), ('workflow_sn', '=', workflow_sn)], limit=1)
            if rsworkflow:
                workflowid = rsworkflow.id
                workflow_evaluate_flag = rsworkflow.workflow_evaluate_flag
                vals = {
                    'workflow_id': workflowid,

                    'workflow_type_nm': rsworkflow.categ_name,

                    'workflow_type_smn': rsworkflow.categ_simplename,
                    'user_id': self.env.uid,
                    'state': 'run',
                    'debugflag': debugflag,
                    'name': values['name'],
                    'workflow_running_table': workflow_running_par_json_str
                 }
                runningworkflow = self.create(vals)
                runningworkflowid = runningworkflow.id
                runningworkflow_sequence = runningworkflow.workflow_sequence

            else:
               raise UserError(_('Workflow %s .not found', workflow_sn))

            # ################################################################
            # 上面根据WORKID OR WORKFLOWSN生成运行的woRKFLOW信息，runningworkflow_sequence主要给前面界面使用
            #
            #

            rsworkflownode = self.env['achworkflow.achworkflownode'].search(
                [
                    ('workflow_id', '=', workflowid),
                    ('active', '=', True),
                ]
            )
            #
 			 # ################################################################
            # 根据STARTKEY查询开始节点，并根据节点，查询节点线段信息查询下一节点信息
            #
            #
            current_node_id = 0
            node_text = ''
            current_node_key = 0
            node_run_mode = 'xand'
            if rsworkflownode:
                for wfnode in rsworkflownode:
                    node_category = wfnode.node_category
                    node_key = wfnode.node_key
                    if startkey == node_key:
                        current_node_id = wfnode.id
                        node_text = wfnode.node_text
                        current_node_key = wfnode.node_key
                        node_run_mode = wfnode.node_run_mode
                        break
            runningworkflow.write({'workflow_current_node': node_text,
                                   'workflow_current_node_key': current_node_id
                                   })


            # ################################################################
            # next node =>if node is node search appover[manager]如果下一节点，也是节点，查询节点角色，并根据节点生成待办
            #else if node is conditional ,do judge 如果下一节点，也是条件节点，判断条件，根据条件来查询下一节点，根据节点生成待办
            #
            rsworkflowline = self.env['achworkflow.achworkflowline'].search(
                [
                    ('workflow_id', '=', workflowid),
                    ('active', '=', True),
                ]
            )
            if True:
                # first node first appover[manager]，开始节点提交后，生产开始节点流程完成的信息
                self.env['achworkflow.achrunningworkflowline'].sudo().create(
                    {
                        'name': workflowid,
                        'state': 'done',
                        'runningworkflow_id': runningworkflowid,
                        'workflow_sequence': runningworkflow_sequence,
                        'authedstate': 'passed',
                        'user_id': self.env.uid,
                        'node_run_mode': node_run_mode,
                        'node_key': startkey,
                        'node_text': node_text

                    }
                )
                # 查询下一节点的，节点KEY
                self.setup_nextnode(rsworkflowline, rsworkflownode, current_node_key, workflow_running_par_json_str, runningworkflowid, self.env.user, runningworkflow, workflow_evaluate_flag)

                self._compute_workflow_chart()


        else:
        #  本区域是指已经有运行的WORKFLOW主体，根据待办来执行。＃B01
        # ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


            rsworkflow = self.env['achworkflow.achworkflow'].search(
                    ['|', ('id', '=', workflowid), ('workflow_sn', '=', workflow_sn)], limit=1)
            if rsworkflow:
                workflow_evaluate_flag = rsworkflow.workflow_evaluate_flag

            runningworkflowline = self.env['achworkflow.achrunningworkflowline'].search(
            [

                ('id', '=', runingworkflowlineid),
                ('state', '=', 'todo'),
                ('active', '=', True),
                ('authedstate', '=', 'todo'),
                ('user_id', '=', self.env.uid)

            ]
            )
            #上面查询待办人员信息根据待办号和用户号

            if runningworkflowline:
                for objwfline in runningworkflowline:
                    r_current_node_key = objwfline.node_key
                    rnode_run_mode = objwfline.node_run_mode
                    runningworkflowid = objwfline.runningworkflow_id.id

                    rworkflow_id = objwfline.workflow_id
                    # ++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                    #上面是参数表
                    rs_runworkflow = self.env['achworkflow.achrunningworkflow'].search(
                        [
                            ('id', '=', runningworkflowid),
                            ('active', '=', True),
                        ]
                    )
                    if rs_runworkflow:
                        workflow_starter = rs_runworkflow.user_id

                    #

                    rs_workflowline = self.env['achworkflow.achworkflowline'].search(
                        [
                            ('workflow_id', '=', rworkflow_id),
                            ('active', '=', True),
                        ]
                    )

                    rs_workflownode = self.env['achworkflow.achworkflownode'].search(
                        [
                            ('workflow_id', '=', rworkflow_id),
                            ('active', '=', True),
                        ]
                    )
                    #列出WORKFLOW节点及节点连接线

                    int_runningworkflowline = self.env['achworkflow.achrunningworkflowline'].search_count(
                        [

                            ('runningworkflow_id', '=', runningworkflowid),
                            ('state', '=', 'todo'),
                            ('active', '=', True),
                            ('authedstate', '=', 'todo'),
                            ('node_key', '=', r_current_node_key)
                        ]

                    )
                    #查询当前节点，所有待办数，下面只有一个待办
                    if int_runningworkflowline == 1:
                        if 'authedstate' in values:
                            authedstate = values['authedstate']
                            # node manager agree
                            if authedstate == 'passed':
                                objwfline.write(
                                    {
                                        'state': 'done',
                                        'authedstate': 'passed',
                                        'signed_by': self.env.uid,
                                        'signed_on': fields.Datetime.now()

                                    }
                                )
                                # 如果操作动作是审核通过，更新待办信息，设置下一个节点

                                self.setup_nextnode(rs_workflowline, rs_workflownode, r_current_node_key,
                                                    workflow_running_par_json_str, runningworkflowid, workflow_starter, rs_runworkflow, workflow_evaluate_flag)

                                #

                            #

                            #   node manager disagree 节点待办是审核不通过，工作流结束
                            if authedstate == 'reject':
                                #
                                objwfline.write(
                                        {
                                            'state': 'done',
                                            'authedstate': 'reject',
                                            'signed_by': self.env.uid,
                                            'signed_on': fields.Datetime.now()

                                        }
                                    )
                                #
                                rs_runworkflow.write(
                                    {
                                        'finish_date': fields.Datetime.now(),
                                        'state': 'cancel'
                                     }
                                )
                             # 本区域是指当前节点只有一个待办

                    if int_runningworkflowline > 1:
                        #
                        rs_runworkflow = self.env['achworkflow.achrunningworkflow'].search(
                            [
                                ('id', '=', runningworkflowid),
                                ('active', '=', True),
                            ]
                        )

                        if rnode_run_mode =='xand':
                            if authedstate == 'passed':
                                objwfline.write(
                                    {
                                        'state': 'done',
                                        'authedstate': 'passed',
                                        'signed_by': self.env.uid,
                                        'signed_on': fields.Datetime.now()

                                    }
                                )
                            #   node manager disagree 节点待办是审核不通过，工作流结束
                            if authedstate == 'reject':
                                #
                                objwfline.write(
                                    {
                                        'state': 'done',
                                        'authedstate': 'reject',
                                        'signed_by': self.env.uid,
                                        'signed_on': fields.Datetime.now()

                                    }
                                )
                                #
                                rs_runworkflow.write(
                                    {
                                        'finish_date': fields.Datetime.now(),
                                        'state': 'cancel'
                                    }

                                )
                            # 本区域是指当前节点只有一个待办

                        if rnode_run_mode == 'xor':
                            if authedstate == 'passed':
                                objwfline.write(
                                    {
                                        'state': 'done',
                                        'authedstate': 'passed',
                                        'signed_by': self.env.uid,
                                        'signed_on': fields.Datetime.now()

                                    }
                                )
                                self.setup_nextnode(rs_workflowline, rs_workflownode, r_current_node_key,
                                                    workflow_running_par_json_str, runningworkflowid, workflow_starter, rs_runworkflow, workflow_evaluate_flag)

                            #   node manager disagree 节点待办是审核不通过，工作流结束
                            if authedstate == 'reject':
                                #
                                objwfline.write(
                                    {
                                        'state': 'done',
                                        'authedstate': 'reject',
                                        'signed_by': self.env.uid,
                                        'signed_on': fields.Datetime.now()

                                    }
                                )
                                #
                                rs_runworkflow.write(
                                    {
                                        'finish_date': fields.Datetime.now(),
                                        'state': 'cancel'
                                    }

                                )
                            # 本区域是指当前节点只有一个待办

            else:
                raise UserError(_('RunningWorkflow %s has not your appover.', runningworkflowid))
            #

        self._compute_workflow_chart()

        return runningworkflowid



    # -----------------------------------------------------------------
    # 本区域是指已经有运行的WORKFLOW主体，根据待办来执行。＃E01
    # 这要增加待办人员信息和activity,取消这个函数增加，上述功能，这个功能将achworkflow.achrunningworkflowline,create事件中增加
    # 2022.4.2
    def setup_nextnode(self, rsworkflowline, rsworkflownode, current_node_key, workflow_running_par_json_str, runningworkflowid, starter, rs_runworkflow, workflow_evaluate_flag):

        next_node_key = 0
        if rsworkflowline:
            for workflowline in rsworkflowline:
                if workflowline.node_line_from == current_node_key:
                    next_node_key = workflowline.node_line_to
                    break
        #======================================
        #下一节点是为0，表示当前节点是最终节点
        if next_node_key == 0:
            if workflow_evaluate_flag:
                rs_runworkflow.write({'finish_date': fields.Datetime.now(),
                                      'state': 'evalated'}
                                     )
            else:
                rs_runworkflow.write({'finish_date': fields.Datetime.now(),
                                      'state': 'done'}
                                     )



        # above this section:end workflow

        # 下面开始判断下一节点信息
        if rsworkflownode:
            for wfnode in rsworkflownode:
                node_key = wfnode.node_key
                node_text = wfnode.node_text

                if next_node_key == node_key:
                    node_category = wfnode.node_category
                    node_run_mode = wfnode.node_run_mode
                    sameDepartment = wfnode.sameDepartment
                    sameCompany = wfnode.sameCompany
                    tostarter = wfnode.tostarter
                    if node_category == 'conditional':
                        # 下一节点是条件节点，首先根据WORKFFLOW运行参数表，来判断每条线的表达式，第一个为True的话，查询一个节点NODEkey
                        cond_next_workflowline = rsworkflowline.filtered(lambda ls: ls.node_line_from == node_key)
                        linejudge = cond_next_workflowline.mapped('linejudge_ids').filtered(lambda n: n.active == True)

                        for lj in linejudge:
                            if lj.ne_expression != '':
                                ne_expression_old = lj.ne_expression
                                runworkflowpars = {}

                                runworkflowpars = eval(workflow_running_par_json_str)

                                if runworkflowpars:
                                    for dictkey, dictval in runworkflowpars.items():
                                        ne_expression_old = ne_expression_old.replace(dictkey, str(dictval))

                            if eval(ne_expression_old):
                                # if true ,to next node
                                next_node_key2 = lj.node_line_to
                                break
                        # ===================================================
                        # 根据下一个节点KEY，来查询下一个节点，生成待办

                        for wfnode2 in rsworkflownode:
                            node_key2 = wfnode2.node_key
                            node_text2 = wfnode2.node_text
                            node_category2 = wfnode2.node_category
                            sameDepartment = wfnode2.sameDepartment
                            sameCompany = wfnode2.sameCompany
                            tostarter = wfnode2.tostarter

                            if next_node_key2 == node_key2:
                                if node_category2 == 'node' or node_category2 == 'end':
                                    # ===================================to starter如果本节点选中给发起人，就增加发起人给待办
                                    if tostarter:
                                        self.env['achworkflow.achrunningworkflowline'].sudo().create(
                                            {
                                                'name': runningworkflowid,
                                                'state': 'todo',
                                                'runningworkflow_id': runningworkflowid,
                                                'authedstate': 'todo',
                                                'user_id': starter.id,
                                                'node_run_mode': node_run_mode,
                                                'node_key': node_key2,
                                                'node_text': node_text2

                                            }
                                        )
                                    # ============================================
                                    for approverid2 in wfnode2.appover_ids.filtered(lambda n: n.active == True):
                                        user_ids = approverid2.sudo().mapped('workflow_node_role').user_ids
                                        for userid in user_ids:
                                            if sameDepartment:
                                                if sameCompany:
                                                    if (starter.department_id.id == userid.department_id.id) and (starter.company_id.id == userid.company_id.id):
                                                        self.env['achworkflow.achrunningworkflowline'].sudo().create(
                                                            {
                                                                'name': runningworkflowid,
                                                                'state': 'todo',
                                                                'runningworkflow_id': runningworkflowid,
                                                                'authedstate': 'todo',
                                                                'user_id': userid.id,
                                                                'node_run_mode': node_run_mode,
                                                                'node_key': node_key2,
                                                                'node_text': node_text2

                                                            }
                                                        )
                                                else:
                                                    if (starter.department_id.id == userid.department_id.id):
                                                        self.env['achworkflow.achrunningworkflowline'].sudo().create(
                                                            {
                                                                'name': runningworkflowid,
                                                                'state': 'todo',
                                                                'runningworkflow_id': runningworkflowid,
                                                                'authedstate': 'todo',
                                                                'user_id': userid.id,
                                                                'node_run_mode': node_run_mode,
                                                                'node_key': node_key2,
                                                                'node_text': node_text2

                                                            }
                                                        )

                                            else:
                                                if sameCompany:
                                                    if (starter.company_id.id == userid.company_id.id):
                                                        self.env['achworkflow.achrunningworkflowline'].sudo().create(
                                                            {
                                                                'name': runningworkflowid,
                                                                'state': 'todo',
                                                                'runningworkflow_id': runningworkflowid,
                                                                'authedstate': 'todo',
                                                                'user_id': userid.id,
                                                                'node_run_mode': node_run_mode,
                                                                'node_key': node_key2,
                                                                'node_text': node_text2

                                                            }
                                                        )
                                                else:
                                                    self.env['achworkflow.achrunningworkflowline'].sudo().create(
                                                            {
                                                                'name': runningworkflowid,
                                                                'state': 'todo',
                                                                'runningworkflow_id': runningworkflowid,
                                                                'authedstate': 'todo',
                                                                'user_id': userid.id,
                                                                'node_run_mode': node_run_mode,
                                                                'node_key': node_key2,
                                                                'node_text': node_text2

                                                            }
                                                        )



                    elif (node_category == 'node' or node_category == 'end'):
                        # if next node is node,search 下一个节点是执行节点或结束结点，生成待办
                        # ===================================to starter      
                        # ===================================to starter如果本节点选中给发起人，就增加发起人给待办
                        if tostarter:
                            self.env['achworkflow.achrunningworkflowline'].sudo().create(
                                {
                                    'name': runningworkflowid,
                                                    'state': 'todo',
                                                    'runningworkflow_id': runningworkflowid,
                                                    'authedstate': 'todo',
                                                    'user_id': starter.id,
                                                    'node_run_mode': node_run_mode,
                                                    'node_key': node_key,
                                                    'node_text': node_text
                                }
                            )
                        # ============================================
                        for approverid in wfnode.appover_ids.filtered(lambda n: n.active == True):
                            user_ids = approverid.sudo().mapped('workflow_node_role').user_ids
                            for userid in user_ids:
                                if sameDepartment:
                                    if sameCompany:
                                        if (starter.department_id.id == userid.department_id.id) and (
                                                starter.company_id.id == userid.company_id.id):
                                            self.env['achworkflow.achrunningworkflowline'].sudo().create(
                                                {
                                                    'name': runningworkflowid,
                                                    'state': 'todo',
                                                    'runningworkflow_id': runningworkflowid,
                                                    'authedstate': 'todo',
                                                    'user_id': userid.id,
                                                    'node_run_mode': node_run_mode,
                                                    'node_key': node_key,
                                                    'node_text': node_text

                                                }
                                            )
                                    else:
                                        if starter.department_id.id == userid.department_id.id:
                                            self.env['achworkflow.achrunningworkflowline'].sudo().create(
                                                {
                                                    'name': runningworkflowid,
                                                    'state': 'todo',
                                                    'runningworkflow_id': runningworkflowid,
                                                    'authedstate': 'todo',
                                                    'user_id': userid.id,
                                                    'node_run_mode': node_run_mode,
                                                    'node_key': node_key,
                                                    'node_text': node_text

                                                }
                                            )

                                else:
                                    if sameCompany:
                                        if (starter.company_id.id == userid.company_id.id):
                                            self.env['achworkflow.achrunningworkflowline'].sudo().create(
                                                {
                                                    'name': runningworkflowid,
                                                    'state': 'todo',
                                                    'runningworkflow_id': runningworkflowid,
                                                    'authedstate': 'todo',
                                                    'user_id': userid.id,
                                                    'node_run_mode': node_run_mode,
                                                    'node_key': node_key,
                                                    'node_text': node_text

                                                }
                                            )
                                    else:
                                        self.env['achworkflow.achrunningworkflowline'].sudo().create(
                                                {
                                                    'name': runningworkflowid,
                                                    'state': 'todo',
                                                    'runningworkflow_id': runningworkflowid,
                                                    'authedstate': 'todo',
                                                    'user_id': userid.id,
                                                    'node_run_mode': node_run_mode,
                                                    'node_key': node_key,
                                                    'node_text': node_text

                                                }
                                            )
                    # =====================
                    break
                    # next node key ,exit loop下一个节点取得，退出LOOP

        #

    # ========================================================================================================
    #
    #
    #
    # ========================================================================================================

    def action_insert_appover(self):
        self.ensure_one()
        action = self.env['ir.actions.act_window']._for_xml_id('achworkflow.achworkflow_addnewaprover_window_action')
        action['target'] = 'new',
        action['context'] = {'create': True, 'workflow_id': self.workflow_id, 'runworkflowid': self.id}

        return action
        # return {
        #     'name': _('Confirmation'),
        #     'res_model': 'achworkflow.achrunningworkflowline',
        #     'type': 'ir.actions.act_window',
        #     'view_mode': 'form',
        #     'view_id': [(self.env.ref('achworkflow.achworkflow_addnewaprover_window_action').id, 'form')],
        #     'target': 'new',
        #     'context': dict(self._context, create=True)
        #
        # }

    # ========================================================================================================
    #
    #
    #
    # ========================================================================================================

    def currentnode_insert_appover(self, userid, runningworkflowid=0):
    # 给当前节点增加待办
        runningworkflowline = self.env['achworkflow.achrunningworkflowline'].search(
            [

                ('runningworkflow_id', '=', runningworkflowid),
                ('state', '=', 'todo'),
                ('active', '=', True),


            ]
        )
        if runningworkflowline:
            for rwfl in runningworkflowline:
                node_run_mode = rwfl.node_run_mode
                node_key = rwfl.node_key
                node_text = rwfl.node_text
                self.env['achworkflow.achrunningworkflowline'].create(
                    {
                        'name': runningworkflowid,
                        'state': 'todo',
                        'runningworkflow_id': runningworkflowid,
                        'authedstate': 'todo',
                        'user_id': userid.id,
                        'node_run_mode': node_run_mode,
                        'node_key': node_key,
                        'node_text': node_text

                    }
                )

    def search_Workflow_appover(self, workflowid, workflow_sn, adminflag = True):
        if adminflag:
            runningworkflowline = self.env['achworkflow.achrunningworkflowline'].search(
                [
                    ('state', '=', 'todo'),
                    ('active', '=', True),
                    ('authedstate', '=', 'todo'),
                    ('user_id', '=', self.env.uid),
                    '|',
                    ('workflow_sn', '=', workflow_sn),
                    ('workflow_id', '=', workflowid),

                ]
            )
        else:
            runningworkflowline = self.env['achworkflow.achrunningworkflowline'].search(
                [
                    ('state', '=', 'todo'),
                    ('active', '=', True),
                    ('authedstate', '=', 'todo'),
                    ('user_id', '=', self.env.uid),
                    '|',
                    ('workflow_sn', '=', workflow_sn),
                    ('workflow_id', '=', workflowid),

                ]
            )
        return runningworkflowline



    @api.model
    def create(self, values):
        sm = values['workflow_type_smn'].strip().lower()
        code = 'workflow.' + sm
        values['workflow_sequence'] = self.env['ir.sequence'].next_by_code(code)
        res = super(achrunningworkflow, self).create(values)
        return res

    def button_pendding(self):
        if self.state == 'run':
           self.write({
                'state': 'pendding'

            })

    def button_returntorun(self):
        if self.state == 'pendding':
            self.write({
                'state': 'run'

            })
# =========================================================================================
#
# code 9-20
# ----------------------------------------------------------------------------------------

    def triggerWorkflowAction(self, signed_txt='', btnaction=0, threadid=0):
        #
        workflow_running_par_json_str = self.workflow_running_table
        workflowid = self.workflow_id.id

        workflow_sn = ''
        rsworkflow = self.env['achworkflow.achworkflow'].search(
            ['|', ('id', '=', workflowid), ('workflow_sn', '=', workflow_sn)], limit=1)
        if rsworkflow:
            workflow_evaluate_flag = rsworkflow.workflow_evaluate_flag

        runningworkflowline = self.mapped('runningworkflowline_ids').filtered(lambda w: w.state == 'todo' and w.authedstate == 'todo' and w.active == True and w.user_id.id == self.env.uid)

        if runningworkflowline:
            for objwfline in runningworkflowline:
                r_current_node_key = objwfline.node_key
                rnode_run_mode = objwfline.node_run_mode
                runningworkflowid = objwfline.runningworkflow_id.id

                rworkflow_id = objwfline.workflow_id
                # ++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                # 上面是参数表
                rs_runworkflow = self.env['achworkflow.achrunningworkflow'].search(
                    [
                        ('id', '=', runningworkflowid),
                        ('active', '=', True),
                    ]
                )
                if rs_runworkflow:
                    workflow_starter = rs_runworkflow.user_id

                #

                rs_workflowline = self.env['achworkflow.achworkflowline'].search(
                    [
                        ('workflow_id', '=', rworkflow_id),
                        ('active', '=', True),
                    ]
                )

                rs_workflownode = self.env['achworkflow.achworkflownode'].search(
                    [
                        ('workflow_id', '=', rworkflow_id),
                        ('active', '=', True),
                    ]
                )
                # 列出WORKFLOW节点及节点连接线

                int_runningworkflowline = self.env['achworkflow.achrunningworkflowline'].search_count(
                    [

                        ('runningworkflow_id', '=', runningworkflowid),
                        ('state', '=', 'todo'),
                        ('active', '=', True),
                        ('authedstate', '=', 'todo'),
                        ('node_key', '=', r_current_node_key)
                    ]

                )
                # 查询当前节点，所有待办数，下面只有一个待办
                if int_runningworkflowline == 1:
                    # ---------------------------------------------------------------------
                    # last node

                    if btnaction == '3':
                        objwfline.write(
                            {
                                'state': 'done',
                                'authedstate': 'passed',
                                'signed_txt': signed_txt,
                                'signed_by': self.env.uid,
                                'signed_on': fields.Datetime.now()

                            })
                        rs_runworkflow.write(
                            {
                                'finish_date': fields.Datetime.now(),
                                'state': 'done'
                            }
                        )
                    # last node document action
                    # ----------------------------------------------------
                    # node manager agree
                    if btnaction == '0':
                        objwfline.write(
                                {
                                    'state': 'done',
                                    'authedstate': 'passed',
                                    'signed_txt': signed_txt,
                                    'signed_by': self.env.uid,
                                    'signed_on': fields.Datetime.now()

                                })

                            # 如果操作动作是审核通过，更新待办信息，设置下一个节点

                        self.setup_nextnode(rs_workflowline, rs_workflownode, r_current_node_key,
                                                workflow_running_par_json_str, runningworkflowid, workflow_starter,
                                                rs_runworkflow, workflow_evaluate_flag)

                        # node manager disagree 节点待办是审核不通过，工作流结束
                        if btnaction == '1':                            #
                            objwfline.write(
                                {
                                    'state': 'done',
                                    'authedstate': 'reject',

                                    'signed_txt': signed_txt,
                                    'signed_by': self.env.uid,
                                    'signed_on': fields.Datetime.now()

                                }
                            )
                            #
                            rs_runworkflow.write(
                                {
                                    'finish_date': fields.Datetime.now(),
                                    'state': 'cancel'
                                }
                            )
                        # 本区域是指当前节点只有一个待办

                if int_runningworkflowline > 1:
                    #
                    rs_runworkflow = self.env['achworkflow.achrunningworkflow'].search(
                        [
                            ('id', '=', runningworkflowid),
                            ('active', '=', True),
                        ]
                    )

                    if rnode_run_mode == 'xand':
                        # ---------------------------------------------------------------------
                        # last node
                        if btnaction == '3':
                            objwfline.write(
                                {
                                    'state': 'done',
                                    'authedstate': 'passed',
                                    'signed_txt': signed_txt,
                                    'signed_by': self.env.uid,
                                    'signed_on': fields.Datetime.now()

                                })
                            rs_runworkflow.write(
                                {
                                    'finish_date': fields.Datetime.now(),
                                    'state': 'done'
                                }
                            )
                        # last node document action
                        # ----------------------------------------------------

                        if btnaction == '0':#passed
                            objwfline.write(
                                {
                                     'state': 'done',
                                    'authedstate': 'passed',
                                    'signed_txt': signed_txt,
                                    'signed_by': self.env.uid,
                                    'signed_on': fields.Datetime.now()

                                }
                            )
                        #   node manager disagree 节点待办是审核不通过，工作流结束
                        if btnaction == '1':   #reject                         #
                            #
                            objwfline.write(
                                {
                                    'state': 'done',
                                    'authedstate': 'reject',
                                    'signed_txt': signed_txt,
                                    'signed_by': self.env.uid,
                                    'signed_on': fields.Datetime.now()

                                }
                            )
                            #
                            rs_runworkflow.write(
                                {
                                    'finish_date': fields.Datetime.now(),
                                    'state': 'cancel'
                                }

                            )
                        # 本区域是指当前节点只有一个待办

                    if rnode_run_mode == 'xor':
                        # ---------------------------------------------------------------------
                        # last node

                        if btnaction == '3':
                            objwfline.write(
                                {
                                    'state': 'done',
                                    'authedstate': 'passed',
                                    'signed_txt': signed_txt,
                                    'signed_by': self.env.uid,
                                    'signed_on': fields.Datetime.now()

                                })
                            rs_runworkflow.write(
                                {
                                    'finish_date': fields.Datetime.now(),
                                    'state': 'done'
                                }
                            )
                        # last node document action
                        # ----------------------------------------------------
                        # passed
                        # --------------------------------------------
                        if btnaction == '0':
                            objwfline.write(
                                {
                                    'state': 'done',
                                    'authedstate': 'passed',
                                    'signed_txt': signed_txt,
                                    'signed_by': self.env.uid,
                                    'signed_on': fields.Datetime.now()

                                }
                            )
                            self.setup_nextnode(rs_workflowline, rs_workflownode, r_current_node_key,
                                                workflow_running_par_json_str, runningworkflowid, workflow_starter,
                                                rs_runworkflow, workflow_evaluate_flag)

                        #   node manager disagree 节点待办是审核不通过，工作流结束
                        # reject
                        # --------------------------------------------------------------
                        if btnaction == '1':
                            objwfline.write(
                                {
                                    'state': 'done',
                                    'authedstate': 'reject',
                                    'signed_txt': signed_txt,
                                    'signed_by': self.env.uid,
                                    'signed_on': fields.Datetime.now()

                                }
                            )
                            #
                            rs_runworkflow.write(
                                {
                                    'finish_date': fields.Datetime.now(),
                                    'state': 'cancel'
                                }

                            )
                        # 本区域是指当前节点只有一个待办



        else:
            raise UserError(_('RunningWorkflow %s has not your appover.', threadid))
        self._compute_workflow_chart()


        # 上面查询待办人员信息根据待办号和用户号
    # --------------------------------------------------------------------------------
    # code 9-27
    # -----------------------------------------------------------------------------


    def _compute_workflow_chart(self):
        workflowchart = self.chart
        for workflowline in self.runningworkflowline_ids:
            if workflowline.active and workflowline.state == 'done':
                node_key = workflowline.node_key
                node_text_name = workflowline.user_id.name
                if workflowline.authedstate == 'passed':
                    workflowchart = self._format_workflow_chart_ok(workflowchart, node_key, node_text_name)

                if workflowline.authedstate == 'reject':
                    workflowchart = self._format_workflow_chart_no(workflowchart, node_key, node_text_name)


        for workflow in self:
            workflow.finished_chart = workflowchart
    # =================================================================
    def _format_workflow_chart_ok(self, chartjson_str, pickedkey, node_text_name):
        objworkflow = json.loads(chartjson_str)
        if objworkflow:
            if ('class' in objworkflow):
                if objworkflow['class'] == 'GraphLinksModel':
                    if ('nodeDataArray' in objworkflow):
                        nodeDataArray = objworkflow['nodeDataArray']
                        for node in nodeDataArray:
                            if node['key'] == pickedkey:
                                node["category"] = node["category"] + "1"
                                node["text"] = node["text"] + ' ' + node_text_name

        return json.dumps(objworkflow)



    def _format_workflow_chart_no(self, chartjson_str, pickedkey,node_text_name):
        objworkflow = json.loads(chartjson_str)
        if objworkflow:
            if ('class' in objworkflow):
                if objworkflow['class'] == 'GraphLinksModel':
                    if ('nodeDataArray' in objworkflow):
                        nodeDataArray = objworkflow['nodeDataArray']
                        for node in nodeDataArray:
                            if node['key'] == pickedkey:
                                node["category"] = node["category"] + "2"
                                node["text"] = node["text"] + ' ' + node_text_name

        return json.dumps(objworkflow)
# ========================================================================

