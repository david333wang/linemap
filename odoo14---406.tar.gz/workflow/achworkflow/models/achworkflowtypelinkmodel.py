# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo import _, tools

class achworkflowtypelinkmodel(models.Model):
    _name = 'achworkflow.achworkflowtypelinkmodel'
    _description = 'achworkflowtypelinkmodel'

    name = fields.Char(compute="_value_name", store=True)

    @api.depends('categ_name')
    def _value_name(self):
        for record in self:
            record.name = record.categ_name

    workflow_id = fields.Many2one('achworkflow.achworkflow', string="workflow id")

    categ_name = fields.Char(related="workflow_id.categ_name", store=True)


    active = fields.Boolean(default=True)
    model_id = fields.Many2one('ir.model', string="model name")
    model_name = fields.Char(related="model_id.model", string="model name", store=True)

    # template_action_id = fields.Many2one('ir.actions.actions',  string="workflow action id")
    template_action_id = fields.Char(string="action xml_id", default='debug005')

    savetriggerworkflowflag = fields.Boolean(default=True)

    workflowover_exec_resultflag = fields.Boolean(default=False)

    status = fields.Selection([
        ('run', 'run'),
        ('pause', 'pause')
    ], default='run')
    workflow_todo_count = fields.Integer(string="todo", compute="_compute_todo_count")
    workflow_did_count = fields.Integer(string="did", compute="_compute_did_count")

    _sql_constraints = [('workflow_id_uniq', 'unique (model_id)', "The model_id  just bind one time.")]

    def _compute_todo_count(self):
        for workflow in self:
            workflow.workflow_todo_count = workflow.workflow_id.request_to_myworkflowline_count


    def _compute_did_count(self):
        for workflow in self:
            workflow.workflow_did_count = workflow.workflow_id.request_to_myworkflowlinedid_count

    def action_open_workflow(self):
        self.ensure_one()
        # self.env.context['active_ids']
        win_domain = [('runningworkflow_id', '!=', False), ('runningworkflow_id.runningworkflowline_ids.user_id', '=', self.env.uid), ('runningworkflow_id.runningworkflowline_ids.state', '=', 'todo')]
        win_context = {}
        win_data = {
            'name': _('%s todo', self.workflow_id.name),
            'type': 'ir.actions.act_window',
            'view_mode': 'tree,form',
            'res_model': self.model_name,
            'domain': win_domain,
            'context': win_context,
            'target': 'current',

        }
        return win_data


    def action_open_didworkflow(self):
        self.ensure_one()
        win_domain = [('runningworkflow_id', '!=', False),
                      ('runningworkflow_id.runningworkflowline_ids.user_id', '=', self.env.uid),
                      ('runningworkflow_id.runningworkflowline_ids.state', '=', 'done')]
        win_context = {}
        win_data = {
            'name': _('%s did', self.workflow_id.name),
            'type': 'ir.actions.act_window',
            'view_mode': 'tree,form',
            'res_model': self.model_name,
            'domain': win_domain,
            'context': win_context,
            'target': 'current',

        }
        return win_data