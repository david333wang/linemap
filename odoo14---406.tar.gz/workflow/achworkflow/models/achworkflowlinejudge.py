# -*- coding: utf-8 -*-


import base64
from random import choice
from string import digits
from werkzeug.urls import url_encode


from odoo import api, fields, models, _
from odoo.osv.query import Query
from odoo.exceptions import ValidationError, AccessError
from odoo.modules.module import get_module_resource


class achworkflowlinejudge(models.Model):
    _name = 'achworkflow.achworkflowlinejudge'
    _description = 'line审核'


    workflow_line_id = fields.Many2one('achworkflow.achworkflowline', string="workflowline")

    workflow_id = fields.Integer(related='workflow_line_id.workflow_id.id', string="workflow", store=True)
    node_line_to = fields.Integer(related='workflow_line_id.node_line_to', string="node_line_to", store=True)

    name = fields.Char()
    active = fields.Boolean(default=True)
    ne_expression = fields.Char(string='expression')
    nodeline_date = fields.Datetime('node date', default=fields.Datetime.now)





