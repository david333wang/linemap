# -*- coding: utf-8 -*-

from odoo import models, fields, api


class achworkflowtype(models.Model):
    _name = 'achworkflow.achworkflowtype'
    _description = 'achworkflowtype'

    name = fields.Char(required=True)
    simplename = fields.Char(required=True, string="simple")

    active = fields.Boolean(default=True)


    status = fields.Selection([
        ('run', 'run'),
        ('pause', 'pause')
    ], default='run')

    _sql_constraints = [
        ('simplename_uniq', 'unique (simplename)', "The simplename ID must be unique."),
     ]
    @api.model
    def create(self, values):
        sm = values['simplename'].strip().lower()
        code = 'workflow.'+sm
        irseq = {'name': 'workflowtype_'+sm, 'code': code, 'padding': 5, 'implementation': 'no_gap', 'prefix': sm}
        # 图例（前缀，后缀）
        # 年代: % (year)
        # s
        # 年份: % (y)
        # s
        # 月: % (month)
        # s
        # 日: % (day)
        # s
        # 当年第几天: % (doy)
        # s
        # 当年第几周: % (woy)
        # s
        # 当周第几天(0: 周一): % (weekday)
        # s
        # 时
        # 00->24: % (h24)
        # s
        # 时
        # 00->12: % (h12)
        # s
        # 分: % (min)
        # s
        # 秒: % (sec)
        # s

        self.env['ir.sequence'].search([('name', '=', 'workflowtype_'+sm)]).write({'active': False})

        self.env['ir.sequence'].create(irseq)

        res = super(achworkflowtype, self).create(values)

        return res