# -*- coding: utf-8 -*-

from odoo import api, fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'


    workflowstartnodekey = fields.Integer('start node key', default=-1, config_parameter='achworkflow.workflowstartnodekey')
    workflowlastnodekey = fields.Integer('last node key', default=-1000,  config_parameter='achworkflow.workflowlastnodekey')

    workflowmessageflag = fields.Boolean('message flag', default=True,
                                         config_parameter='achworkflow.workflowmessageflag')
    workflowactivityflag = fields.Boolean('activity flag', default=True,
                                         config_parameter='achworkflow.workflowactivityflag')
    workflowactivityhour = fields.Integer('activity hour', default=2,
                                          config_parameter='achworkflow.workflowactivityhour')
    def set_values(self):
        super(ResConfigSettings, self).set_values()
    @api.model
    def create(self, values):
        return super(ResConfigSettings, self).create(values)