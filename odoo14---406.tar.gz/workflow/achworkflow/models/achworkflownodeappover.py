# -*- coding: utf-8 -*-


import base64
from random import choice
from string import digits
from werkzeug.urls import url_encode


from odoo import api, fields, models, _
from odoo.osv.query import Query
from odoo.exceptions import ValidationError, AccessError
from odoo.modules.module import get_module_resource


class achworkflownodeappover(models.Model):
    _name = 'achworkflow.achworkflownodeappover'
    _description = '节点审核人'


    workflow_node_id = fields.Many2one('achworkflow.achworkflownode', string="workflownode")
    workflow_id = fields.Integer(related='workflow_node_id.workflow_id.id', string="workflow", store=True)
    name = fields.Char()
    active = fields.Boolean(default=True)
    nodeappoverdate = fields.Datetime('node date', default=fields.Datetime.now)
    workflow_node_role = fields.Many2one('res.users.role',  string='node role')




