odoo.define('achworkflow.workflowchart', function (require) {
    "use strict";
   
    var field_registry = require('web.field_registry');
    var fields = require('web.basic_fields');
    var core = require('web.core');

    var utils =require('web.field_utils');
    var qweb = core.qweb;
    var _t = core._t;
    var _lt = core._lt;

    var FieldACHWorkflowChart = fields.FieldChar.extend({
            widget_class: 'o_form_field_flow_chart',
            template: 'FieldACHWorkflowChart',
            events: {


            },
             //--------------------------------------------------------------------------
            // Public
            //--------------------------------------------------------------------------


            /**
             * @override
             */
             init: function()
             {
                this.workflowdesign = null;
                 this.initialized = false;
                  this.myDiagram = false ;
                   this.myPalette = false ;
                   this.editable = false;


                  this.default = { "class": "go.GraphLinksModel",
                    "linkFromPortIdProperty": "fromPort",
                    "linkToPortIdProperty": "toPort",
                    "nodeDataArray": [
                  ],
                    "linkDataArray": [
                  ]};
                   this.$$ = go.GraphObject.make;  // for conciseness in defining templates
                   this.idag = null;
                   this.myDiagram = false ;
                   return this._super.apply(this, arguments);

             },

            start: function () {


             this.editable = false;
             if(this.mode=="edit")
             {
                this.editable = true;
             }
              this.workflowdesign = this.$(".achworkflow_editor_divcanvas")[0];

               this.myPalette  = this.$(".achworkflow_editor_palcanvas")[0];

              return this._super.apply(this, arguments);
            },

            load:function(){
                var self=this;
                 var show_value = '';
                 if(!self.value)
                 {
                  show_value = JSON.stringify(self.default)
                 }
                 else
                 {
                  show_value = self._formatValue(self.value)
                 }
//                 var show_value = self._formatValue(self.value) ? self.value :

                 self.myDiagram.model = go.Model.fromJson(show_value);

            },
//          _getValue: function () {
//            var $input = this.$el.find('input');
//            var val = $input.val();
//            return $input.val();
//        },


        _renderReadonly: function () {
            return Promise.resolve().then(() => {
                // Prevent Double Rendering on Updates
                if (!this.myDiagram) {
                    this.init_go_readonly();
                    this.load();

                }
                else
                {
                     this.load();
                }
            });
         },

        _renderEdit: function () {

            return Promise.resolve().then(() => {
                // Prevent Double Rendering on Updates
                if (!this.myDiagram) {
                    this.init_go_edit();
                    this.load();

                }
                else
                {
                     this.load();
                }
            });
         },
            /**
             * @override
             */
            destroy: function () {

                this._super.apply(this, arguments);
            },



              //--------------------------------------------------------------------------
            // Private
            //--------------------------------------------------------------------------




              /**
             * Starts the ace library on the given DOM element. This initializes the
             * ace editor option according to the edit/readonly mode and binds ace
             * editor events.
             *
             * @private
             * @param {Node} node - the DOM element the ace library must initialize on
             */

            //=============================gojs init_go_edit===================================
            init_go_edit:function(){
                          var self = this;
                              //prive gojs function
                                 function nodeStyle() {
                                    return [
                                    new go.Binding("angle").makeTwoWay(),
                                    new go.Binding("desiredSize","size",go.Size.parse).makeTwoWay(go.Size.stringify),
                                      // The Node.location comes from the "loc" property of the node data,
                                      // converted by the Point.parse static method.
                                      // If the Node.location is changed, it updates the "loc" property of the node data,
                                      // converting back using the Point.stringify static method.
                                      new go.Binding("location", "loc", go.Point.parse).makeTwoWay(go.Point.stringify),
                                      {
                                        // the Node.location is at the center of each node
                                        locationSpot: go.Spot.Center,
                                        resizable:true,
                                        rotatable:true,
                                        resizeObjectName:'ITEM',
                                        selectionObjectName:'ITEM'

                                      }
                                    ];
                              };
                              //=================================

                        //===========================================================
                          self.myDiagram =
                            self.$$(go.Diagram, this.workflowdesign ,  // must name or refer to the DIV HTML element
                              {
                                "LinkDrawn": showLinkLabel,  // this DiagramEvent listener is defined below
                                "LinkRelinked": showLinkLabel,

                                "zoomToFit":true,
                                "allowDelete":true,

                                'scale':0.5,
                                "grid.visible":true,
                               "grid.gridCellSize":new go.Size(50,50),
//                                "draggingTool.isGridSnapEnabled":true,
//                                "draggingTool.gridSnapCellSize":new go.Size(50,50),
                                "initialContentAlignment": go.Spot.Center,  // center the content

                                  // enable undo & redo
                              });


                            //NODE ===================
                              self.myDiagram.nodeTemplateMap.add("Start",
                                self.$$(go.Node, "Table", nodeStyle(),
                                  self.$$(go.Panel, "Spot",
                                    self.$$(go.Shape, "Circle",
                                      {name:'ITEM', fill: "#ffffff", stroke: "green", strokeWidth: 3.5 ,minSize:new go.Size(50,50) },
                                              new go.Binding("desiredSize","size",go.Size.parse).makeTwoWay(go.Size.stringify),
                        ),

                                   self.$$(go.TextBlock, textStyle(),
                                      {
                                        margin: 8,
                                        maxSize: new go.Size(160, NaN),
                                        wrap: go.TextBlock.WrapFit,
                                        editable: self.editable
                                      },
                                      new go.Binding("text").makeTwoWay())
                                  ),
                                  // three named ports, one on each side except the top, all output only:
                                  makePort("L", go.Spot.Left, go.Spot.Left, true, false),
                                  makePort("R", go.Spot.Right, go.Spot.Right, true, false),
                                  makePort("B", go.Spot.Bottom, go.Spot.Bottom, true, false)
                                ));

                              self.myDiagram.nodeTemplateMap.add("Node",  // the default category
                                    self.$$(go.Node, "Table", nodeStyle(),
                                      // the main object is a Panel that surrounds a TextBlock with a rectangular Shape
                                      self.$$(go.Panel, "Auto",
                                        self.$$(go.Shape, "Rectangle",
                                          { name:'ITEM',fill: "#ffffff", stroke: "#000000", strokeWidth: 3.5 ,minSize:new go.Size(100,50)  },
                                          new go.Binding("figure", "figure"),
                                                  new go.Binding("desiredSize","size",go.Size.parse).makeTwoWay(go.Size.stringify)
                            ),
                                        self.$$(go.TextBlock, textStyle(),
                                          {
                                            margin: 8,
                                            maxSize: new go.Size(400, NaN),
                                            minSize: new go.Size(100, NaN),
                                        textAlign: "center",
                                            wrap: go.TextBlock.WrapFit,
                                            editable: self.editable
                                          },
                                          new go.Binding("text").makeTwoWay())
                                      ),
                                      // four named ports, one on each side:
                                      makePort("T", go.Spot.Top, go.Spot.TopSide, false, true),
                                      makePort("L", go.Spot.Left, go.Spot.LeftSide, true, true),
                                      makePort("R", go.Spot.Right, go.Spot.RightSide, true, true),
                                      makePort("B", go.Spot.Bottom, go.Spot.BottomSide, true, false)
                                    ));

                              self.myDiagram.nodeTemplateMap.add("Conditional",
                                self.$$(go.Node, "Table", nodeStyle(),
                                  // the main object is a Panel that surrounds a TextBlock with a rectangular Shape
                                  self.$$(go.Panel, "Auto",
                                    self.$$(go.Shape, "Diamond",
                                      { name:'ITEM',fill: "#ffffff", stroke: "blue", strokeWidth: 3.5, minSize:new go.Size(50,50) },
                                      new go.Binding("figure", "figure"),
                                              new go.Binding("desiredSize","size",go.Size.parse).makeTwoWay(go.Size.stringify),
                        ),
                                    self.$$(go.TextBlock, textStyle(),
                                      {
                                        margin: 8,
                                        maxSize: new go.Size(160, NaN),
                                        textAlign: "center",
                                        wrap: go.TextBlock.WrapFit,
                                        editable: self.editable
                                      },
                                      new go.Binding("text").makeTwoWay())
                                  ),
                                  // four named ports, one on each side:
                                  makePort("T", go.Spot.Top, go.Spot.Top, false, true),
                                  makePort("L", go.Spot.Left, go.Spot.Left, true, true),
                                  makePort("R", go.Spot.Right, go.Spot.Right, true, true),
                                  makePort("B", go.Spot.Bottom, go.Spot.Bottom, true, false)
                                ));

                              self.myDiagram.nodeTemplateMap.add("End",
                                    self.$$(go.Node, "Table", nodeStyle(),
                                      self.$$(go.Panel, "Spot",
                                        self.$$(go.Shape, "Circle",
                                          { name:'ITEM', fill: "#ffffff", stroke: "red", strokeWidth: 3.5 },        new go.Binding("desiredSize","size",go.Size.parse).makeTwoWay(go.Size.stringify),
                            ),
                                        self.$$(go.TextBlock, textStyle(),
                                          {
                                            margin: 8,
                                            maxSize: new go.Size(160, NaN),
                                            wrap: go.TextBlock.WrapFit,
                                            editable: self.editable
                                          },
                                          new go.Binding("text").makeTwoWay())
                                      ),
                                      // three named ports, one on each side except the bottom, all input only:
                                      makePort("T", go.Spot.Top, go.Spot.Top, false, true),
                                      makePort("L", go.Spot.Left, go.Spot.Left, false, true),
                                      makePort("R", go.Spot.Right, go.Spot.Right, false, true)
                                    ));

                                  //taken from ../extensions/Figures.js:
                               go.Shape.defineFigureGenerator("File", function(shape, w, h) {
                                    var geo = new go.Geometry();
                                    var fig = new go.PathFigure(0, 0, true); // starting point
                                    geo.add(fig);
                                    fig.add(new go.PathSegment(go.PathSegment.Line, .75 * w, 0));
                                    fig.add(new go.PathSegment(go.PathSegment.Line, w, .25 * h));
                                    fig.add(new go.PathSegment(go.PathSegment.Line, w, h));
                                    fig.add(new go.PathSegment(go.PathSegment.Line, 0, h).close());
                                    var fig2 = new go.PathFigure(.75 * w, 0, false);
                                    geo.add(fig2);
                                    // The Fold
                                    fig2.add(new go.PathSegment(go.PathSegment.Line, .75 * w, .25 * h));
                                    fig2.add(new go.PathSegment(go.PathSegment.Line, w, .25 * h));
                                    geo.spot1 = new go.Spot(0, .25);
                                    geo.spot2 = go.Spot.BottomRight;
                                    return geo;
                                  });
                               self.myDiagram.nodeTemplateMap.add("Comment",
                                self.$$(go.Node, "Auto", nodeStyle(),
                                  self.$$(go.Shape, "File",
                                    { name:'ITEM',fill: "transparent", stroke: "#000000", strokeWidth: 3 },new go.Binding("desiredSize","size",go.Size.parse).makeTwoWay(go.Size.stringify)),
                                  self.$$(go.TextBlock, textStyle(),
                                    {
                                      margin: 8,
                                      maxSize: new go.Size(125, NaN),
                                      minSize: new go.Size(125, NaN),
                                      wrap: go.TextBlock.WrapFit,
                                      textAlign: "center",
                                      editable: self.editable
                                    }
                                    , new go.Binding("text").makeTwoWay())
                                  // no ports, because no links are allowed to connect with a comment
                                ));
//===============================Palette=====================begin=======================================


                      this.myPalette.className = 'achworkflow_editor_palcanvas achworkflow_show';

                                 self.myPalette =
                                    self.$$(go.Palette,this.myPalette ,  // must name or refer to the DIV HTML element
                                      {

                                        nodeTemplateMap: self.myDiagram.nodeTemplateMap,  // share the templates used by self.myDiagram
                                        model: new go.GraphLinksModel([  // specify the contents of the Palette
                                          { category: "Start", text: "开始" },
                                          { category: "Node",  text: "节点" },
                                          { category: "Conditional", text: "决策" },
                                          { category: "End", text: "结束" },
                                          { category: "Comment", text: "备注" }
                                        ])
                                      });

//===============================Palette=====================end=======================================

                            //NODE END
                            //=================================

                              // replace the default Link template in the linkTemplateMap
                              self.myDiagram.linkTemplate =
                                self.$$(go.Link,  // the whole link panel
                                  {
                                    
							          routing: go.Link.AvoidsNodes,
							          curve: go.Link.JumpOver,
							          corner: 5, toShortLength: 4,
							          relinkableFrom: true,
							          relinkableTo: true,
							          reshapable: true,
							          resegmentable: true,
							          // mouse-overs subtly highlight links:
							          //mouseEnter: (e, link) => link.findObject("HIGHLIGHT").stroke = "rgba(30,144,255,0.2)",
							          //mouseLeave: (e, link) => link.findObject("HIGHLIGHT").stroke = "transparent"
                                  },
                                  new go.Binding("points").makeTwoWay(),
                                  self.$$(go.Shape,  // the highlight shape, normally transparent
                                    { isPanelMain: true, strokeWidth: 8, stroke: "transparent", name: "HIGHLIGHT" }),
                                  self.$$(go.Shape,  // the link path shape
                                    { isPanelMain: true, stroke: "gray", strokeWidth: 2 },
                                    new go.Binding("stroke", "isSelected", function(sel) { return sel ? "dodgerblue" : "gray"; }).ofObject()),
                                  self.$$(go.Shape,  // the arrowhead
                                    { toArrow: "standard", strokeWidth: 0, fill: "gray" }),
                                  self.$$(go.Panel, "Auto",  // the link label, normally not visible
                                    { visible: false, name: "LABEL", segmentIndex: 2, segmentFraction: 0.5 },
                                    new go.Binding("visible", "visible").makeTwoWay(),
                                    self.$$(go.Shape, "RoundedRectangle",  // the label shape
                                      { fill: "white", strokeWidth: 1, minSize:new go.Size(100,40) }),
                                    self.$$(go.TextBlock, "Yes",  // the label
                                      {  minSize: new go.Size(120, 120),
                                        textAlign: "center",
                                        font: "15pt helvetica, arial, sans-serif",
                                        stroke: "black",
                                        editable: self.editable
                                        , isMultiline: false 
                                      },
                                      new go.Binding("text").makeTwoWay())
                                  )
                                );


                            // temporary links used by LinkingTool and RelinkingTool are also orthogonal:
                          self.myDiagram.toolManager.linkingTool.temporaryLink.routing = go.Link.Orthogonal;
                          self.myDiagram.toolManager.relinkingTool.temporaryLink.routing = go.Link.Orthogonal;


                            //EVENT====================
                            // notice whenever a transaction or undo/redo has occurred


                            //===========================================================
                             //helper
                             // This is a re-implementation of the default animation, except it fades in from downwards, instead of upwards.


                            function showLinkLabel(e) {
                                var label = e.subject.findObject("LABEL");
                                if (label !== null) label.visible = (e.subject.fromNode.data.category === "Conditional");
                              };



                              // Define a function for creating a "port" that is normally transparent.
                              // The "name" is used as the GraphObject.portId,
                              // the "align" is used to determine where to position the port relative to the body of the node,
                              // the "spot" is used to control how links connect with the port and whether the port
                              // stretches along the side of the node,
                              // and the boolean "output" and "input" arguments control whether the user can draw links from or to the port.
                              function makePort(name, align, spot, output, input) {
                                var horizontal = align.equals(go.Spot.Top) || align.equals(go.Spot.Bottom);
                                // the port is basically just a transparent rectangle that stretches along the side of the node,
                                // and becomes colored when the mouse passes over it
                                return self.$$(go.Shape,
                                  {
                                    fill: "transparent",  // changed to a color in the mouseEnter event handler
                                    strokeWidth: 0,  // no stroke
                                    width: horizontal ? NaN : 8,  // if not stretching horizontally, just 8 wide
                                    height: !horizontal ? NaN : 8,  // if not stretching vertically, just 8 tall
                                    alignment: align,  // align the port on the main Shape
                                    stretch: (horizontal ? go.GraphObject.Horizontal : go.GraphObject.Vertical),
                                    portId: name,  // declare this object to be a "port"
                                    fromSpot: spot,  // declare where links may connect at this port
                                    fromLinkable: output,  // declare whether the user may draw links from here
                                    toSpot: spot,  // declare where links may connect at this port
                                    toLinkable: input,  // declare whether the user may draw links to here
                                    cursor: "pointer",  // show a different cursor to indicate potential link point
                                    mouseEnter: function(e, port) {  // the PORT argument will be this Shape
                                      if (!e.diagram.isReadOnly) port.fill = "rgba(255,0,255,0.5)";
                                    },
                                    mouseLeave: function(e, port) {
                                      port.fill = "transparent";
                                    }
                                  });
                              };

                              function textStyle() {
                                return {
                                  font: "bold 18pt Lato, Helvetica, Arial, sans-serif",
                                  stroke: "#000000"
                                }
                              };

                              //helper end==============================
                              // notice whenever a transaction or undo/redo has occurred
                              self.myDiagram.addModelChangedListener(function(e) {


                                    if(self.myDiagram.nodes.count > 0)
                                    {
                                        self._setValue(self.myDiagram.model.toJson());
                                        var $input = self.$el.find('input');
                                        if($input)
                                        {
                                            $input.val(self.myDiagram.model.toJson());
                                        }
                                    }
                                    //self.$el.val(self.myDiagram.model.toJson());


                              });
                            self.initialized=true;


             //====================================init_go end tag============
             },
             //====================================init_editgo end tag============
                //=============================gojs init_go_reaonly===================================
            init_go_readonly:function(){
                          var self=this;
                              //prive gojs function
                                 function nodeStyle() {
                                    return [
                                    new go.Binding("angle").makeTwoWay(),
                                    new go.Binding("desiredSize","size",go.Size.parse).makeTwoWay(go.Size.stringify),
                                      // The Node.location comes from the "loc" property of the node data,
                                      // converted by the Point.parse static method.
                                      // If the Node.location is changed, it updates the "loc" property of the node data,
                                      // converting back using the Point.stringify static method.
                                      new go.Binding("location", "loc", go.Point.parse).makeTwoWay(go.Point.stringify),
                                      {
                                        // the Node.location is at the center of each node
                                        locationSpot: go.Spot.Center,
                                        resizable:true,
                                        rotatable:true,
                                        resizeObjectName:'ITEM',
                                        selectionObjectName:'ITEM'

                                      }
                                    ];
                              };
                              //=================================

                        //===========================================================
                          self.myDiagram =
                            self.$$(go.Diagram, this.workflowdesign ,  // must name or refer to the DIV HTML element
                              {
                                "LinkDrawn": showLinkLabel,  // this DiagramEvent listener is defined below
                                "LinkRelinked": showLinkLabel,
                                 'scale':0.65,
                                "zoomToFit":true,
                                "allowDelete":false,
                                'contentAlignment':go.Spot.Center,
//                                "grid.visible":true,
//                                "grid.gridCellSize":new go.Size(50,50),
//                                "draggingTool.isGridSnapEnabled":true,
//                                "draggingTool.gridSnapCellSize":new go.Size(50,50),
                                "initialContentAlignment": go.Spot.Center,  // center the content

                                  // enable undo & redo
                              });

                            //NODE ===================
                              self.myDiagram.nodeTemplateMap.add("Start",
                                self.$$(go.Node, "Table", nodeStyle(),
                                  self.$$(go.Panel, "Spot",
                                    self.$$(go.Shape, "Circle",
                                      {name:'ITEM', fill: "#ffffff", stroke: "green", strokeWidth: 3.5 },        new go.Binding("desiredSize","size",go.Size.parse).makeTwoWay(go.Size.stringify),
                        ),

                                   self.$$(go.TextBlock, textStyle(),
                                      {
                                        margin: 8,
                                        maxSize: new go.Size(160, NaN),
                                        wrap: go.TextBlock.WrapFit,
                                        editable: self.editable
                                      },
                                      new go.Binding("text").makeTwoWay())
                                  ),
                                  // three named ports, one on each side except the top, all output only:
                                  makePort("L", go.Spot.Left, go.Spot.Left, true, false),
                                  makePort("R", go.Spot.Right, go.Spot.Right, true, false),
                                  makePort("B", go.Spot.Bottom, go.Spot.Bottom, true, false)
                                ));

                              self.myDiagram.nodeTemplateMap.add("Node",  // the default category
                                    self.$$(go.Node, "Table", nodeStyle(),
                                      // the main object is a Panel that surrounds a TextBlock with a rectangular Shape
                                      self.$$(go.Panel, "Auto",
                                        self.$$(go.Shape, "Rectangle",
                                          { name:'ITEM',fill: "#ffffff", stroke: "#000000", strokeWidth: 3.5 },
                                          new go.Binding("figure", "figure"),
                                                  new go.Binding("desiredSize","size",go.Size.parse).makeTwoWay(go.Size.stringify)
                            ),
                                        self.$$(go.TextBlock, textStyle(),
                                          {
                                            margin: 8,
                                            maxSize: new go.Size(400, NaN),
                                            wrap: go.TextBlock.WrapFit,
                                            editable: self.editable
                                          },
                                          new go.Binding("text").makeTwoWay())
                                      ),
                                      // four named ports, one on each side:
                                      makePort("T", go.Spot.Top, go.Spot.TopSide, false, true),
                                      makePort("L", go.Spot.Left, go.Spot.LeftSide, true, true),
                                      makePort("R", go.Spot.Right, go.Spot.RightSide, true, true),
                                      makePort("B", go.Spot.Bottom, go.Spot.BottomSide, true, false)
                                    ));

                              self.myDiagram.nodeTemplateMap.add("Conditional",
                                self.$$(go.Node, "Table", nodeStyle(),
                                  // the main object is a Panel that surrounds a TextBlock with a rectangular Shape
                                  self.$$(go.Panel, "Auto",
                                    self.$$(go.Shape, "Diamond",
                                      { name:'ITEM',fill: "#ffffff", stroke: "blue", strokeWidth: 3.5 },
                                      new go.Binding("figure", "figure"),
                                              new go.Binding("desiredSize","size",go.Size.parse).makeTwoWay(go.Size.stringify),
                        ),
                                    self.$$(go.TextBlock, textStyle(),
                                      {
                                        margin: 8,
                                        maxSize: new go.Size(160, NaN),
                                        wrap: go.TextBlock.WrapFit,
                                        editable: self.editable
                                      },
                                      new go.Binding("text").makeTwoWay())
                                  ),
                                  // four named ports, one on each side:
                                  makePort("T", go.Spot.Top, go.Spot.Top, false, true),
                                  makePort("L", go.Spot.Left, go.Spot.Left, true, true),
                                  makePort("R", go.Spot.Right, go.Spot.Right, true, true),
                                  makePort("B", go.Spot.Bottom, go.Spot.Bottom, true, false)
                                ));

                               self.myDiagram.nodeTemplateMap.add("End",
                                    self.$$(go.Node, "Table", nodeStyle(),
                                      self.$$(go.Panel, "Spot",
                                        self.$$(go.Shape, "Circle",
                                          { name:'ITEM', fill: "#ffffff", stroke: "red", strokeWidth: 3.5 },        new go.Binding("desiredSize","size",go.Size.parse).makeTwoWay(go.Size.stringify),
                            ),
                                        self.$$(go.TextBlock, textStyle(),
                                          {
                                            margin: 8,
                                            maxSize: new go.Size(160, NaN),
                                            wrap: go.TextBlock.WrapFit,
                                            editable: self.editable
                                          },
                                          new go.Binding("text").makeTwoWay())
                                      ),
                                      // three named ports, one on each side except the bottom, all input only:
                                      makePort("T", go.Spot.Top, go.Spot.Top, false, true),
                                      makePort("L", go.Spot.Left, go.Spot.Left, false, true),
                                      makePort("R", go.Spot.Right, go.Spot.Right, false, true)
                                    ));

                                  //taken from ../extensions/Figures.js:
                               go.Shape.defineFigureGenerator("File", function(shape, w, h) {
                                    var geo = new go.Geometry();
                                    var fig = new go.PathFigure(0, 0, true); // starting point
                                    geo.add(fig);
                                    fig.add(new go.PathSegment(go.PathSegment.Line, .75 * w, 0));
                                    fig.add(new go.PathSegment(go.PathSegment.Line, w, .25 * h));
                                    fig.add(new go.PathSegment(go.PathSegment.Line, w, h));
                                    fig.add(new go.PathSegment(go.PathSegment.Line, 0, h).close());
                                    var fig2 = new go.PathFigure(.75 * w, 0, false);
                                    geo.add(fig2);
                                    // The Fold
                                    fig2.add(new go.PathSegment(go.PathSegment.Line, .75 * w, .25 * h));
                                    fig2.add(new go.PathSegment(go.PathSegment.Line, w, .25 * h));
                                    geo.spot1 = new go.Spot(0, .25);
                                    geo.spot2 = go.Spot.BottomRight;
                                    return geo;
                                  });

                               self.myDiagram.nodeTemplateMap.add("Comment",
                                self.$$(go.Node, "Auto", nodeStyle(),
                                  self.$$(go.Shape, "File",
                                    { name:'ITEM',fill: "yellow", stroke: "#000000", strokeWidth: 3 },new go.Binding("desiredSize","size",go.Size.parse).makeTwoWay(go.Size.stringify)),
                                  self.$$(go.TextBlock, textStyle(),
                                    {
                                      margin: 8,
                                      maxSize: new go.Size(200, NaN),
                                      wrap: go.TextBlock.WrapFit,
                                      textAlign: "center",
                                      editable: self.editable
                                    },
                                    new go.Binding("text").makeTwoWay())
                                  // no ports, because no links are allowed to connect with a comment
                                ));
//===============================Palette=====================begin=======================================
                      this.myPalette.className = 'achworkflow_editor_palcanvas achworkflow_hidden';

//===============================Palette=====================end=======================================

                            //NODE END
                            //=================================

                              // replace the default Link template in the linkTemplateMap
                              self.myDiagram.linkTemplate =
                                self.$$(go.Link,  // the whole link panel
                                  {
                                    routing: go.Link.AvoidsNodes,
                                    curve: go.Link.JumpOver,
                                    corner: 5,
                                     toShortLength: 4,
                                    relinkableFrom: true,
                                    relinkableTo: true,
                                    reshapable: true,
                                    resegmentable: true,
                                    // mouse-overs subtly highlight links:
                                    //  mouseEnter: function(e, link) { link.findObject("HIGHLIGHT").stroke = "rgba(30,144,255,0.2)"; },
                                   // mouseLeave: function(e, link) { link.findObject("HIGHLIGHT").stroke = "transparent"; },

                                      selectionAdorned: true
                                  },
                                  new go.Binding("points").makeTwoWay(),
                                  self.$$(go.Shape,  // the highlight shape, normally transparent
                                    { isPanelMain: true, strokeWidth: 8, stroke: "transparent", name: "HIGHLIGHT" }),
                                  self.$$(go.Shape,  // the link path shape
                                    { isPanelMain: true, stroke: "gray", strokeWidth: 2 },
                                    new go.Binding("stroke", "isSelected", function(sel) { return sel ? "dodgerblue" : "gray"; }).ofObject()),
                                  self.$$(go.Shape,  // the arrowhead
                                    { toArrow: "standard", strokeWidth: 3, fill: "#339966" }),
                                  self.$$(go.Panel, "Auto",  // the link label, normally not visible
                                    { visible: false, name: "LABEL", segmentIndex: 2, segmentFraction: 0.5 },
                                    new go.Binding("visible", "visible").makeTwoWay(),
                                    self.$$(go.Shape, "RoundedRectangle",  // the label shape
                                      { fill: "#F8F8F8", strokeWidth: 0 }),
                                    self.$$(go.TextBlock, "Yes",  // the label
                                      {
                                        textAlign: "center",
                                        font: "15pt helvetica, arial, sans-serif",
                                        stroke: "#333333",
                                        editable: self.editable
                                      },
                                      new go.Binding("text").makeTwoWay())
                                  )
                                );


                            // temporary links used by LinkingTool and RelinkingTool are also orthogonal:
                          self.myDiagram.toolManager.linkingTool.temporaryLink.routing = go.Link.Orthogonal;
                          self.myDiagram.toolManager.relinkingTool.temporaryLink.routing = go.Link.Orthogonal;
                            //EVENT====================


                            //===========================================================
                             //helper
                             // This is a re-implementation of the default animation, except it fades in from downwards, instead of upwards.


                            function showLinkLabel(e) {
                                var label = e.subject.findObject("LABEL");
                                if (label !== null) label.visible = (e.subject.fromNode.data.category === "Conditional");
                              };



                              // Define a function for creating a "port" that is normally transparent.
                              // The "name" is used as the GraphObject.portId,
                              // the "align" is used to determine where to position the port relative to the body of the node,
                              // the "spot" is used to control how links connect with the port and whether the port
                              // stretches along the side of the node,
                              // and the boolean "output" and "input" arguments control whether the user can draw links from or to the port.
                              function makePort(name, align, spot, output, input) {
                                var horizontal = align.equals(go.Spot.Top) || align.equals(go.Spot.Bottom);
                                // the port is basically just a transparent rectangle that stretches along the side of the node,
                                // and becomes colored when the mouse passes over it
                                return self.$$(go.Shape,
                                  {
                                    fill: "transparent",  // changed to a color in the mouseEnter event handler
                                    strokeWidth: 0,  // no stroke
                                    width: horizontal ? NaN : 8,  // if not stretching horizontally, just 8 wide
                                    height: !horizontal ? NaN : 8,  // if not stretching vertically, just 8 tall
                                    alignment: align,  // align the port on the main Shape
                                    stretch: (horizontal ? go.GraphObject.Horizontal : go.GraphObject.Vertical),
                                    portId: name,  // declare this object to be a "port"
                                    fromSpot: spot,  // declare where links may connect at this port
                                    fromLinkable: output,  // declare whether the user may draw links from here
                                    toSpot: spot,  // declare where links may connect at this port
                                    toLinkable: input,  // declare whether the user may draw links to here
                                    cursor: "pointer",  // show a different cursor to indicate potential link point
                                    mouseEnter: function(e, port) {  // the PORT argument will be this Shape
                                      if (!e.diagram.isReadOnly) port.fill = "rgba(255,0,255,0.5)";
                                    },
                                    mouseLeave: function(e, port) {
                                      port.fill = "transparent";
                                    }
                                  });
                              };

                              function textStyle() {
                                return {
                                  font: "bold 18pt Lato, Helvetica, Arial, sans-serif",
                                  stroke: "#000000"
                                }
                              };

                              //helper end==============================


             //====================================init_go end tag============
             },
             //====================================init_editgo readonly tag============

            //=============================================================



      
    });

    field_registry.add('field_achworkflow_chart', FieldACHWorkflowChart);


 
    
});
