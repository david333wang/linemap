odoo.define('achworkflow.workflowfrontuichart', function (require) {
    "use strict";
   
    var field_registry = require('web.field_registry');
    var fields = require('web.basic_fields');
    var core = require('web.core');

    var utils =require('web.field_utils');
    var qweb = core.qweb;
    var _t = core._t;
    var _lt = core._lt;

    var FieldACHWorkflowfrontChart = fields.FieldChar.extend({
            widget_class: 'o_form_field_flow_chart',
            template: 'FieldACHWorkflowfrontChart',
            events: { 'click #print':'_printDiagram' },
             //--------------------------------------------------------------------------
            // Public
            //--------------------------------------------------------------------------


            /**
             * @override
             */
             init: function()
             {
                this.workflowdesign = null;
                 this.initialized = false;
                  this.myDiagram = false ;
                   this.myPalette = false ;
                   this.editable = false;
                    this.passednode = null;

                  this.default = { "class": "go.GraphLinksModel",
                    "linkFromPortIdProperty": "fromPort",
                    "linkToPortIdProperty": "toPort",
                    "nodeDataArray": [
                  ],
                    "linkDataArray": [
                  ]};
                   this.$$ = go.GraphObject.make;  // for conciseness in defining templates
                   this.idag = null;
                   this.myDiagram = false ;
                   return this._super.apply(this, arguments);

             },

            start: function () {
             this.editable = false;
             if(this.mode=="edit")
             {
                this.editable = true;
             }
              this.workflowdesign = this.$(".achworkflow_editor_divcanvas")[0];


              return this._super.apply(this, arguments);
            },

            load:function(){
                var self=this;
                 var show_value = self._formatValue(self.value) ? self.value : JSON.stringify(self.default)

                 self.myDiagram.model = go.Model.fromJson(show_value);

            },
          _getValue: function () {
            var $input = this.$el.find('input');

            var val = $input.val();


            return $input.val();


        },
         _renderEdit: function () {
           this._renderReadonly();
         },

         _renderReadonly: function () {
            //this._super.apply(this, arguments);
            return Promise.resolve().then(() => {
                // Prevent Double Rendering on Updates
                if (!this.myDiagram) {
                    this.init_go_readonly();
                    this.load();

                }
                else
                {
                     this.load();
                }
            });
         },
      _printDiagram:function() {
        var self=this;
      var svgWindow = window.open();
      if (!svgWindow) return;  // failure to open a new Window
      var printSize = new go.Size(700, 960);
      var bnds = self.myDiagram.documentBounds;
      var x = bnds.x;
      var y = bnds.y;
      while (y < bnds.bottom) {
        while (x < bnds.right) {
          var svg = self.myDiagram.makeSVG({ scale: 1.0, position: new go.Point(x, y), size: printSize });
          svgWindow.document.body.appendChild(svg);
          x += printSize.width;
        }
        x = bnds.x;
        y += printSize.height;
      }
      setTimeout(function() { svgWindow.print(); }, 1);
    },


            /**
             * @override
             */
            destroy: function () {

                this._super.apply(this, arguments);
            },



              //--------------------------------------------------------------------------
            // Private
            //--------------------------------------------------------------------------




              /**
             * Starts the ace library on the given DOM element. This initializes the
             * ace editor option according to the edit/readonly mode and binds ace
             * editor events.
             *
             * @private
             * @param {Node} node - the DOM element the ace library must initialize on
             */


                //=============================gojs init_go_reaonly===================================
            init_go_readonly:function(){
                          var self=this;
                              //prive gojs function
                                 function nodeStyle() {
                                    return [
                                    new go.Binding("angle").makeTwoWay(),
                                    new go.Binding("desiredSize","size",go.Size.parse).makeTwoWay(go.Size.stringify),
                                      // The Node.location comes from the "loc" property of the node data,
                                      // converted by the Point.parse static method.
                                      // If the Node.location is changed, it updates the "loc" property of the node data,
                                      // converting back using the Point.stringify static method.
                                      new go.Binding("location", "loc", go.Point.parse).makeTwoWay(go.Point.stringify),
                                      {
                                        // the Node.location is at the center of each node
                                        locationSpot: go.Spot.Center,
                                        resizable:false,
                                        rotatable:false,
                                        resizeObjectName:'ITEM',
                                        selectionObjectName:'ITEM'

                                      }
                                    ];
                              };
                              //=================================

                        //===========================================================
                          self.myDiagram =
                            self.$$(go.Diagram, this.workflowdesign ,  // must name or refer to the DIV HTML element
                              {
                                "LinkDrawn": showLinkLabel,  // this DiagramEvent listener is defined below
                                "LinkRelinked": showLinkLabel,
                                 'scale':0.5,
                                "zoomToFit":true,
                                "allowDelete":false,
                                'contentAlignment':go.Spot.Top,
                                "isReadOnly": true,
                                "contextMenuTool.isEnabled":false,

//                                "grid.visible":true,
//                                "grid.gridCellSize":new go.Size(50,50),
//                                "draggingTool.isGridSnapEnabled":true,
//                                "draggingTool.gridSnapCellSize":new go.Size(50,50),
                                "initialContentAlignment": go.Spot.Center,  // center the content

                                  // enable undo & redo
                              });

                                             self.myDiagram.contextMenu =
                  $("ContextMenu",


                    // no binding, always visible button:
                    $("ContextMenuButton",
                      $(go.TextBlock, "New Node"),
                      { click: function(e, obj) {
                        e.diagram.commit(function(d) {

                        }, 'new node');
                      } })
                  );

// 1 passed C2185B 2 reject 4CAF50
                            //NODE ===================
                   self.myDiagram.nodeTemplateMap.add("Start1",
                                self.$$(go.Node, "Table", nodeStyle(),
                                  self.$$(go.Panel, "Spot",
                                    self.$$(go.Shape, "Circle",
                                      {name:'ITEM', fill: "transparent", stroke: "#C2185B", strokeWidth: 3.5 },
                                      new go.Binding("desiredSize","size",go.Size.parse).makeTwoWay(go.Size.stringify),
                        ),

                                   self.$$(go.TextBlock, textStyle(),
                                      {
                                        margin: 8,
                                        maxSize: new go.Size(160, NaN),
                                        wrap: go.TextBlock.WrapFit,
                                        editable: false
                                      },
                                      new go.Binding("text").makeTwoWay())
                                  ),
                                  // three named ports, one on each side except the top, all output only:
                                  makePort("L", go.Spot.Left, go.Spot.Left, true, false),
                                  makePort("R", go.Spot.Right, go.Spot.Right, true, false),
                                  makePort("B", go.Spot.Bottom, go.Spot.Bottom, true, false)
                                ));

                    self.myDiagram.nodeTemplateMap.add("Start2",
                                self.$$(go.Node, "Table", nodeStyle(),
                                  self.$$(go.Panel, "Spot",
                                    self.$$(go.Shape, "Circle",
                                      {name:'ITEM', fill: "transparent", stroke: "#4CAF50", strokeWidth: 3.5 },
                                      new go.Binding("desiredSize","size",go.Size.parse).makeTwoWay(go.Size.stringify),
                        ),

                                   self.$$(go.TextBlock, textStyle(),
                                      {
                                        margin: 8,
                                        maxSize: new go.Size(160, NaN),
                                        wrap: go.TextBlock.WrapFit,
                                        editable: false
                                      },
                                      new go.Binding("text").makeTwoWay())
                                  ),
                                  // three named ports, one on each side except the top, all output only:
                                  makePort("L", go.Spot.Left, go.Spot.Left, true, false),
                                  makePort("R", go.Spot.Right, go.Spot.Right, true, false),
                                  makePort("B", go.Spot.Bottom, go.Spot.Bottom, true, false)
                                ));

                    self.myDiagram.nodeTemplateMap.add("Start",
                                self.$$(go.Node, "Table", nodeStyle(),
                                  self.$$(go.Panel, "Spot",
                                    self.$$(go.Shape, "Circle",
                                      {name:'ITEM', fill: "transparent", stroke: "#339966", strokeWidth: 3.5 },
                                      new go.Binding("desiredSize","size",go.Size.parse).makeTwoWay(go.Size.stringify),
                        ),

                                   self.$$(go.TextBlock, textStyle(),
                                      {
                                        margin: 8,
                                        maxSize: new go.Size(160, NaN),
                                        wrap: go.TextBlock.WrapFit,
                                        editable: false
                                      },
                                      new go.Binding("text").makeTwoWay())
                                  ),
                                  // three named ports, one on each side except the top, all output only:
                                 // makePort("L", go.Spot.Left, go.Spot.Left, true, false),
                                 // makePort("R", go.Spot.Right, go.Spot.Right, true, false),
                                  //makePort("B", go.Spot.Bottom, go.Spot.Bottom, true, false)
                                ));

                    self.myDiagram.nodeTemplateMap.add("Node1",  // the default category
                                    self.$$(go.Node, "Table", nodeStyle(),
                                      // the main object is a Panel that surrounds a TextBlock with a rectangular Shape
                                      self.$$(go.Panel, "Auto",
                                        self.$$(go.Shape, "Rectangle",
                                          { name:'ITEM',fill: "#ffffff", stroke: "#C2185B", strokeWidth: 3.5 },
                                          new go.Binding("figure", "figure"),
                                                  new go.Binding("desiredSize","size",go.Size.parse).makeTwoWay(go.Size.stringify)
                            ),
                                        self.$$(go.TextBlock, textStyle(),
                                          {
                                            margin: 8,
                                            maxSize: new go.Size(400, NaN),
                                            wrap: go.TextBlock.WrapFit,
                                            editable: self.editable
                                          },
                                          new go.Binding("text").makeTwoWay())
                                      ),
                                      // four named ports, one on each side:
                                      makePort("T", go.Spot.Top, go.Spot.TopSide, false, true),
                                      makePort("L", go.Spot.Left, go.Spot.LeftSide, true, true),
                                      makePort("R", go.Spot.Right, go.Spot.RightSide, true, true),
                                      makePort("B", go.Spot.Bottom, go.Spot.BottomSide, true, false)
                                    ));

                    self.myDiagram.nodeTemplateMap.add("Node2",  // the default category
                                    self.$$(go.Node, "Table", nodeStyle(),
                                      // the main object is a Panel that surrounds a TextBlock with a rectangular Shape
                                      self.$$(go.Panel, "Auto",
                                        self.$$(go.Shape, "Rectangle",
                                          { name:'ITEM',fill: "#ffffff", stroke: "#4CAF50", strokeWidth: 3.5 },
                                          new go.Binding("figure", "figure"),
                                                  new go.Binding("desiredSize","size",go.Size.parse).makeTwoWay(go.Size.stringify)
                            ),
                                        self.$$(go.TextBlock, textStyle(),
                                          {
                                            margin: 8,
                                            maxSize: new go.Size(400, NaN),
                                            wrap: go.TextBlock.WrapFit,
                                            editable: self.editable
                                          },
                                          new go.Binding("text").makeTwoWay())
                                      ),
                                      // four named ports, one on each side:
                                      makePort("T", go.Spot.Top, go.Spot.TopSide, false, true),
                                      makePort("L", go.Spot.Left, go.Spot.LeftSide, true, true),
                                      makePort("R", go.Spot.Right, go.Spot.RightSide, true, true),
                                      makePort("B", go.Spot.Bottom, go.Spot.BottomSide, true, false)
                                    ));

                    self.myDiagram.nodeTemplateMap.add("Node",  // the default category
                                    self.$$(go.Node, "Table", nodeStyle(),
                                      // the main object is a Panel that surrounds a TextBlock with a rectangular Shape
                                      self.$$(go.Panel, "Auto",
                                        self.$$(go.Shape, "Rectangle",
                                          { name:'ITEM',fill: "#ffffff", stroke: "#339966", strokeWidth: 3.5 },
                                          new go.Binding("figure", "figure"),
                                                  new go.Binding("desiredSize","size",go.Size.parse).makeTwoWay(go.Size.stringify)
                            ),
                                        self.$$(go.TextBlock, textStyle(),
                                          {
                                            margin: 8,
                                            maxSize: new go.Size(400, NaN),
                                            wrap: go.TextBlock.WrapFit,
                                            editable: self.editable
                                          },
                                          new go.Binding("text").makeTwoWay())
                                      ),
                                      // four named ports, one on each side:
                                      makePort("T", go.Spot.Top, go.Spot.TopSide, false, true),
                                      makePort("L", go.Spot.Left, go.Spot.LeftSide, true, true),
                                      makePort("R", go.Spot.Right, go.Spot.RightSide, true, true),
                                      makePort("B", go.Spot.Bottom, go.Spot.BottomSide, true, false)
                                    ));
                    self.myDiagram.nodeTemplateMap.add("Conditional",

                    self.$$(go.Node, "Table", nodeStyle(),
                                  // the main object is a Panel that surrounds a TextBlock with a rectangular Shape
                                  self.$$(go.Panel, "Auto",
                                    self.$$(go.Shape, "Diamond",
                                      { name:'ITEM',fill: "#ffffff", stroke: "#eeeeee",  strokeWidth: 3.5 },
                                      new go.Binding("figure", "figure"),
                                              new go.Binding("desiredSize","size",go.Size.parse).makeTwoWay(go.Size.stringify),
                        ),
                                    self.$$(go.TextBlock, textStyle(),
                                      {
                                        margin: 8,
                                        maxSize: new go.Size(160, NaN),
                                        wrap: go.TextBlock.WrapFit,
                                        editable: self.editable
                                      },
                                      new go.Binding("text").makeTwoWay())
                                  ),
                                  // four named ports, one on each side:
                                  makePort("T", go.Spot.Top, go.Spot.Top, false, true),
                                  makePort("L", go.Spot.Left, go.Spot.Left, true, true),
                                  makePort("R", go.Spot.Right, go.Spot.Right, true, true),
                                  makePort("B", go.Spot.Bottom, go.Spot.Bottom, true, false)
                                ));

                    self.myDiagram.nodeTemplateMap.add("Conditional1",
                                 self.$$(go.Node, "Table", nodeStyle(),
                                  // the main object is a Panel that surrounds a TextBlock with a rectangular Shape
                                  self.$$(go.Panel, "Auto",
                                    self.$$(go.Shape, "Diamond",
                                      { name:'ITEM',fill: "#ffffff", stroke: "#C2185B",  strokeWidth: 3.5 },
                                      new go.Binding("figure", "figure"),
                                              new go.Binding("desiredSize","size",go.Size.parse).makeTwoWay(go.Size.stringify),
                        ),
                                    self.$$(go.TextBlock, textStyle(),
                                      {
                                        margin: 8,
                                        maxSize: new go.Size(160, NaN),
                                        wrap: go.TextBlock.WrapFit,
                                        editable: self.editable
                                      },
                                      new go.Binding("text").makeTwoWay())
                                  ),
                                  // four named ports, one on each side:
                                  makePort("T", go.Spot.Top, go.Spot.Top, false, true),
                                  makePort("L", go.Spot.Left, go.Spot.Left, true, true),
                                  makePort("R", go.Spot.Right, go.Spot.Right, true, true),
                                  makePort("B", go.Spot.Bottom, go.Spot.Bottom, true, false)
                                ));

                    self.myDiagram.nodeTemplateMap.add("Conditional2",
                                 self.$$(go.Node, "Table", nodeStyle(),
                                  // the main object is a Panel that surrounds a TextBlock with a rectangular Shape
                                  self.$$(go.Panel, "Auto",
                                    self.$$(go.Shape, "Diamond",
                                      { name:'ITEM',fill: "#ffffff", stroke: "#4CAF50",  strokeWidth: 3.5 },
                                      new go.Binding("figure", "figure"),
                                              new go.Binding("desiredSize","size",go.Size.parse).makeTwoWay(go.Size.stringify),
                        ),
                                    self.$$(go.TextBlock, textStyle(),
                                      {
                                        margin: 8,
                                        maxSize: new go.Size(160, NaN),
                                        wrap: go.TextBlock.WrapFit,
                                        editable: self.editable
                                      },
                                      new go.Binding("text").makeTwoWay())
                                  ),
                                  // four named ports, one on each side:
                                  makePort("T", go.Spot.Top, go.Spot.Top, false, true),
                                  makePort("L", go.Spot.Left, go.Spot.Left, true, true),
                                  makePort("R", go.Spot.Right, go.Spot.Right, true, true),
                                  makePort("B", go.Spot.Bottom, go.Spot.Bottom, true, false)
                                ));

                    self.myDiagram.nodeTemplateMap.add("End1",
                                    self.$$(go.Node, "Table", nodeStyle(),
                                      self.$$(go.Panel, "Spot",
                                        self.$$(go.Shape, "Circle",
                                          { name:'ITEM', fill: "#ffffff", stroke: "#C2185B",  strokeWidth: 3.5 },        new go.Binding("desiredSize","size",go.Size.parse).makeTwoWay(go.Size.stringify),
                            ),
                                        self.$$(go.TextBlock, textStyle(),
                                          {
                                            margin: 8,
                                            maxSize: new go.Size(160, NaN),
                                            wrap: go.TextBlock.WrapFit,
                                            editable: self.editable
                                          },
                                          new go.Binding("text").makeTwoWay())
                                      ),
                                      // three named ports, one on each side except the bottom, all input only:
                                      makePort("T", go.Spot.Top, go.Spot.Top, false, true),
                                      makePort("L", go.Spot.Left, go.Spot.Left, false, true),
                                      makePort("R", go.Spot.Right, go.Spot.Right, false, true)
                                    ));

                    self.myDiagram.nodeTemplateMap.add("End2",
                                    self.$$(go.Node, "Table", nodeStyle(),
                                      self.$$(go.Panel, "Spot",
                                        self.$$(go.Shape, "Circle",
                                          { name:'ITEM', fill: "#ffffff", stroke: "#4CAF50",  strokeWidth: 3.5 },        new go.Binding("desiredSize","size",go.Size.parse).makeTwoWay(go.Size.stringify),
                            ),
                                        self.$$(go.TextBlock, textStyle(),
                                          {
                                            margin: 8,
                                            maxSize: new go.Size(160, NaN),
                                            wrap: go.TextBlock.WrapFit,
                                            editable: self.editable
                                          },
                                          new go.Binding("text").makeTwoWay())
                                      ),
                                      // three named ports, one on each side except the bottom, all input only:
                                      makePort("T", go.Spot.Top, go.Spot.Top, false, true),
                                      makePort("L", go.Spot.Left, go.Spot.Left, false, true),
                                      makePort("R", go.Spot.Right, go.Spot.Right, false, true)
                                    ));


                    self.myDiagram.nodeTemplateMap.add("End",
                                    self.$$(go.Node, "Table", nodeStyle(),
                                      self.$$(go.Panel, "Spot",
                                        self.$$(go.Shape, "Circle",
                                          { name:'ITEM', fill: "#ffffff", stroke: "#339966",  strokeWidth: 3.5 },        new go.Binding("desiredSize","size",go.Size.parse).makeTwoWay(go.Size.stringify),
                            ),
                                        self.$$(go.TextBlock, textStyle(),
                                          {
                                            margin: 8,
                                            maxSize: new go.Size(160, NaN),
                                            wrap: go.TextBlock.WrapFit,
                                            editable: self.editable
                                          },
                                          new go.Binding("text").makeTwoWay())
                                      ),
                                      // three named ports, one on each side except the bottom, all input only:
                                      makePort("T", go.Spot.Top, go.Spot.Top, false, true),
                                      makePort("L", go.Spot.Left, go.Spot.Left, false, true),
                                      makePort("R", go.Spot.Right, go.Spot.Right, false, true)
                                    ));

                                  //taken from ../extensions/Figures.js:
                    go.Shape.defineFigureGenerator("File", function(shape, w, h) {
                                    var geo = new go.Geometry();
                                    var fig = new go.PathFigure(0, 0, true); // starting point
                                    geo.add(fig);
                                    fig.add(new go.PathSegment(go.PathSegment.Line, .75 * w, 0));
                                    fig.add(new go.PathSegment(go.PathSegment.Line, w, .25 * h));
                                    fig.add(new go.PathSegment(go.PathSegment.Line, w, h));
                                    fig.add(new go.PathSegment(go.PathSegment.Line, 0, h).close());
                                    var fig2 = new go.PathFigure(.75 * w, 0, false);
                                    geo.add(fig2);
                                    // The Fold
                                    fig2.add(new go.PathSegment(go.PathSegment.Line, .75 * w, .25 * h));
                                    fig2.add(new go.PathSegment(go.PathSegment.Line, w, .25 * h));
                                    geo.spot1 = new go.Spot(0, .25);
                                    geo.spot2 = go.Spot.BottomRight;
                                    return geo;
                                  });

                    self.myDiagram.nodeTemplateMap.add("Comment",
                                 self.$$(go.Node, "Auto", nodeStyle(),
                                  self.$$(go.Shape, "File",
                                    { name:'ITEM',fill: "#eeeeee", stroke: "#339966",  strokeWidth: 3 },new go.Binding("desiredSize","size",go.Size.parse).makeTwoWay(go.Size.stringify)),
                                  self.$$(go.TextBlock, textStyle(),
                                    {
                                      margin: 8,
                                      maxSize: new go.Size(200, NaN),
                                      wrap: go.TextBlock.WrapFit,
                                      textAlign: "center",
                                      editable: false
                                    },
                                    new go.Binding("text").makeTwoWay())
                                  // no ports, because no links are allowed to connect with a comment
                              ));


                     //NODE END
                     //=================================

                    // replace the default Link template in the linkTemplateMap
                    self.myDiagram.linkTemplate =
                                self.$$(go.Link,  // the whole link panel
                                  {
                                    routing: go.Link.AvoidsNodes,
                                   // curve: go.Link.JumpOver,
                                   // corner: 5, toShortLength: 4,
                                    relinkableFrom: true,
                                    relinkableTo: true,
                                    reshapable: true,
                                    resegmentable: true,
                                    // mouse-overs subtly highlight links:
                                    mouseEnter: function(e, link) { link.findObject("HIGHLIGHT").stroke = "rgba(30,144,255,0.2)"; },
                                    mouseLeave: function(e, link) { link.findObject("HIGHLIGHT").stroke = "transparent"; },
                                    selectionAdorned: false
                                  },
                                  new go.Binding("points").makeTwoWay(),
                                  self.$$(go.Shape,  // the highlight shape, normally transparent
                                    { isPanelMain: true, strokeWidth: 0, stroke: "transparent", name: "HIGHLIGHT" }),

                                  self.$$(go.Shape,  // the link path shape
                                    { isPanelMain: true, fill: "#339966", strokeWidth: 2 },
                                    new go.Binding("stroke", "isSelected", function(sel) { return sel ? "#339966" : "gray"; }).ofObject()),

                                  self.$$(go.Shape,  // the arrowhead
                                    { toArrow: "standard", strokeWidth: 3, fill: "#339966" }),
                                  self.$$(go.Panel, "Auto",  // the link label, normally not visible
                                    { visible: false, name: "LABEL", segmentIndex: 2, segmentFraction: 0.5 },
                                    new go.Binding("visible", "visible").makeTwoWay(),
                                    self.$$(go.Shape, "RoundedRectangle",  // the label shape
                                      { fill: "#339966", strokeWidth: 0 }),
                                    self.$$(go.TextBlock, "Yes",  // the label
                                      {
                                        textAlign: "center",
                                        font: "15pt helvetica, arial, sans-serif",
                                        stroke: "#333333",
                                        editable: false
                                      },
                                      new go.Binding("text").makeTwoWay())
                                  )
                                );

                                //]]]]]]]


                                //]]]]]]]]


                            // temporary links used by LinkingTool and RelinkingTool are also orthogonal:
                    self.myDiagram.toolManager.linkingTool.temporaryLink.routing = go.Link.Normal;
                    self.myDiagram.toolManager.relinkingTool.temporaryLink.routing = go.Link.Normal;

                    self.myDiagram.addDiagramListener("InitialLayoutCompleted", function(e){
                            //============================

                             self.myDiagram.commit(function(d) {
                             d.nodes.each(function(node) {
                               if(node.key==-1)
                               {
                                node.fill = "red";
                                node.text = "1111111111";
                               }
                              });

                             },"d");


                             //=====================
                            });
                            //============================================

                            //EVENT====================

                           self.myDiagram.div.style.width = '99.9%';
                           self.myDiagram.requestUpdate();

                            //===========================================================
                             //helper


                    function showLinkLabel(e) {
                                var label = e.subject.findObject("LABEL");
                                if (label !== null) label.visible = (e.subject.fromNode.data.category === "Conditional");
                              };



                              // Define a function for creating a "port" that is normally transparent.
                              // The "name" is used as the GraphObject.portId,
                              // the "align" is used to determine where to position the port relative to the body of the node,
                              // the "spot" is used to control how links connect with the port and whether the port
                              // stretches along the side of the node,
                              // and the boolean "output" and "input" arguments control whether the user can draw links from or to the port.
                    function makePort(name, align, spot, output, input) {
                                var horizontal = align.equals(go.Spot.Top) || align.equals(go.Spot.Bottom);
                                // the port is basically just a transparent rectangle that stretches along the side of the node,
                                // and becomes colored when the mouse passes over it
                                return self.$$(go.Shape,
                                  {
                                    fill: "transparent",  // changed to a color in the mouseEnter event handler
                                    strokeWidth: 0,  // no stroke
                                    width: horizontal ? NaN : 8,  // if not stretching horizontally, just 8 wide
                                    height: !horizontal ? NaN : 8,  // if not stretching vertically, just 8 tall
                                    alignment: align,  // align the port on the main Shape
                                    stretch: (horizontal ? go.GraphObject.Horizontal : go.GraphObject.Vertical),
                                    portId: name,  // declare this object to be a "port"
                                    fromSpot: spot,  // declare where links may connect at this port
                                    fromLinkable: output,  // declare whether the user may draw links from here
                                    toSpot: spot,  // declare where links may connect at this port
                                    toLinkable: input,  // declare whether the user may draw links to here
                                    cursor: "pointer",  // show a different cursor to indicate potential link point
                                    mouseEnter: function(e, port) {  // the PORT argument will be this Shape
                                      if (!e.diagram.isReadOnly) port.fill = "rgba(255,0,255,0.5)";
                                    },
                                    mouseLeave: function(e, port) {
                                      port.fill = "transparent";
                                    }
                                  });
                              };

                              function textStyle() {
                                return {
                                  font: "bold 18pt Lato, Helvetica, Arial, sans-serif",
                                  stroke: "#000000"
                                }
                              };

                              //helper end==============================
//
//
//                            var shape = node.findObject("SHAPE");
//                            shape.fill = "red";




             //====================================init_go end tag============
             },
             //====================================init_editgo readonly tag============

            //=============================================================



      
    });

    field_registry.add('field_achworkflow_frontchart', FieldACHWorkflowfrontChart);


 
    
});
