# -*- coding: utf-8 -*-
{
    'name': "ach_frontui_workflow",

    'summary': """
 workflow image design tool    """,

    'author': "ach",
    'website': "",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/14.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'tools/ach_ui_workflow',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        # 'security/workflow_security.xml',

        'views/assets.xml',
        # 'views/views.xml',
    ],
    # only loaded in demonstration mode
      "qweb": [
        "static/src/xml/qweb.xml",
    ],
    'installable': True,
    'auto_install': False,
    'application': False,
}
