# -*- coding: utf-8 -*-

from odoo import models, fields, api


class ach_frontui_workflow(models.Model):
    _name = 'ach_frontui_workflow.ach_frontui_workflow'
    _description = 'ach_frontui_workflow.ach_frontui_workflow'

    name = fields.Char()


    nametxt = fields.Char()
    nametxt1 = fields.Char()
    company_id = fields.Many2one('res.company', string='Company', required=True, readonly=True,
        default=lambda self: self.env.company)