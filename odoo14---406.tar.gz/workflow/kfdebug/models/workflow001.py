# -*- coding: utf-8 -*-

from odoo import models, fields, api


class workflow001(models.Model):
    _name = 'kfdebug.workflow001'
    _description = 'kfdebug.workflow001'
    _inherit = ['achworkflow.achrworkflowmixin', 'mail.thread', 'mail.activity.mixin']


    active = fields.Boolean(default=True,
                            help="If the active field is set to False, it will allow you to hide the project without removing it.")







    name = fields.Char(string='name3')
    value = fields.Integer()
    description = fields.Text()

