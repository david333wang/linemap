# -*- coding: utf-8 -*-

from odoo import models, fields, api


class workflow002(models.Model):
    _name = 'kfdebug.workflow002'
    _description = 'kfdebug.workflow002'
    _inherit = ['achworkflow.achrworkflowmixin']


    active = fields.Boolean(default=True,
                            help="If the active field is set to False, it will allow you to hide the project without removing it.")
    name = fields.Char(string='name3')
    value = fields.Integer()
    description = fields.Text()
    company_id = fields.Many2one('res.company', string='Company', required=True, readonly=True,
                                 default=lambda self: self.env.company)
    state = fields.Selection(selection=[
            ('draft', 'Draft'),
            ('posted', 'Posted'),
            ('cancel', 'Cancelled'),
        ], string='Status', required=True, readonly=True, copy=False, tracking=True,
        default='draft')
    line_ids = fields.One2many('kfdebug.workflow002line', 'workflow002id', string='workflow2')

class workflow002line(models.Model):
    _name = 'kfdebug.workflow002line'

    workflow002id = fields.Many2one('kfdebug.workflow002', string='workflow2')
    name = fields.Char(string='name3')
    value = fields.Integer()
