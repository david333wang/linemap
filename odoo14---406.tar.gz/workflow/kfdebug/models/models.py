# -*- coding: utf-8 -*-
import datetime

from odoo import api, fields, models, tools, SUPERUSER_ID, _


class wodebug001(models.Model):
    _name = 'kfdebug.wodebug001'
    _description = 'kfdebug.wodebug001'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'image.mixin']


    active = fields.Boolean(default=True,
                            help="If the active field is set to False, it will allow you to hide the project without removing it.")



    partner_id = fields.Many2one('res.partner', 'Responsible')
    guest_ids = fields.Many2many('res.partner', 'Participants')

    signs22 = fields.Image("dd")
    signs1 = fields.Image("1")
    signs2 = fields.Image("2")



    name = fields.Char(string='name1', tracking=True)
    value = fields.Integer(tracking=1)
    value2 = fields.Float(compute="_value_pc", store=True)
    description = fields.Text()
    wodebug002 = fields.One2many('kfdebug.wodebug002', 'debug002', "debug002")


    def action_test(self):
        myapp_id = self.env['ir.module.category'].sudo().search([('name', '=', 'achworkflow')], limit=1)
        if myapp_id:
            user_groupids = self.env['res.groups'].sudo().search([('category_id', '=', myapp_id.id)])
            if user_groupids:
                for user_groupid in user_groupids:
                    self.message_subscribe(partner_ids=user_groupid.users.partner_id.ids)

        odoobot = self.env.ref('base.partner_root')
        refs = ["<a href=# data-oe-model=kfdebug.wodebug001 data-oe-id=%s>%s</a>" % (self.id, self.name)]
        message = _("This  bill is from: %s") % ','.join(refs)

        self.message_post(body=message,
                              message_type='comment',
                              subtype_xmlid='mail.mt_note',
                              author_id=odoobot.id)

        expiration_date = datetime.datetime.now() + datetime.timedelta(hours=1)

        self.sudo().activity_schedule('kfdebug.mail_act_workflow', summary='todo', note=message, date_deadline=expiration_date, user_id=self.env.uid)

        if self.env['ir.config_parameter'].sudo().get_param('achworkflow.workflowmessageflag', False):
            # 增加关注和发送信息
            pass
        if self.env['ir.config_parameter'].sudo().get_param('achworkflow.workflowactivityflag', False):
            # 给待办增加工作规划

            pass
        return False


    @api.depends('value')
    def _value_pc(self):
        for record in self:
            record.value2 = float(record.value) / 100
    # @api.model
    # def action_compute_attached_docs_count(self):
    #     res = super(wodebug001, self)._compute_mixin_attached_docs_count(self)
    #     return res

    def attachment_tree_view(self):
        msg = 'i will go to trip'
        msg_subject = _("my name:%s", self.name)
        odoobot_id = self.env['ir.model.data'].xmlid_to_res_id("base.partner_root")
        self.message_post(body=msg, author_id=odoobot_id, subject=msg_subject)

        # partners = self.env['res.partner'].search([('id', '>', 0)])
        # self.message_subscribe(partner_ids=partners.ids)
        #
        groupid = self.env.ref('resourcecalendar.module_resourcecalendar_category').id
        mu = self.env['res.groups'].sudo().search([('name', '=', 'Administrator'), ('category_id', '=', groupid)])
        users1 = self.env['res.users'].search([('groups_id', 'in', mu.id)])
        if users1:
            for user in users1:
                self.message_subscribe(partner_ids=user.partner_id.ids)
        # =======================================
        channel = self.env['mail.channel'].browse(1)
        notification = _(
            '<div class="o_mail_notification">%(author)s invited %(new_partner)s to <a href="#" class="o_channel_redirect" data-oe-id="%(channel_id)s">#%(channel_name)s</a></div>',
            author=self.env.user.display_name,
            new_partner=self.env.user.display_name,
            channel_id=channel.id,
            channel_name=channel.name,
            )
        # partners = self.env['res.partner'].search([('id', '>', 0)])
        # channel.channel_invite({1,2})
        # {'attachment_ids': [], 'body': '7878787878785gvcv', 'channel_ids': [], 'partner_ids': [],
        #  'subtype_xmlid': 'mail.mt_comment'}
        channel.message_post(body=notification, attachment_ids=[1], subtype_xmlid='mail.mt_comment', message_type='comment')
        # channel.notify_typing(True)

        return self

    #
    #
    # @api.model
    # def create(self, vals):
    #     flds = self.fields_get()
    #     for fldobj in flds:
    #         if 'tracking' in flds.get(fldobj):
    #             pass
    #
    #             self.activity_reschedule(['fleet.mail_act_fleet_contract_to_renew'], date_deadline=vals.get('expiration_date'), new_user_id=vals.get('user_id'))
    def _creation_subtype(self):
        return self.env.ref('maintenance.mt_req_created')

    def _track_subtype(self, init_values):
        self.ensure_one()
        if 'stage_id' in init_values:
            return self.env.ref('maintenance.mt_req_status')
        return super(wodebug001, self)._track_subtype(init_values)


    def _add_followers(self):
        for request in self:
            partner_ids = (request.owner_user_id.partner_id + request.user_id.partner_id).ids
            request.message_subscribe(partner_ids=partner_ids)

    def activity_update(self):
        """ Update maintenance activities based on current record set state.
        It reschedule, unlink or create maintenance request activities. """
        # self.filtered(lambda request: not request.schedule_date).activity_unlink(['maintenance.mail_act_maintenance_request'])
        # for request in self.filtered(lambda request: request.schedule_date):
        #     date_dl = fields.Datetime.from_string(request.schedule_date).date()
        #     updated = request.activity_reschedule(
        #         ['maintenance.mail_act_maintenance_request'],
        #         date_deadline=date_dl,
        #         new_user_id=request.user_id.id or request.owner_user_id.id or self.env.uid)
        #     if not updated:
        #         if request.equipment_id:
        #             note = _('Request planned for <a href="#" data-oe-model="%s" data-oe-id="%s">%s</a>') % (
        #                 request.equipment_id._name, request.equipment_id.id, request.equipment_id.display_name)
        #         else:
        #             note = False
        #         request.activity_schedule(
        #             'maintenance.mail_act_maintenance_request',
        #             fields.Datetime.from_string(request.schedule_date).date(),
        #             note=note, user_id=request.user_id.id or request.owner_user_id.id or self.env.uid)

