# -*- coding: utf-8 -*-

from odoo import models, fields, api


class workflow003(models.Model):
    _name = 'kfdebug.workflow003'
    _description = 'kfdebug.workflow003'
    _inherit = ['achworkflow.achrworkflowmixin']


    active = fields.Boolean(default=True,
                            help="If the active field is set to False, it will allow you to hide the project without removing it.")

    name = fields.Char(string='name3')
    value = fields.Integer()
    description = fields.Text()
    signs22 = fields.Image("dd")

