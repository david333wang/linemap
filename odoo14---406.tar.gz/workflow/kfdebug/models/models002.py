# -*- coding: utf-8 -*-

from odoo import models, fields, api


class wodebug002(models.Model):
    _name = 'kfdebug.wodebug002'
    _description = 'kfdebug.wodebug002'
    # _inherit = ['achworkflow.achrworkflowmixin']


    active = fields.Boolean(default=True,
                            help="If the active field is set to False, it will allow you to hide the project without removing it.")



    debug002 = fields.Many2one('kfdebug.wodebug001', 'wodebug002')




    name = fields.Char(string='name2')
    value = fields.Integer()
