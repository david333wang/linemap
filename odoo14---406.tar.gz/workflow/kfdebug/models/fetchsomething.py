# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import logging
import poplib
from ssl import SSLError
from socket import gaierror, timeout
from imaplib import IMAP4, IMAP4_SSL
from poplib import POP3, POP3_SSL

from odoo import api, fields, models, tools, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)


class fetchsomething(models.Model):
    _name = 'kfdebug.fetchsomething'
    _description = 'Fetch Something'

    name = fields.Char('Name', required=True)
    active = fields.Boolean('Active', default=True)
    state = fields.Selection([
        ('draft', 'Not Confirmed'),
        ('done', 'Confirmed'),
    ], string='Status', index=True, readonly=True, copy=False, default='draft')

    @api.model
    def create(self, values):
        res = super(fetchsomething, self).create(values)
        self._update_cron()
        return res

    def write(self, values):
        res = super(fetchsomething, self).write(values)
        self._update_cron()
        return res

    def unlink(self):
        res = super(fetchsomething, self).unlink()
        self._update_cron()
        return res

    def set_draft(self):
        self.write({'state': 'done'})
        return True

    def button_confirm_login(self):

        self._btn_fetch_mails()
        return True

    @api.model
    def _fetch_mails(self):
        """ Method called by cron to fetch mails from servers """
        return self.search([('state', '=', 'done')]).fetch_mail()

    def _btn_fetch_mails(self):
        """ Method called by cron to fetch mails from servers """
        return self.search([('state', '=', 'done')]).fetch_mail()

    def fetch_mail(self):
        """ WARNING: meant for cron usage only - will commit() after each email! """
        additionnal_context = {
            'fetchmail_cron_running': True
        }
        self = self.with_context(additionnal_context)

        for server in self:
            try:
                _logger.info('===============> kfgs==========>%s server %s', server.name, server.name)

                # self._cr.commit()
            except Exception:
                _logger.info("===============> kfgs==========> %s server %s.", server.name, server.name)
            finally:
                pass
        return True

    @api.model
    def _update_cron(self):
        if self.env.context.get('fetchmail_cron_running'):
            return
        try:
            # Enabled/Disable cron based on the number of 'done' server of type pop or imap
            cron = self.env.ref('kfdebug.ir_cron_do_gateway_action')
            cron.toggle(model=self._name, domain=[('state', '=', 'done')])
        except ValueError:
            pass
