# -*- coding: utf-8 -*-
{
    'name': "kfdebug",

    'summary': """
        Short (1 phrase/line) summary of the module's purpose, used as
        subtitle on modules listing or apps.openerp.com""",

    'description': """
        Long description of module's purpose                 
        field name="action_compute_attached_docs_count"
         widget="statinfo" string="Documents" options="{'reload_on_button': true}"
  
    """,

 

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/14.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
   'author': "调试专用库",
    'website': "调试专用库",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/14.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'tools',

    # any module necessary for this one to work correctly
    'depends': ['base', 'mail', 'achworkflow'],

    # always loaded
    'data': [
         'security/ir.model.access.csv',
        'views/templates.xml',
        'views/views.xml',
                'views/workflow001.xml',
        'views/workflow002.xml',
        'views/workflow003.xml',


        'report/running_workflow_templates.xml',
        'report/workflow_reports.xml',

        'demo/demo.xml',
         'data/fetchsomehting_data.xml',

        'views/fetchsomething_views.xml',

        'views/menu.xml',
    ],
    # only loaded in demonstration mode
    'demo': [

    ],

'qweb': [


    ],
    'installable': True,
    'application': True,
}
