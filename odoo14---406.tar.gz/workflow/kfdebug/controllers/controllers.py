# -*- coding: utf-8 -*-
# from odoo import http


# class Kfdebug(http.Controller):
#     @http.route('/kfdebug/kfdebug/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/kfdebug/kfdebug/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('kfdebug.listing', {
#             'root': '/kfdebug/kfdebug',
#             'objects': http.request.env['kfdebug.kfdebug'].search([]),
#         })

#     @http.route('/kfdebug/kfdebug/objects/<model("kfdebug.kfdebug"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('kfdebug.object', {
#             'object': obj
#         })
