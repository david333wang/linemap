# -*- coding: utf-8 -*-
# from odoo import http


# class AchIniData(http.Controller):
#     @http.route('/ach_ini_data/ach_ini_data/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/ach_ini_data/ach_ini_data/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('ach_ini_data.listing', {
#             'root': '/ach_ini_data/ach_ini_data',
#             'objects': http.request.env['ach_ini_data.ach_ini_data'].search([]),
#         })

#     @http.route('/ach_ini_data/ach_ini_data/objects/<model("ach_ini_data.ach_ini_data"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('ach_ini_data.object', {
#             'object': obj
#         })
