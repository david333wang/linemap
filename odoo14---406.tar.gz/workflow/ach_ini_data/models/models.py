# -*- coding: utf-8 -*-

# from odoo import models, fields, api


# class ach_ini_data(models.Model):
#     _name = 'ach_ini_data.ach_ini_data'
#     _description = 'ach_ini_data.ach_ini_data'

#     name = fields.Char()
#     value = fields.Integer()
#     value2 = fields.Float(compute="_value_pc", store=True)
#     description = fields.Text()
#
#     @api.depends('value')
#     def _value_pc(self):
#         for record in self:
#             record.value2 = float(record.value) / 100
