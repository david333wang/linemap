Open ERP System :- odoo13 Community

Installation 
============
Install the Application => Apps -> Watermark Report(Technical Name:reports_with_watermark	)

Installation
============
This Module Install than wkhtmltopdf library are required if not library than module not installed.

Version
========
	Odoo v14

Module Configuration Guideline
=============================

	1. Here We Can Select the Watergraph:
	   Settings -> Company -> Watermark Options
 
