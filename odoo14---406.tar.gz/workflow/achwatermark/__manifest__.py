# See README.rst file on addons root folder for license details

{
    "name": "achwatermark",
    "summary": "Watermark field",
    "version": "14.0.3.0.0",

    "category": "Tools",
    "depends": ["base"],
    "license": "LGPL-3",
    "data": [
        "views/company_view.xml"
    ],
    "images": ["static/description/main_screenshot.png"],
    "installable": True,

}
